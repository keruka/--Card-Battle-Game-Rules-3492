-- 攻撃ログテーブルの作成/更新
CREATE TABLE IF NOT EXISTS attack_logs_a7x9k2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  game_session_id TEXT NOT NULL,
  
  -- 🔧 修正: 攻撃者・被攻撃者の情報を正しく記録
  attacker_player INTEGER NOT NULL CHECK (attacker_player IN (1, 2)),
  target_player INTEGER NOT NULL CHECK (target_player IN (1, 2)),
  
  -- 攻撃者カード情報
  attacker_card_id UUID NOT NULL,
  attacker_card_name TEXT NOT NULL,
  
  -- 攻撃対象情報
  target_type TEXT NOT NULL CHECK (target_type IN ('insect', 'territory')),
  target_card_id UUID,
  target_card_name TEXT NOT NULL, -- 'Territory' or actual card name
  
  -- 攻撃詳細
  attack_value INTEGER NOT NULL CHECK (attack_value >= 0),
  attack_type INTEGER NOT NULL DEFAULT 1 CHECK (attack_type IN (1, 2)),
  is_advantage BOOLEAN NOT NULL DEFAULT false,
  damage_dealt INTEGER NOT NULL CHECK (damage_dealt >= 0),
  
  -- ゲーム状況
  turn_count INTEGER NOT NULL CHECK (turn_count >= 1),
  game_phase TEXT NOT NULL CHECK (game_phase IN ('draw', 'set', 'main', 'end')),
  
  -- タイムスタンプ
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- インデックスの追加
CREATE INDEX IF NOT EXISTS idx_attack_logs_game_session ON attack_logs_a7x9k2(game_session_id);
CREATE INDEX IF NOT EXISTS idx_attack_logs_attacker_player ON attack_logs_a7x9k2(attacker_player);
CREATE INDEX IF NOT EXISTS idx_attack_logs_target_player ON attack_logs_a7x9k2(target_player);
CREATE INDEX IF NOT EXISTS idx_attack_logs_target_type ON attack_logs_a7x9k2(target_type);
CREATE INDEX IF NOT EXISTS idx_attack_logs_turn_count ON attack_logs_a7x9k2(turn_count);
CREATE INDEX IF NOT EXISTS idx_attack_logs_created_at ON attack_logs_a7x9k2(created_at);

-- RLSポリシーの設定
ALTER TABLE attack_logs_a7x9k2 ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable read access for all users" ON attack_logs_a7x9k2;
DROP POLICY IF EXISTS "Enable insert for all users" ON attack_logs_a7x9k2;
DROP POLICY IF EXISTS "Enable update for all users" ON attack_logs_a7x9k2;
DROP POLICY IF EXISTS "Enable delete for all users" ON attack_logs_a7x9k2;

CREATE POLICY "Enable read access for all users" ON attack_logs_a7x9k2 FOR SELECT USING (true);
CREATE POLICY "Enable insert for all users" ON attack_logs_a7x9k2 FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update for all users" ON attack_logs_a7x9k2 FOR UPDATE USING (true);
CREATE POLICY "Enable delete for all users" ON attack_logs_a7x9k2 FOR DELETE USING (true);

-- 攻撃統計ビューの作成
CREATE OR REPLACE VIEW attack_statistics_view AS
SELECT 
  game_session_id,
  attacker_player,
  target_player,
  target_type,
  COUNT(*) as total_attacks,
  SUM(damage_dealt) as total_damage,
  COUNT(CASE WHEN is_advantage THEN 1 END) as advantage_attacks,
  COUNT(CASE WHEN target_type = 'territory' THEN 1 END) as territory_attacks,
  COUNT(CASE WHEN target_type = 'insect' THEN 1 END) as insect_attacks,
  MIN(created_at) as first_attack,
  MAX(created_at) as last_attack
FROM attack_logs_a7x9k2 
GROUP BY game_session_id, attacker_player, target_player, target_type
ORDER BY game_session_id, attacker_player, target_player;

-- ターン別攻撃ビューの作成
CREATE OR REPLACE VIEW turn_attacks_view AS
SELECT 
  game_session_id,
  turn_count,
  attacker_player,
  target_player,
  COUNT(*) as attacks_this_turn,
  SUM(damage_dealt) as damage_this_turn,
  array_agg(
    json_build_object(
      'attacker_card', attacker_card_name,
      'target_type', target_type,
      'target_card', target_card_name,
      'damage', damage_dealt,
      'advantage', is_advantage,
      'time', created_at
    ) ORDER BY created_at
  ) as attack_details
FROM attack_logs_a7x9k2 
GROUP BY game_session_id, turn_count, attacker_player, target_player
ORDER BY game_session_id, turn_count, attacker_player, target_player;

-- コメントの追加
COMMENT ON TABLE attack_logs_a7x9k2 IS 'Complete attack log with correct attacker/target identification';
COMMENT ON COLUMN attack_logs_a7x9k2.attacker_player IS 'Player who performed the attack (1 or 2)';
COMMENT ON COLUMN attack_logs_a7x9k2.target_player IS 'Player who was attacked (1 or 2)';
COMMENT ON COLUMN attack_logs_a7x9k2.attacker_card_name IS 'Name of the attacking card (e.g., アキアカネ)';
COMMENT ON COLUMN attack_logs_a7x9k2.target_card_name IS 'Name of target card or "Territory"';

-- 初期データ確認クエリ
SELECT 
  'Attack Logs' as table_name,
  COUNT(*) as total_records,
  COUNT(CASE WHEN attacker_player = 1 THEN 1 END) as player1_attacks,
  COUNT(CASE WHEN attacker_player = 2 THEN 1 END) as player2_attacks,
  COUNT(CASE WHEN target_type = 'territory' THEN 1 END) as territory_attacks,
  COUNT(CASE WHEN target_type = 'insect' THEN 1 END) as insect_attacks
FROM attack_logs_a7x9k2;