-- ナナフシモドキの擬態効果をデータベースに追加・更新
INSERT INTO cards_mushi_a7x9k2 (
  name, type, cost, attack1, attack2, health, element, rarity, 
  effect1_text, passive_effect_text, image_url
) VALUES 
(
  'ナナフシモドキ', 'insect', 1, 80, NULL, 60, 'green', 'N',
  '細い体での攻撃',
  '擬態: 場に出たとき、敵の攻撃を1回無効化する',
  'https://via.placeholder.com/150x200/22c55e/ffffff?text=ナナフシモドキ'
)
ON CONFLICT (name) DO UPDATE SET
  passive_effect_text = '擬態: 場に出たとき、敵の攻撃を1回無効化する',
  attack1 = 80,
  attack2 = NULL,
  health = 60,
  cost = 1,
  element = 'green',
  rarity = 'N',
  effect1_text = '細い体での攻撃';

-- 既存のナナフシモドキカードを全て更新
UPDATE cards_mushi_a7x9k2 
SET 
  passive_effect_text = '擬態: 場に出たとき、敵の攻撃を1回無効化する',
  attack1 = 80,
  attack2 = NULL,
  health = 60,
  cost = 1,
  element = 'green',
  rarity = 'N',
  effect1_text = '細い体での攻撃'
WHERE name LIKE '%ナナフシモドキ%' OR name LIKE '%nanafushi%';

-- 追加の擬態系カードも挿入
INSERT INTO cards_mushi_a7x9k2 (
  name, type, cost, attack1, attack2, health, element, rarity, 
  effect1_text, passive_effect_text, image_url
) VALUES 
(
  '忍者蟷螂', 'insect', 2, 120, 200, 80, 'green', 'R',
  '隠密攻撃',
  '擬態: 場に出たとき、敵の攻撃を1回無効化する',
  'https://via.placeholder.com/150x200/22c55e/ffffff?text=忍者蟷螂'
),
(
  '幻影蝶', 'insect', 3, 180, 280, 120, 'blue', 'SR',
  '幻惑の粉',
  '擬態: 場に出たとき、敵の攻撃を1回無効化する。さらに攻撃力+50',
  'https://via.placeholder.com/150x200/3b82f6/ffffff?text=幻影蝶'
)
ON CONFLICT (name) DO UPDATE SET
  passive_effect_text = EXCLUDED.passive_effect_text,
  attack1 = EXCLUDED.attack1,
  attack2 = EXCLUDED.attack2,
  health = EXCLUDED.health,
  cost = EXCLUDED.cost,
  element = EXCLUDED.element,
  rarity = EXCLUDED.rarity,
  effect1_text = EXCLUDED.effect1_text;

-- データベースの確認クエリ
SELECT 
  name, 
  passive_effect_text, 
  attack1, 
  attack2, 
  health, 
  cost,
  element,
  rarity
FROM cards_mushi_a7x9k2 
WHERE passive_effect_text LIKE '%擬態%' 
ORDER BY name;