-- 既存のテーブルに新しいカラムを追加
ALTER TABLE cards_mushi_a7x9k2 
ADD COLUMN IF NOT EXISTS attack1 INTEGER,
ADD COLUMN IF NOT EXISTS attack2 INTEGER,
ADD COLUMN IF NOT EXISTS effect1_text TEXT,
ADD COLUMN IF NOT EXISTS effect2_text TEXT,
ADD COLUMN IF NOT EXISTS passive_effect_text TEXT;

-- 既存の attack カラムのデータを attack1 に移行（まだ設定されていない場合）
UPDATE cards_mushi_a7x9k2 
SET attack1 = attack 
WHERE attack1 IS NULL AND attack IS NOT NULL;

-- attack2 のデフォルト値を設定（attack1 + 50、または150）
UPDATE cards_mushi_a7x9k2 
SET attack2 = COALESCE(attack1, attack, 100) + 50 
WHERE attack2 IS NULL AND type = 'insect';

-- 既存の effect_text を effect1_text に移行
UPDATE cards_mushi_a7x9k2 
SET effect1_text = effect_text 
WHERE effect1_text IS NULL AND effect_text IS NOT NULL;

-- 攻撃力0を許可するため、制約を更新
ALTER TABLE cards_mushi_a7x9k2 
DROP CONSTRAINT IF EXISTS cards_mushi_a7x9k2_attack_check;

ALTER TABLE cards_mushi_a7x9k2 
DROP CONSTRAINT IF EXISTS cards_mushi_a7x9k2_attack1_check;

ALTER TABLE cards_mushi_a7x9k2 
DROP CONSTRAINT IF EXISTS cards_mushi_a7x9k2_attack2_check;

-- 新しい制約を追加（0以上を許可）
ALTER TABLE cards_mushi_a7x9k2 
ADD CONSTRAINT cards_mushi_a7x9k2_attack_check CHECK (attack >= 0);

ALTER TABLE cards_mushi_a7x9k2 
ADD CONSTRAINT cards_mushi_a7x9k2_attack1_check CHECK (attack1 >= 0);

ALTER TABLE cards_mushi_a7x9k2 
ADD CONSTRAINT cards_mushi_a7x9k2_attack2_check CHECK (attack2 >= 0);

-- 体力は1以上の制約を維持
ALTER TABLE cards_mushi_a7x9k2 
DROP CONSTRAINT IF EXISTS cards_mushi_a7x9k2_health_check;

ALTER TABLE cards_mushi_a7x9k2 
ADD CONSTRAINT cards_mushi_a7x9k2_health_check CHECK (health > 0 OR type != 'insect');

-- インデックスを追加してパフォーマンスを向上
CREATE INDEX IF NOT EXISTS idx_cards_type ON cards_mushi_a7x9k2(type);
CREATE INDEX IF NOT EXISTS idx_cards_rarity ON cards_mushi_a7x9k2(rarity);
CREATE INDEX IF NOT EXISTS idx_cards_element ON cards_mushi_a7x9k2(element);
CREATE INDEX IF NOT EXISTS idx_cards_cost ON cards_mushi_a7x9k2(cost);

-- RLSポリシーを確認・更新
DROP POLICY IF EXISTS "Enable read access for all users" ON cards_mushi_a7x9k2;
DROP POLICY IF EXISTS "Enable insert for all users" ON cards_mushi_a7x9k2;
DROP POLICY IF EXISTS "Enable update for all users" ON cards_mushi_a7x9k2;
DROP POLICY IF EXISTS "Enable delete for all users" ON cards_mushi_a7x9k2;

CREATE POLICY "Enable read access for all users" ON cards_mushi_a7x9k2
    FOR SELECT USING (true);

CREATE POLICY "Enable insert for all users" ON cards_mushi_a7x9k2
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON cards_mushi_a7x9k2
    FOR UPDATE USING (true);

CREATE POLICY "Enable delete for all users" ON cards_mushi_a7x9k2
    FOR DELETE USING (true);

-- テーブルのコメントを更新
COMMENT ON TABLE cards_mushi_a7x9k2 IS 'Card data for insect card game with dual attack system';
COMMENT ON COLUMN cards_mushi_a7x9k2.attack1 IS 'Primary attack value (can be 0)';
COMMENT ON COLUMN cards_mushi_a7x9k2.attack2 IS 'Secondary attack value (can be 0)';
COMMENT ON COLUMN cards_mushi_a7x9k2.effect1_text IS 'Effect triggered when using attack1';
COMMENT ON COLUMN cards_mushi_a7x9k2.effect2_text IS 'Effect triggered when using attack2';
COMMENT ON COLUMN cards_mushi_a7x9k2.passive_effect_text IS 'Passive effect while card is on field';