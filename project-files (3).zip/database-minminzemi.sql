-- ミンミンゼミカードをデータベースに追加・更新
INSERT INTO cards_mushi_a7x9k2 (
  name,
  type,
  cost,
  attack1,
  attack2,
  health,
  element,
  rarity,
  effect1_text,
  passive_effect_text,
  image_url
) VALUES (
  'ミンミンゼミ',
  'insect',
  2,
  150,
  250,
  120,
  'red',
  'R',
  '夏の鳴き声',
  'とびだす: 縄張りから手札に移動した時、コストを支払わずに場に出すことができる',
  'https://via.placeholder.com/150x200/ef4444/ffffff?text=ミンミンゼミ'
) ON CONFLICT (name) DO UPDATE SET
  passive_effect_text = 'とびだす: 縄張りから手札に移動した時、コストを支払わずに場に出すことができる',
  attack1 = 150,
  attack2 = 250,
  health = 120,
  cost = 2,
  element = 'red',
  rarity = 'R',
  effect1_text = '夏の鳴き声';

-- 追加のとびだす系カードも挿入
INSERT INTO cards_mushi_a7x9k2 (
  name,
  type,
  cost,
  attack1,
  attack2,
  health,
  element,
  rarity,
  effect1_text,
  passive_effect_text,
  image_url
) VALUES (
  'アブラゼミ',
  'insect',
  1,
  100,
  180,
  100,
  'green',
  'N',
  '油のような鳴き声',
  'とびだす: 縄張りから手札に移動した時、コストを支払わずに場に出すことができる',
  'https://via.placeholder.com/150x200/22c55e/ffffff?text=アブラゼミ'
),(
  'ツクツクボウシ',
  'insect',
  3,
  200,
  350,
  150,
  'blue',
  'R',
  'ツクツク鳴き',
  'とびだす: 縄張りから手札に移動した時、コストを支払わずに場に出すことができる',
  'https://via.placeholder.com/150x200/3b82f6/ffffff?text=ツクツクボウシ'
) ON CONFLICT (name) DO UPDATE SET
  passive_effect_text = EXCLUDED.passive_effect_text,
  attack1 = EXCLUDED.attack1,
  attack2 = EXCLUDED.attack2,
  health = EXCLUDED.health,
  cost = EXCLUDED.cost,
  element = EXCLUDED.element,
  rarity = EXCLUDED.rarity,
  effect1_text = EXCLUDED.effect1_text;

-- とびだす効果を持つカードの確認クエリ
SELECT name, passive_effect_text, attack1, attack2, health, cost, element, rarity
FROM cards_mushi_a7x9k2 
WHERE passive_effect_text LIKE '%とびだす%' 
ORDER BY name;