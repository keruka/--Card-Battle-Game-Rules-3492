-- ゲームセッションテーブルの作成/更新
CREATE TABLE IF NOT EXISTS game_sessions_a7x9k2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  current_player INTEGER NOT NULL DEFAULT 1 CHECK (current_player IN (1, 2)),
  game_phase TEXT NOT NULL DEFAULT 'setup' CHECK (game_phase IN ('setup', 'draw', 'set', 'main', 'end')),
  turn_count INTEGER NOT NULL DEFAULT 0,
  turn_history JSONB DEFAULT '[]'::jsonb,
  game_state JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_update TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- インデックスの追加
CREATE INDEX IF NOT EXISTS idx_game_sessions_current_player ON game_sessions_a7x9k2(current_player);
CREATE INDEX IF NOT EXISTS idx_game_sessions_game_phase ON game_sessions_a7x9k2(game_phase);
CREATE INDEX IF NOT EXISTS idx_game_sessions_turn_count ON game_sessions_a7x9k2(turn_count);
CREATE INDEX IF NOT EXISTS idx_game_sessions_updated_at ON game_sessions_a7x9k2(updated_at);

-- RLSポリシーの設定
ALTER TABLE game_sessions_a7x9k2 ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable read access for all users" ON game_sessions_a7x9k2;
DROP POLICY IF EXISTS "Enable insert for all users" ON game_sessions_a7x9k2;
DROP POLICY IF EXISTS "Enable update for all users" ON game_sessions_a7x9k2;
DROP POLICY IF EXISTS "Enable delete for all users" ON game_sessions_a7x9k2;

CREATE POLICY "Enable read access for all users" ON game_sessions_a7x9k2 FOR SELECT USING (true);
CREATE POLICY "Enable insert for all users" ON game_sessions_a7x9k2 FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update for all users" ON game_sessions_a7x9k2 FOR UPDATE USING (true);
CREATE POLICY "Enable delete for all users" ON game_sessions_a7x9k2 FOR DELETE USING (true);

-- ターン履歴ビューの作成
CREATE OR REPLACE VIEW turn_history_view AS
SELECT 
  id,
  current_player,
  game_phase,
  turn_count,
  jsonb_array_length(turn_history) as total_turns,
  turn_history,
  created_at,
  updated_at,
  last_update
FROM game_sessions_a7x9k2
ORDER BY updated_at DESC;

-- 自動更新トリガーの作成
CREATE OR REPLACE FUNCTION update_game_session_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_game_sessions_updated_at ON game_sessions_a7x9k2;
CREATE TRIGGER update_game_sessions_updated_at
  BEFORE UPDATE ON game_sessions_a7x9k2
  FOR EACH ROW
  EXECUTE FUNCTION update_game_session_timestamp();

-- コメントの追加
COMMENT ON TABLE game_sessions_a7x9k2 IS 'Game session management with turn tracking';
COMMENT ON COLUMN game_sessions_a7x9k2.current_player IS 'Current active player (1 or 2)';
COMMENT ON COLUMN game_sessions_a7x9k2.game_phase IS 'Current game phase (setup, draw, set, main, end)';
COMMENT ON COLUMN game_sessions_a7x9k2.turn_count IS 'Current turn number';
COMMENT ON COLUMN game_sessions_a7x9k2.turn_history IS 'JSON array of turn history entries';
COMMENT ON COLUMN game_sessions_a7x9k2.game_state IS 'Complete game state snapshot';
COMMENT ON COLUMN game_sessions_a7x9k2.last_update IS 'Last turn state update timestamp';

-- 初期データの確認クエリ
SELECT 
  'Game Sessions' as table_name,
  COUNT(*) as total_records,
  COUNT(CASE WHEN current_player = 1 THEN 1 END) as player1_sessions,
  COUNT(CASE WHEN current_player = 2 THEN 1 END) as player2_sessions
FROM game_sessions_a7x9k2;