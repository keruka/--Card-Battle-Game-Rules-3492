import React from 'react';
import { motion } from 'framer-motion';
import Hand from './Hand';
import Field from './Field';
import FeedArea from './FeedArea';
import TerritoryArea from './TerritoryArea';
import GraveyardArea from './GraveyardArea';
import PlayerInfo from './PlayerInfo';
import TurnIndicator from './TurnIndicator';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiMessageSquare, FiHome, FiSword, FiShield, FiUser, FiLayers, FiArchive, FiDollarSign } = FiIcons;

const PlayerArea = ({
  player,
  isCurrentPlayer,
  isOpponent,
  onPlayCard,
  onAttack,
  onSetFeed,
  gamePhase,
  onReturnCardToHand,
  onCardClick,
  onImageClick,
  compact = false,
  turnCount = 1,
  currentPlayer = 1,
  // 🆕 攻撃対象選択用の新しいプロパティ
  enemyPlayer,
  onAttackTarget,
  // 🆕 エサセットスキップ用の新しいプロパティ
  onSkipFeedPhase,
  // 🆕 術カード捨札ドロップ用のプロパティ
  onSpellToGraveyard,
  // 🆕 強化カード場適用用のプロパティ
  onEnhancementDrop,
  // 🆕 縄張り攻撃状況用のプロパティ
  territoryAttackStatus = null,
  // 🆕 UIコントロール用のプロパティ
  showUIControls = false,
  showPlayerInfo = true, // 🆕 プレイヤー情報表示制御
  endTurn,
  isAIProcessing,
  isTurnTransitioning,
  gameSessionId,
  gameLog,
  onShowGameLog,
  onReturnHome,
  // 🆕 弱体化効果関連のプロパティ
  getDebuffStatus,
  getEffectiveAttackPower,
  // 🆕 強化効果関連のプロパティ
  getEffectiveMaxHealth,
  // 🆕 飛蝗の凶相効果関連のプロパティ
  getLocustSpellStatus,
  // 🆕 擬態効果関連のプロパティ
  getMimicryStatus,
  // 🆕 蟲の息吹捨札ドロップ用のプロパティ
  onBreathOfInsectsDrop,
  // 🆕 擬態効果の強制リフレッシュ用
  mimicryRefresh = 0
}) => {
  if (!player) return null;

  // 🆕 このプレイヤーの縄張り攻撃状況を取得
  const playerNumber = isOpponent ? 2 : 1;
  const hasBeenAttacked = (territoryAttackStatus?.hasPlayer1BeenAttacked && playerNumber === 1) || 
                          (territoryAttackStatus?.hasPlayer2BeenAttacked && playerNumber === 2);
  const attackCount = playerNumber === 1 ? 
                     (territoryAttackStatus?.player1Attacks?.length || 0) : 
                     (territoryAttackStatus?.player2Attacks?.length || 0);

  // 🔧 プレイヤー1エリア縮小のためのcompactプロパティを強制的に設定
  const forceCompact = !isOpponent ? true : compact;

  // 🔧 修正: 背景画像の設定（プレイヤー1の背景を上限から下限まで完全拡張）
  const getBackgroundStyle = () => {
    if (isOpponent) {
      // プレイヤー2（上部）: 背景なし（全体背景を使用）
      return {};
    } else {
      // プレイヤー1（下部）: 背景を上限から下限まで完全拡張
      return {
        backgroundImage: 'url("https://quest-media-storage-bucket.s3.us-east-2.amazonaws.com/1751765332470-mushi_playmat_tensho.webp")',
        backgroundSize: '120% 300%', // 🔧 修正: 縦方向を300%に大幅拡張して確実に上下をカバー
        backgroundPosition: 'center center', // 🔧 修正: 中央基準で上下に拡張
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'local'
      };
    }
  };

  // 🔧 修正: プレイヤー1エリアの上限調整と下限拡張
  const getContainerClasses = () => {
    if (isOpponent) {
      return `
        relative rounded-xl overflow-hidden 
        ${forceCompact ? 'p-1' : 'p-2'}
        ${isCurrentPlayer ? 'ring-2 ring-emerald-400' : ''}
        transform rotate-180
        ${hasBeenAttacked ? 'ring-2 ring-orange-400 ring-opacity-50' : ''}
      `;
    } else {
      // プレイヤー1: エリア上限は維持、コンテンツを微調整
      return `
        relative rounded-xl overflow-hidden 
        ${forceCompact ? 'p-1' : 'p-2'}
        ${isCurrentPlayer ? 'ring-2 ring-emerald-400' : ''}
        ${hasBeenAttacked ? 'ring-2 ring-orange-400 ring-opacity-50' : ''}
        -mt-12 -mb-32 pt-5 pb-36
        before:absolute before:inset-0 before:bg-cover before:bg-center before:bg-no-repeat before:-z-10
      `;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: isOpponent ? -20 : 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={getContainerClasses()}
      style={getBackgroundStyle()}
    >
      {/* 🆕 背景拡張レイヤー（プレイヤー1のみ） */}
      {!isOpponent && (
        <div 
          className="absolute -top-12 -bottom-32 -left-4 -right-4 -z-10"
          style={{
            backgroundImage: 'url("https://quest-media-storage-bucket.s3.us-east-2.amazonaws.com/1751765332470-mushi_playmat_tensho.webp")',
            backgroundSize: '120% 500%', // さらに大きく拡張
            backgroundPosition: 'center center',
            backgroundRepeat: 'no-repeat',
            backgroundAttachment: 'local'
          }}
        />
      )}

      {/* 🔧 修正: コンテンツエリア（プレイヤー1は微調整） */}
      <div className={`relative z-10 ${isOpponent ? 'transform rotate-180' : ''} ${!isOpponent ? '-mt-5' : ''}`}>
        {/* 🔧 プレイヤー情報を条件付きで表示（showPlayerInfoで制御） */}
        {isOpponent && showPlayerInfo && (
          <PlayerInfo
            player={player}
            isCurrentPlayer={isCurrentPlayer}
            isOpponent={isOpponent}
            compact={forceCompact}
            // 🆕 縄張り攻撃状況を渡す
            hasBeenAttacked={hasBeenAttacked}
            attackCount={attackCount}
          />
        )}

        {/* 🔧 場エリアを横幅制限して中央配置 */}
        <div className={`flex justify-center ${!isOpponent ? 'mb-0' : ''}`}>
          <div className={`${forceCompact ? 'max-w-xs' : 'max-w-md'} w-full`}>
            <Field
              insects={player.field}
              isCurrentPlayer={isCurrentPlayer}
              onAttack={onAttack}
              gamePhase={gamePhase}
              onPlayCard={onPlayCard}
              onReturnToHand={(card) => onReturnCardToHand(card, 'field')}
              onCardClick={onCardClick}
              compact={forceCompact}
              turnCount={turnCount}
              currentPlayer={currentPlayer}
              // 🆕 攻撃対象選択用のプロパティを追加
              enemyField={enemyPlayer?.field || []}
              onAttackTarget={onAttackTarget}
              // 🆕 強化カード場適用用のプロパティを追加
              onEnhancementDrop={onEnhancementDrop}
              // 🆕 プレイヤー2判定を追加
              isOpponent={isOpponent}
              // 🆕 弱体化効果関連のプロパティを追加
              getDebuffStatus={getDebuffStatus}
              getEffectiveAttackPower={getEffectiveAttackPower}
              // 🆕 強化効果関連のプロパティを追加
              getEffectiveMaxHealth={getEffectiveMaxHealth}
              // 🆕 擬態効果関連のプロパティを追加
              getMimicryStatus={getMimicryStatus}
              // 🆕 擬態効果の強制リフレッシュを追加
              mimicryRefresh={mimicryRefresh}
            />
          </div>
        </div>

        {/* 🔧 修正: 3列グリッドで均等に配置 */}
        <div className={`grid grid-cols-3 gap-1 ${forceCompact ? 'mb-0' : 'mb-0'} max-w-md mx-auto ${!isOpponent ? '-mt-0.5' : ''}`}>
          {/* 縄張りエリア */}
          <div className="col-span-1">
            <TerritoryArea
              territory={player.territory}
              compact={forceCompact}
              hasBeenAttacked={hasBeenAttacked}
              attackCount={attackCount}
              isCurrentPlayer={isCurrentPlayer}
              playerNumber={playerNumber}
              // 🆕 プレイヤー2判定を追加
              isOpponent={isOpponent}
            />
          </div>

          {/* エサ場エリア */}
          <div className="col-span-1">
            <FeedArea
              feedCards={player.feedArea}
              currentCost={player.currentCost}
              maxCost={player.maxCost}
              onSetFeed={onSetFeed}
              isCurrentPlayer={isCurrentPlayer}
              gamePhase={gamePhase}
              onReturnToHand={(card) => onReturnCardToHand(card, 'feed')}
              compact={forceCompact}
              hasSetFeed={player.hasSetFeed}
              turnCount={turnCount}
              // 🆕 プレイヤー2判定を追加
              isOpponent={isOpponent}
            />
          </div>

          {/* 捨札エリア */}
          <div className="col-span-1">
            <GraveyardArea
              graveyard={player.graveyard}
              onCardClick={onCardClick}
              compact={forceCompact}
              // 🆕 術カードドロップ用のプロパティ
              onSpellDrop={onSpellToGraveyard}
              isCurrentPlayer={isCurrentPlayer}
              gamePhase={gamePhase}
              // 🆕 プレイヤー2判定を追加
              isOpponent={isOpponent}
              // 🆕 飛蝗の凶相効果関連のプロパティを追加
              getLocustSpellStatus={getLocustSpellStatus}
              currentPlayer={playerNumber}
              // 🆕 蟲の息吹捨札ドロップ用のプロパティを追加
              onBreathOfInsectsDrop={onBreathOfInsectsDrop}
            />
          </div>
        </div>

        {/* 🔧 プレイヤー1の情報を下に移動 - 微調整 */}
        {!isOpponent && showPlayerInfo && (
          <div className="-mt-0.5">
            <PlayerInfo
              player={player}
              isCurrentPlayer={isCurrentPlayer}
              isOpponent={isOpponent}
              compact={forceCompact}
              // 🆕 縄張り攻撃状況を渡す
              hasBeenAttacked={hasBeenAttacked}
              attackCount={attackCount}
            />
          </div>
        )}

        {/* 🔧 修正: プレイヤー1の手札エリアとスキップボタンを横並びに配置 */}
        {!isOpponent && (
          <div className="max-w-md mx-auto -mt-3">
            {showUIControls && (
              <div className="flex items-center gap-2">
                {/* 🔧 修正: エサセットスキップボタンを手札の左に配置 */}
                {isCurrentPlayer && gamePhase === 'set' && !player.hasSetFeed && onSkipFeedPhase && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                    className="flex-shrink-0"
                  >
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={onSkipFeedPhase}
                      className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white rounded-lg font-semibold flex flex-col items-center justify-center gap-0.5 transition-all duration-200 shadow-lg px-2 py-2 h-16 w-16"
                    >
                      <SafeIcon icon={FiIcons.FiSkipForward} className="text-sm" />
                      <div className="text-center">
                        <div className="text-xs leading-tight">エサ</div>
                        <div className="text-xs leading-tight">スキップ</div>
                      </div>
                    </motion.button>
                  </motion.div>
                )}

                {/* 🆕 手札エリア */}
                <div className="flex-1 min-w-0">
                  <Hand
                    cards={player.hand}
                    isCurrentPlayer={isCurrentPlayer}
                    onPlayCard={onPlayCard}
                    onSetFeed={onSetFeed}
                    gamePhase={gamePhase}
                    currentCost={player.currentCost}
                    onCardClick={onCardClick}
                    onImageClick={onImageClick}
                    hasSetFeed={player.hasSetFeed}
                    enemyField={enemyPlayer?.field || []}
                    onAttackTarget={onAttackTarget}
                    onSkipFeedPhase={null} // 🔧 修正: スキップボタンは左に配置
                    compact={true}
                    showTitle={false}
                    showCardBack={false}
                    // 🆕 弱体化効果関連のプロパティを追加
                    getDebuffStatus={getDebuffStatus}
                    getEffectiveAttackPower={getEffectiveAttackPower}
                    // 🆕 強化効果関連のプロパティを追加
                    getEffectiveMaxHealth={getEffectiveMaxHealth}
                    // 🆕 擬態効果関連のプロパティを追加
                    getMimicryStatus={getMimicryStatus}
                    // 🆕 擬態効果の強制リフレッシュを追加
                    mimicryRefresh={mimicryRefresh}
                  />
                </div>
              </div>
            )}

            {/* 通常の手札表示（UIコントロールがない場合） */}
            {!showUIControls && (
              <Hand
                cards={player.hand}
                isCurrentPlayer={isCurrentPlayer}
                onPlayCard={onPlayCard}
                onSetFeed={onSetFeed}
                gamePhase={gamePhase}
                currentCost={player.currentCost}
                onCardClick={onCardClick}
                onImageClick={onImageClick}
                hasSetFeed={player.hasSetFeed}
                enemyField={enemyPlayer?.field || []}
                onAttackTarget={onAttackTarget}
                onSkipFeedPhase={onSkipFeedPhase}
                compact={forceCompact}
                showTitle={false}
                showCardBack={false}
                // 🆕 弱体化効果関連のプロパティを追加
                getDebuffStatus={getDebuffStatus}
                getEffectiveAttackPower={getEffectiveAttackPower}
                // 🆕 強化効果関連のプロパティを追加
                getEffectiveMaxHealth={getEffectiveMaxHealth}
                // 🆕 擬態効果関連のプロパティを追加
                getMimicryStatus={getMimicryStatus}
                // 🆕 擬態効果の強制リフレッシュを追加
                mimicryRefresh={mimicryRefresh}
              />
            )}
          </div>
        )}

        {/* 🔧 修正: プレイヤー2（敵）の手札は裏面表示、配置は元のまま */}
        {isOpponent && (
          <div className="max-w-md mx-auto">
            <Hand
              cards={player.hand}
              isCurrentPlayer={isCurrentPlayer}
              onPlayCard={onPlayCard}
              onSetFeed={onSetFeed}
              gamePhase={gamePhase}
              currentCost={player.currentCost}
              onCardClick={onCardClick}
              onImageClick={onImageClick}
              hasSetFeed={player.hasSetFeed}
              enemyField={enemyPlayer?.field || []}
              onAttackTarget={onAttackTarget}
              compact={forceCompact}
              showTitle={false}
              showCardBack={true}
              // 🆕 弱体化効果関連のプロパティを追加
              getDebuffStatus={getDebuffStatus}
              getEffectiveAttackPower={getEffectiveAttackPower}
              // 🆕 強化効果関連のプロパティを追加
              getEffectiveMaxHealth={getEffectiveMaxHealth}
              // 🆕 擬態効果関連のプロパティを追加
              getMimicryStatus={getMimicryStatus}
              // 🆕 擬態効果の強制リフレッシュを追加
              mimicryRefresh={mimicryRefresh}
            />
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default PlayerArea;