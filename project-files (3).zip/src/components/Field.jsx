import React from 'react';
import { motion } from 'framer-motion';
import { useDrop } from 'react-dnd';
import Card from './Card';

const Field = ({
  insects,
  isCurrentPlayer,
  onAttack,
  gamePhase,
  onPlayCard,
  onReturnToHand,
  onCardClick,
  compact = false,
  turnCount = 1,
  currentPlayer = 1,
  // 🆕 攻撃対象選択用の新しいプロパティ
  enemyField = [],
  onAttackTarget,
  // 🆕 強化カード適用用の新しいプロパティ
  onEnhancementDrop,
  // 🆕 プレイヤー2判定用のプロパティ
  isOpponent = false,
  // 🆕 弱体化効果関連のプロパティ
  getDebuffStatus,
  getEffectiveAttackPower,
  // 🆕 強化効果関連のプロパティ
  getEffectiveMaxHealth,
  // 🆕 擬態効果関連のプロパティ
  getMimicryStatus,
  // 🆕 擬態効果の強制リフレッシュ用
  mimicryRefresh = 0
}) => {
  const [{ isOver, canDrop }, drop] = useDrop(
    () => ({
      accept: 'card',
      drop: (item) => {
        // 🆕 強化カードの処理
        if (item.card.type === 'enhancement' && isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && insects.length > 0) {
          onEnhancementDrop?.(item.card);
          return;
        }
        // 既存のムシカードドロップ処理
        if (item.card.type === 'insect' && isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main')) {
          onPlayCard(item.card);
        }
      },
      canDrop: (item) => {
        // 🆕 強化カードの条件: 自分のムシが場にいる時のみ
        if (item.card.type === 'enhancement') {
          return isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && insects.length > 0;
        }
        // 既存のムシカード条件
        return item.card.type === 'insect' && isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && insects.length < 5;
      },
      collect: (monitor) => ({
        isOver: monitor.isOver(),
        canDrop: monitor.canDrop(),
      }),
    }),
    [insects.length, isCurrentPlayer, gamePhase, onEnhancementDrop]
  );

  const isHighlighted = isOver && canDrop;

  return (
    <div className={compact ? 'mb-1' : 'mb-4'} ref={drop}>
      {/* 🔧 修正: プレイヤー2（相手）の場合はタイトルを表示しない */}
      {!isOpponent && (
        <h4 className={`text-white font-semibold text-center ${compact ? 'text-xs mb-1' : 'text-sm mb-3'}`}>
          場 ({insects.length}/5)
          {isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && (
            <span className="text-emerald-300 text-xs ml-1">
              (虫・強化カードをドロップ)
            </span>
          )}
        </h4>
      )}

      <div
        className={`
          relative bg-gradient-to-br from-emerald-900/50 via-emerald-800/40 to-emerald-900/50 
          border-4 border-dashed border-emerald-500/60 rounded-xl transition-all duration-300
          ${isHighlighted ? 'border-emerald-400 bg-gradient-to-br from-emerald-400/40 via-emerald-300/30 to-emerald-400/40 shadow-lg shadow-emerald-400/30' : ''}
          ${compact ? 'min-h-8 p-1' : 'min-h-28 p-4'}
        `}
      >
        <div className="relative z-10">
          {insects.length === 0 ? (
            <div
              className={`flex items-center justify-center h-full text-emerald-200/80 font-medium ${
                compact ? 'text-xs min-h-6' : 'text-sm min-h-20'
              } ${isOpponent ? 'transform rotate-180' : ''}`}
            >
              {isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') ? (
                compact ? '虫をドロップ' : '虫カードをドロップ'
              ) : (
                'なし'
              )}
            </div>
          ) : (
            <div
              className={`flex gap-2 justify-center items-center flex-wrap ${
                compact ? 'gap-0.5' : 'gap-3'
              }`}
            >
              {insects.map((insect, index) => {
                // 🔍 デバッグ情報をログ出力
                console.log(`🐛 Field insect ${insect.name}:`, {
                  playedTurn: insect.playedTurn,
                  currentTurn: turnCount,
                  currentPlayer,
                  isCurrentPlayer,
                  hasPlayed: insect.hasPlayed
                });

                return (
                  <motion.div
                    key={insect.id}
                    initial={{ opacity: 0, scale: 0.8, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: index * 0.1, type: "spring", stiffness: 300, damping: 20 }}
                    whileHover={{ y: compact ? -1 : -2, scale: compact ? 1.01 : 1.02 }}
                  >
                    <div className={compact ? 'transform scale-60 origin-center' : ''}>
                      <Card
                        card={insect}
                        inField={true}
                        canAttack={isCurrentPlayer && gamePhase === 'main' && !insect.hasAttacked}
                        onAttack={() => onAttack(insect)}
                        currentHealth={insect.currentHealth}
                        hasAttacked={insect.hasAttacked}
                        onReturnToHand={
                          isCurrentPlayer && !insect.hasPlayed ? () => onReturnToHand(insect) : null
                        }
                        onCardClick={() => onCardClick(insect)}
                        compact={compact}
                        turnCount={turnCount}
                        gamePhase={gamePhase}
                        cardPlayedTurn={insect.playedTurn}
                        currentPlayer={currentPlayer}
                        // 🆕 攻撃対象選択用のプロパティを追加
                        enemyField={enemyField}
                        onAttackTarget={onAttackTarget}
                        // 🆕 弱体化効果関連のプロパティを追加
                        getDebuffStatus={getDebuffStatus}
                        getEffectiveAttackPower={getEffectiveAttackPower}
                        // 🆕 強化効果関連のプロパティを追加
                        getEffectiveMaxHealth={getEffectiveMaxHealth}
                        // 🆕 擬態効果関連のプロパティを追加
                        getMimicryStatus={getMimicryStatus}
                        // 🆕 擬態効果の強制リフレッシュを追加
                        mimicryRefresh={mimicryRefresh}
                      />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {isHighlighted && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-emerald-400/20 rounded-xl border-2 border-emerald-400 pointer-events-none"
          />
        )}
      </div>
    </div>
  );
};

export default Field;