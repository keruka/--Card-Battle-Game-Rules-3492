import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiX } = FiIcons;

const CardImageModal = ({ card, onClose }) => {
  const modalRef = useRef(null);

  useEffect(() => {
    const handleEscape = (e) => e.key === 'Escape' && onClose();
    const handleClickOutside = (e) => !modalRef.current?.contains(e.target) && onClose();

    document.addEventListener('keydown', handleEscape);
    document.addEventListener('mousedown', handleClickOutside);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'auto';
    };
  }, [onClose]);

  const borderColors = { N: 'border-gray-400', R: 'border-blue-400', SR: 'border-purple-400', LR: 'border-yellow-400' };
  const glowColors = { N: 'shadow-xl shadow-gray-400/20', R: 'shadow-xl shadow-blue-400/40', SR: 'shadow-xl shadow-purple-400/40', LR: 'shadow-xl shadow-yellow-400/40' };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        ref={modalRef}
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="relative max-w-xs w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="absolute -top-3 -right-3 w-8 h-8 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center text-white shadow-lg z-10"
        >
          <SafeIcon icon={FiX} className="text-sm" />
        </motion.button>

        <div className={`w-full aspect-[3/4] rounded-xl border-3 ${borderColors[card.rarity] || 'border-gray-400'} ${glowColors[card.rarity] || 'shadow-xl shadow-gray-400/20'} overflow-hidden`}>
          {card.image_url ? (
            <img src={card.image_url} alt={card.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gray-700 flex items-center justify-center text-white">
              <div className="text-center">
                <h2 className="text-lg font-bold">{card.name}</h2>
                <p className="text-sm opacity-75">画像なし</p>
              </div>
            </div>
          )}
        </div>

        <p className="mt-3 text-center text-gray-300 text-xs">ESCキーまたは外側をクリックで閉じる</p>
      </motion.div>
    </motion.div>
  );
};

export default CardImageModal;