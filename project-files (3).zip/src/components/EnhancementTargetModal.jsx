import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const { FiTarget, FiX, FiZap } = FiIcons;

const EnhancementTargetModal = ({ 
  isOpen, 
  enhancementCard, 
  targetInsects, 
  onSelectTarget, 
  onCancel 
}) => {
  if (!isOpen || !enhancementCard) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onCancel}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-xl font-bold flex items-center gap-2">
            <SafeIcon icon={FiTarget} className="text-yellow-400" />
            強化対象を選択
          </h2>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <SafeIcon icon={FiX} className="text-xl" />
          </button>
        </div>

        {/* 強化カード表示 */}
        <div className="mb-6 p-4 bg-yellow-900/20 border border-yellow-600/30 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-16 h-20 flex-shrink-0">
              <Card card={enhancementCard} compact={true} />
            </div>
            <div>
              <h3 className="text-yellow-300 font-bold text-lg">{enhancementCard.name}</h3>
              <p className="text-gray-300 text-sm mt-1">
                {enhancementCard.effect1_text || enhancementCard.effect_text || '強化効果'}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-yellow-400 text-xs">コスト: {enhancementCard.cost}</span>
                <span className="text-yellow-400 text-xs">•</span>
                <span className="text-yellow-400 text-xs">強化カード</span>
              </div>
            </div>
          </div>
        </div>

        {/* 対象選択説明 */}
        <div className="mb-4 text-center">
          <p className="text-gray-300 text-sm">
            この強化カードを適用するムシを選択してください
          </p>
          <p className="text-yellow-300 text-xs mt-1">
            ※ 強化カードは選択したムシの右上に表示されます
          </p>
        </div>

        {/* ターゲット選択 */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          {targetInsects.map((insect, index) => (
            <motion.div
              key={insect.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onSelectTarget(insect)}
              className="cursor-pointer bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded-lg p-3 transition-all duration-200"
            >
              <div className="flex flex-col items-center">
                {/* ムシカード */}
                <div className="w-20 h-28 mb-2">
                  <Card card={insect} compact={true} />
                </div>
                
                {/* ムシ情報 */}
                <div className="text-center">
                  <h4 className="text-white font-semibold text-sm">{insect.name}</h4>
                  <div className="text-xs text-gray-400 space-y-1 mt-1">
                    <div>攻撃: {insect.attack1 || insect.attack || 0}</div>
                    <div>体力: {insect.currentHealth || insect.health}/{insect.health}</div>
                    {insect.appliedEnhancements && insect.appliedEnhancements.length > 0 && (
                      <div className="text-yellow-400">
                        強化済み: {insect.appliedEnhancements.length}個
                      </div>
                    )}
                  </div>
                </div>

                {/* 選択ボタン */}
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="mt-2 bg-yellow-600 hover:bg-yellow-500 text-white px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <SafeIcon icon={FiZap} />
                  選択
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* キャンセルボタン */}
        <div className="flex justify-center">
          <button
            onClick={onCancel}
            className="bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default EnhancementTargetModal;