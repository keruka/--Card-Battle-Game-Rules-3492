import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiCheckCircle, FiX, FiArrowRight, FiAlertTriangle } = FiIcons;

const PhaseConfirmationModal = ({ isOpen, onConfirm, onCancel, cardName }) => {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onCancel}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-gray-900 rounded-2xl p-6 max-w-md mx-4 border border-yellow-400/30"
        onClick={e => e.stopPropagation()}
      >
        <div className="text-center">
          <div className="mb-4">
            <SafeIcon icon={FiCheckCircle} className="text-yellow-400 text-4xl mx-auto mb-2" />
            <h3 className="text-white text-xl font-bold mb-2">
              エサセット完了
            </h3>
            <p className="text-gray-300 text-sm">
              「{cardName}」をエサ場にセットしました
            </p>
          </div>

          <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-2 mb-2">
              <SafeIcon icon={FiAlertTriangle} className="text-yellow-400" />
              <p className="text-yellow-200 text-sm font-semibold">
                セットフェーズを終了しますか？
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs text-gray-300 mb-2">
              <span>セットフェーズ</span>
              <SafeIcon icon={FiArrowRight} />
              <span className="text-emerald-300">メインフェーズ</span>
            </div>
            <p className="text-xs text-yellow-300">
              ※ 「はい」を選択すると手札に戻せません
            </p>
          </div>

          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onConfirm}
              className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiCheckCircle} />
              はい
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onCancel}
              className="flex-1 bg-gray-600 hover:bg-gray-500 text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiX} />
              いいえ
            </motion.button>
          </div>

          <p className="text-xs text-gray-400 mt-3">
            「いいえ」を選択すると、セットフェーズを継続できます
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PhaseConfirmationModal;