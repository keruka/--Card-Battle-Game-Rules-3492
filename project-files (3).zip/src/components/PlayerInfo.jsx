import React from 'react';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiUser, FiLayers, FiArchive, FiDollarSign } = FiIcons;

const PlayerInfo = ({
  player,
  isCurrentPlayer,
  isOpponent,
  compact = false
}) => {
  return (
    <div className={`flex justify-between items-center ${compact ? 'mb-2' : 'mb-4'} ${isOpponent ? 'transform rotate-180' : ''}`}>
      <div className="flex items-center gap-2">
        <div className={`rounded-full ${isCurrentPlayer ? 'bg-emerald-400 animate-pulse' : 'bg-gray-500'} ${compact ? 'w-2 h-2' : 'w-3 h-3'}`} />
        <h3 className={`text-white font-bold flex items-center gap-1 ${compact ? 'text-sm' : 'text-lg'} ${isOpponent ? 'ml-2' : 'ml-4'}`}>
          {/* 🔧 修正: プレイヤー1のテキストをもう少し右に配置 */}
          <SafeIcon icon={FiUser} className={compact ? 'text-sm' : ''} />
          プレイヤー{isOpponent ? '2 (AI)' : '1 (あなた)'}
        </h3>
      </div>

      {/* 🔧 修正: $などの表示をもう少し左に配置 */}
      <div className={`flex items-center ${isOpponent ? 'gap-2 mr-2' : 'gap-1 mr-6'} ${compact ? 'text-xs' : 'text-sm'}`}>
        {/* 🔧 修正: プレイヤー1はmr-6でより左に配置 */}
        {player.maxCost !== undefined && (
          <div className="flex items-center gap-1 text-yellow-300">
            <SafeIcon icon={FiDollarSign} className={compact ? 'text-xs' : ''} />
            <span>{player.currentCost}/{player.maxCost}</span>
            {/* 🔧 修正: 「コスト:」を削除 */}
          </div>
        )}

        <div className="flex items-center gap-1 text-blue-300">
          <SafeIcon icon={FiLayers} className={compact ? 'text-xs' : ''} />
          <span>{player.deck.length}</span>
          {/* 🔧 修正: 「山札:」を削除 */}
        </div>

        <div className="flex items-center gap-1 text-gray-300">
          <SafeIcon icon={FiArchive} className={compact ? 'text-xs' : ''} />
          <span>{player.graveyard.length}</span>
          {/* 🔧 修正: 「捨札:」を削除 */}
        </div>
      </div>
    </div>
  );
};

export default PlayerInfo;