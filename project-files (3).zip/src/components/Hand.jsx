import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const { FiSkipForward, FiArrowRight } = FiIcons;

const Hand = ({
  cards,
  isCurrentPlayer,
  onPlayCard,
  onSetFeed,
  gamePhase,
  currentCost,
  onCardClick,
  onImageClick,
  hasSetFeed = false,
  onSkipFeedPhase,
  compact = false,
  showTitle = true,
  showCardBack = false // 🔧 修正: カード裏面表示制御を追加
}) => {
  return (
    <div className={compact ? "mt-1" : "mt-4"}>
      {/* 🔧 修正: プレイヤー1の手札テキストを削除 */}
      {showTitle && showCardBack && (
        <h4 className={`text-white font-semibold text-center ${compact ? 'text-xs mb-1' : 'text-sm mb-1'}`}>
          手札
          {(gamePhase === 'main' || gamePhase === 'set') && (
            <span className="text-yellow-300 ml-2">(利用可能コスト: {currentCost})</span>
          )}
          {gamePhase === 'set' && (
            <span className={`ml-2 ${hasSetFeed ? 'text-orange-300' : 'text-green-300'}`}>
              {hasSetFeed ? '(エサセット済み)' : '(ドラッグでエサセット)'}
            </span>
          )}
        </h4>
      )}

      {/* 🔧 修正: 手札エリアのみ（スキップボタンは親コンポーネントで管理） */}
      <div className={`flex justify-center gap-1 flex-wrap ${compact ? 'gap-0.5' : 'gap-1'}`}>
        {cards.map((card, index) => {
          let isPlayable = false;
          let isDraggable = false;

          if (gamePhase === 'set') {
            // 🔧 修正: エサセット済みかどうかに関係なく、セットフェーズでは常にドラッグ可能
            isDraggable = isCurrentPlayer;
            isPlayable = false; // クリックでのプレイは無効
          } else if (gamePhase === 'main') {
            isPlayable = isCurrentPlayer && card.cost <= currentCost;
            isDraggable = isCurrentPlayer && card.cost <= currentCost;
          }

          return (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: compact ? -5 : -10, scale: compact ? 1.02 : 1.05 }}
              className={
                // 🔧 修正: 相手の手札（showCardBack=true）の場合は縄張りサイズに
                showCardBack ? '' : (compact ? 'transform scale-75' : '')
              }
            >
              <Card
                card={card}
                inHand={true}
                isPlayable={isPlayable}
                canDrag={isDraggable}
                onPlay={() => {
                  // 🔧 修正: セットフェーズでのクリックプレイを無効化
                  if (gamePhase === 'set') {
                    // エサセットはドラッグ&ドロップのみ
                    return;
                  } else if (gamePhase === 'main') {
                    if (card.type !== 'insect') {
                      onPlayCard(card);
                    }
                  }
                }}
                gamePhase={gamePhase}
                onCardClick={() => {
                  // 🆕 相手の手札は押せないようにする
                  if (showCardBack || !isCurrentPlayer) {
                    return; // 何も反応しない
                  }
                  onCardClick(card);
                }}
                onImageClick={() => {
                  // 🆕 相手の手札は押せないようにする
                  if (showCardBack || !isCurrentPlayer) {
                    return; // 何も反応しない
                  }
                  onImageClick?.(card);
                }}
                compact={showCardBack ? false : compact}
                showBack={showCardBack}
                smallAreaSize={showCardBack}
              />
            </motion.div>
          );
        })}
      </div>

      {/* エサセット方法のヒント - プレイヤー1のタイトルなし時は非表示 */}
      {gamePhase === 'set' && !hasSetFeed && !compact && showTitle && showCardBack && !showCardBack && (
        <div className="mt-2 text-center">
          <p className="text-yellow-200 text-xs">
            💡 エサをセットするには、カードをエサ場にドラッグ&ドロップしてください
          </p>
        </div>
      )}
    </div>
  );
};

export default Hand;