import React from 'react';
import {motion} from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const {FiTarget,FiX,FiZap,FiBomb} = FiIcons;

const ExplosiveTargetModal = ({
  isOpen,
  explosiveCard,
  targetInsects,
  onSelectTarget,
  onCancel
}) => {
  if (!isOpen || !explosiveCard) return null;

  return (
    <motion.div
      initial={{opacity: 0}}
      animate={{opacity: 1}}
      exit={{opacity: 0}}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onCancel}
    >
      <motion.div
        initial={{scale: 0.8, opacity: 0}}
        animate={{scale: 1, opacity: 1}}
        exit={{scale: 0.8, opacity: 0}}
        className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-xl font-bold flex items-center gap-2">
            <SafeIcon icon={FiBomb} className="text-red-400" />
            爆熱弾の対象を選択
          </h2>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <SafeIcon icon={FiX} className="text-xl" />
          </button>
        </div>

        {/* 爆熱弾カード表示 */}
        <div className="mb-6 p-4 bg-red-900/20 border border-red-600/30 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-16 h-20 flex-shrink-0">
              <Card card={explosiveCard} compact={true} />
            </div>
            <div>
              <h3 className="text-red-300 font-bold text-lg">{explosiveCard.name}</h3>
              <p className="text-gray-300 text-sm mt-1">
                {explosiveCard.effect1_text || explosiveCard.effect_text || '選択した敵の虫に600ダメージ'}
              </p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-red-400 text-xs">コスト: {explosiveCard.cost}</span>
                <span className="text-red-400 text-xs">•</span>
                <span className="text-red-400 text-xs">ダメージ: 600</span>
                <SafeIcon icon={FiBomb} className="text-red-400 text-xs" />
              </div>
            </div>
          </div>
        </div>

        {/* 対象選択説明 */}
        <div className="mb-4 text-center">
          <p className="text-gray-300 text-sm">
            爆熱弾で攻撃する敵の虫を選択してください
          </p>
          <p className="text-red-300 text-xs mt-1">
            ※ 選択した虫に600の固定ダメージを与えます
          </p>
        </div>

        {/* ターゲット選択 */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          {targetInsects.map((insect, index) => {
            // 虫の現在体力を計算
            const maxHealth = insect.health;
            const currentHealth = insect.currentHealth !== undefined ? insect.currentHealth : maxHealth;
            const healthPercentage = maxHealth > 0 ? (currentHealth / maxHealth) * 100 : 0;
            const willBeDestroyed = currentHealth <= 600;

            return (
              <motion.div
                key={insect.id}
                initial={{opacity: 0, scale: 0.9}}
                animate={{opacity: 1, scale: 1}}
                transition={{delay: index * 0.1}}
                whileHover={{scale: 1.05}}
                whileTap={{scale: 0.95}}
                onClick={() => onSelectTarget(insect)}
                className={`cursor-pointer bg-gray-800/50 hover:bg-gray-700/50 border ${
                  willBeDestroyed 
                    ? 'border-red-400 hover:border-red-300 bg-red-900/20' 
                    : 'border-gray-600 hover:border-red-400'
                } rounded-lg p-3 transition-all duration-200`}
              >
                <div className="flex flex-col items-center">
                  {/* ムシカード */}
                  <div className="w-20 h-28 mb-2">
                    <Card card={insect} compact={true} />
                  </div>

                  {/* ムシ情報 */}
                  <div className="text-center">
                    <h4 className="text-white font-semibold text-sm">{insect.name}</h4>
                    <div className="text-xs text-gray-400 space-y-1 mt-1">
                      <div>攻撃: {insect.attack1 || insect.attack || 0}</div>
                      <div className={willBeDestroyed ? 'text-red-400 font-bold' : ''}>
                        体力: {currentHealth}/{maxHealth}
                      </div>
                      {insect.isFlipped && (
                        <div className="text-purple-400">裏向き</div>
                      )}
                    </div>

                    {/* ダメージ予測 */}
                    <div className="mt-2 p-2 bg-red-900/30 border border-red-600/30 rounded text-xs">
                      <div className="text-red-300 font-bold">
                        600ダメージ
                      </div>
                      <div className={willBeDestroyed ? 'text-red-400 font-bold' : 'text-yellow-300'}>
                        {willBeDestroyed ? '撃破される！' : `残り体力: ${Math.max(0, currentHealth - 600)}`}
                      </div>
                    </div>
                  </div>

                  {/* 選択ボタン */}
                  <motion.button
                    whileHover={{scale: 1.1}}
                    whileTap={{scale: 0.9}}
                    className={`mt-2 px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-colors ${
                      willBeDestroyed
                        ? 'bg-red-600 hover:bg-red-500 text-white'
                        : 'bg-orange-600 hover:bg-orange-500 text-white'
                    }`}
                  >
                    <SafeIcon icon={FiBomb} />
                    {willBeDestroyed ? '撃破' : '攻撃'}
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* 対象がいない場合の表示 */}
        {targetInsects.length === 0 && (
          <div className="text-center py-8">
            <SafeIcon icon={FiTarget} className="text-gray-500 text-4xl mx-auto mb-2" />
            <p className="text-gray-400">攻撃可能な敵の虫がいません</p>
          </div>
        )}

        {/* キャンセルボタン */}
        <div className="flex justify-center">
          <button
            onClick={onCancel}
            className="bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ExplosiveTargetModal;