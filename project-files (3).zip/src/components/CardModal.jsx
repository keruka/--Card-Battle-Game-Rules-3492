import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiX, FiZap, FiHeart, FiSword, FiShield, FiTarget } = FiIcons;

const CardModal = ({ card, onClose }) => {
  const modalRef = useRef(null);

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [onClose]);

  const getCardColor = () => {
    switch (card.element) {
      case 'red': return 'from-red-600 to-red-800';
      case 'blue': return 'from-blue-600 to-blue-800';
      case 'green': return 'from-green-600 to-green-800';
      case 'neutral': return 'from-gray-600 to-gray-800';
      default: return 'from-gray-600 to-gray-800';
    }
  };

  const getCardBorder = () => {
    switch (card.rarity) {
      case 'N': return 'border-gray-400';
      case 'R': return 'border-blue-400';
      case 'SR': return 'border-purple-400';
      case 'LR': return 'border-yellow-400';
      default: return 'border-gray-400';
    }
  };

  const getRarityGlow = () => {
    switch (card.rarity) {
      case 'LR': return 'shadow-2xl shadow-yellow-400/50';
      case 'SR': return 'shadow-2xl shadow-purple-400/50';
      case 'R': return 'shadow-2xl shadow-blue-400/50';
      case 'N': return 'shadow-2xl shadow-gray-400/30';
      default: return 'shadow-2xl shadow-gray-400/30';
    }
  };

  const getRarityDisplay = () => {
    switch (card.rarity) {
      case 'N': return 'ノーマル';
      case 'R': return 'レア';
      case 'SR': return 'スーパーレア';
      case 'LR': return 'レジェンダリーレア';
      default: return card.rarity || 'ノーマル';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        ref={modalRef}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-gray-900 rounded-2xl p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-2xl font-bold">{card.name}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <SafeIcon icon={FiX} className="text-2xl" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Card Image */}
          <div className="flex justify-center">
            <div className={`relative w-48 h-64 rounded-xl border-4 ${getCardBorder()} ${getRarityGlow()}`}>
              <div className={`absolute inset-0 bg-gradient-to-br ${getCardColor()} rounded-lg`} />
              
              {card.image_url && (
                <div className="absolute inset-0 rounded-lg overflow-hidden">
                  <img
                    src={card.image_url}
                    alt={card.name}
                    className="w-full h-full object-cover"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-br ${getCardColor()} opacity-40`} />
                </div>
              )}

              <div className="relative h-full p-3 flex flex-col justify-between text-white">
                {/* Cost */}
                <div className="absolute -top-2 -left-2 w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center text-lg font-bold text-black">
                  {card.cost}
                </div>

                {/* Name */}
                <div className="text-center font-bold text-lg leading-tight mt-6 bg-black/50 rounded px-2 py-1">
                  {card.name}
                </div>

                {/* Type Icon */}
                <div className="flex justify-center my-2">
                  <SafeIcon
                    icon={card.type === 'insect' ? FiZap : card.type === 'spell' ? FiSword : FiShield}
                    className="text-4xl drop-shadow-lg"
                  />
                </div>

                {/* Stats */}
                {card.type === 'insect' && (
                  <div className="space-y-2">
                    {card.attack1 && card.attack2 ? (
                      <div className="grid grid-cols-2 gap-2 text-sm bg-black/50 rounded px-2 py-1">
                        <div className="flex items-center gap-1">
                          <SafeIcon icon={FiSword} className="text-red-300" />
                          <span className="text-red-300">{card.attack1}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <SafeIcon icon={FiSword} className="text-orange-300" />
                          <span className="text-orange-300">{card.attack2}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex justify-center text-sm bg-black/50 rounded px-2 py-1">
                        <div className="flex items-center gap-1">
                          <SafeIcon icon={FiSword} className="text-red-300" />
                          <span>{card.attack1 || card.attack}</span>
                        </div>
                      </div>
                    )}
                    <div className="flex justify-center text-sm bg-black/50 rounded px-2 py-1">
                      <div className="flex items-center gap-1">
                        <SafeIcon icon={FiHeart} className="text-green-300" />
                        <span>{card.currentHealth !== undefined ? card.currentHealth : card.health}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Card Details */}
          <div className="space-y-4">
            <div className="bg-gray-800 rounded-lg p-4">
              <h3 className="text-white font-bold mb-2">基本情報</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">種類:</span>
                  <span className="text-white">
                    {card.type === 'insect' ? 'ムシ' : card.type === 'spell' ? '術' : '強化'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">コスト:</span>
                  <span className="text-yellow-300">{card.cost}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">属性:</span>
                  <span className="text-white">
                    {card.element === 'red' ? '赤' : card.element === 'blue' ? '青' : card.element === 'green' ? '緑' : '無属性'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">レアリティ:</span>
                  <span className="text-white">{getRarityDisplay()}</span>
                </div>
              </div>
            </div>

            {/* Effects */}
            <div className="bg-gray-800 rounded-lg p-4">
              <h3 className="text-white font-bold mb-2">効果</h3>
              <div className="space-y-3 text-sm">
                {card.effect1_text && (
                  <div>
                    <span className="text-red-300 font-semibold">効果1:</span>
                    <p className="text-gray-300 mt-1">{card.effect1_text}</p>
                  </div>
                )}
                {card.effect2_text && (
                  <div>
                    <span className="text-orange-300 font-semibold">効果2:</span>
                    <p className="text-gray-300 mt-1">{card.effect2_text}</p>
                  </div>
                )}
                {card.passive_effect_text && (
                  <div>
                    <span className="text-blue-300 font-semibold">常時効果:</span>
                    <p className="text-gray-300 mt-1">{card.passive_effect_text}</p>
                  </div>
                )}
                {!card.effect1_text && !card.effect2_text && !card.passive_effect_text && card.effect_text && (
                  <div>
                    <span className="text-yellow-300 font-semibold">効果:</span>
                    <p className="text-gray-300 mt-1">{card.effect_text}</p>
                  </div>
                )}
                {!card.effect1_text && !card.effect2_text && !card.passive_effect_text && !card.effect_text && (
                  <p className="text-gray-400">効果なし</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default CardModal;