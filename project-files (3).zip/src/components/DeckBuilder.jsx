import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';
import supabase from '../lib/supabase';

const { FiPlus, FiMinus, FiSave, FiTrash2, FiPlay, FiDatabase, FiShuffle, FiFilter, FiSearch } = FiIcons;

const DeckBuilder = ({ onClose, onStartGame }) => {
  const [availableCards, setAvailableCards] = useState([]);
  const [playerDeck, setPlayerDeck] = useState([]);
  const [computerDeck, setComputerDeck] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState('player');
  const [autoBuilding, setAutoBuilding] = useState(false);
  
  // 検索機能のための状態
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterElement, setFilterElement] = useState('all');

  useEffect(() => {
    loadAvailableCards();
  }, []);

  const loadAvailableCards = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('cards_mushi_a7x9k2')
        .select('*')
        .not('image_url', 'is', null)
        .neq('image_url', '')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAvailableCards(data || []);
    } catch (error) {
      console.error('Error loading cards:', error);
      alert('カードの読み込みに失敗しました: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const addCardToDeck = (card) => {
    const deckType = selectedTab;
    const currentDeck = deckType === 'player' ? playerDeck : computerDeck;
    const setDeck = deckType === 'player' ? setPlayerDeck : setComputerDeck;

    // Check if deck is full
    if (currentDeck.length >= 20) {
      alert('デッキは最大20枚までです');
      return;
    }

    // Check if card already exists twice
    const cardCount = currentDeck.filter(c => c.id === card.id).length;
    if (cardCount >= 2) {
      alert('同じカードは2枚までしか入れられません');
      return;
    }

    setDeck([...currentDeck, { ...card, deckId: Date.now() + Math.random() }]);
  };

  const removeCardFromDeck = (card) => {
    const deckType = selectedTab;
    const currentDeck = deckType === 'player' ? playerDeck : computerDeck;
    const setDeck = deckType === 'player' ? setPlayerDeck : setComputerDeck;

    setDeck(currentDeck.filter(c => c.id !== card.id));
  };

  const clearDeck = () => {
    const deckType = selectedTab;
    if (!confirm(`${deckType === 'player' ? 'プレイヤー' : 'コンピュータ'}のデッキをクリアしますか？`)) {
      return;
    }
    
    const setDeck = deckType === 'player' ? setPlayerDeck : setComputerDeck;
    setDeck([]);
  };

  const autoFillDeck = () => {
    setAutoBuilding(true);
    const deckType = selectedTab;
    const currentDeck = deckType === 'player' ? playerDeck : computerDeck;
    const setDeck = deckType === 'player' ? setPlayerDeck : setComputerDeck;

    const newDeck = [...currentDeck];
    const shuffledCards = [...availableCards].sort(() => Math.random() - 0.5);

    // Add cards until deck is full (20 cards)
    for (let i = 0; i < shuffledCards.length && newDeck.length < 20; i++) {
      const card = shuffledCards[i];
      const cardCount = newDeck.filter(c => c.id === card.id).length;

      // Add up to 2 copies of each card
      if (cardCount < 2) {
        newDeck.push({ ...card, deckId: Date.now() + Math.random() + i });

        // Try to add a second copy if deck still has space
        if (newDeck.length < 20 && cardCount === 0) {
          newDeck.push({ ...card, deckId: Date.now() + Math.random() + i + 1000 });
        }
      }
    }

    setDeck(newDeck.slice(0, 20)); // Ensure exactly 20 cards
    setAutoBuilding(false);
  };

  const getCardCount = (card, deck) => {
    return deck.filter(c => c.id === card.id).length;
  };

  const canAddCard = (card, deck) => {
    return deck.length < 20 && getCardCount(card, deck) < 2;
  };

  const getDeckStats = (deck) => {
    const insects = deck.filter(c => c.type === 'insect').length;
    const spells = deck.filter(c => c.type === 'spell').length;
    const enhancements = deck.filter(c => c.type === 'enhancement').length;
    const totalCost = deck.reduce((sum, c) => sum + (c.cost || 0), 0);
    const avgCost = deck.length > 0 ? (totalCost / deck.length).toFixed(1) : 0;

    return { insects, spells, enhancements, totalCost, avgCost };
  };

  const canStartGame = () => {
    return playerDeck.length === 20 && computerDeck.length === 20;
  };

  const handleStartGame = () => {
    if (!canStartGame()) {
      alert('両方のデッキが20枚ちょうどである必要があります');
      return;
    }
    
    onStartGame({
      playerDeck: playerDeck,
      computerDeck: computerDeck
    });
  };

  // フィルタリングされたカード一覧を取得
  const getFilteredCards = () => {
    return availableCards.filter(card => {
      // 検索語でフィルタリング
      const nameMatch = card.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      // カードタイプでフィルタリング
      const typeMatch = filterType === 'all' || card.type === filterType;
      
      // 属性でフィルタリング
      const elementMatch = filterElement === 'all' || card.element === filterElement;
      
      return nameMatch && typeMatch && elementMatch;
    });
  };

  const DeckStats = ({ deck, title }) => {
    const stats = getDeckStats(deck);
    return (
      <div className="bg-gray-800 rounded-lg p-3 mb-4">
        <h4 className="text-white font-bold mb-2">{title} ({deck.length}/20)</h4>
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-300">
          <div>虫: {stats.insects}枚</div>
          <div>術: {stats.spells}枚</div>
          <div>強化: {stats.enhancements}枚</div>
          <div>平均コスト: {stats.avgCost}</div>
        </div>
        <div className="mt-2">
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-300 ${
                deck.length === 20 ? 'bg-green-500' : 'bg-yellow-500'
              }`} 
              style={{ width: `${(deck.length / 20) * 100}%` }} 
            />
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
        <div className="text-white text-xl">カード読み込み中...</div>
      </div>
    );
  }

  const filteredCards = getFilteredCards();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/90 flex items-center justify-center z-50"
    >
      <div className="bg-gray-900 rounded-xl p-6 max-w-7xl w-full mx-4 max-h-[95vh] overflow-hidden">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-2xl font-bold">デッキ構築</h2>
          <div className="flex gap-2">
            <button
              onClick={handleStartGame}
              disabled={!canStartGame()}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-6 py-2 rounded flex items-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiPlay} />
              ゲーム開始
            </button>
            <button
              onClick={onClose}
              className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded transition-colors"
            >
              閉じる
            </button>
          </div>
        </div>

        <div className="h-[75vh] flex gap-6">
          {/* 左側: カード一覧 */}
          <div className="w-1/2 h-full overflow-hidden flex flex-col">
            <div className="mb-4 flex items-center gap-4">
              <h3 className="text-white text-lg font-bold">
                カード一覧 ({filteredCards.length}枚)
              </h3>
              <div className="flex-1 flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="カード名で検索..."
                    className="w-full bg-gray-800 border border-gray-700 rounded pl-10 pr-3 py-1 text-white text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                  <SafeIcon
                    icon={FiSearch}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                  />
                </div>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="bg-gray-800 border border-gray-700 rounded pl-2 pr-8 py-1 text-white text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="all">全タイプ</option>
                  <option value="insect">虫</option>
                  <option value="spell">術</option>
                  <option value="enhancement">強化</option>
                </select>
                <select
                  value={filterElement}
                  onChange={(e) => setFilterElement(e.target.value)}
                  className="bg-gray-800 border border-gray-700 rounded pl-2 pr-8 py-1 text-white text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="all">全属性</option>
                  <option value="red">赤</option>
                  <option value="blue">青</option>
                  <option value="green">緑</option>
                  <option value="neutral">無</option>
                </select>
              </div>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 h-full overflow-y-auto flex-1">
              <div className="grid grid-cols-4 gap-4">
                {filteredCards.map((card) => (
                  <div
                    key={card.id}
                    onClick={() => addCardToDeck(card)}
                    className={`cursor-pointer transition-all duration-200 transform hover:scale-105 ${
                      !canAddCard(card, selectedTab === 'player' ? playerDeck : computerDeck)
                        ? 'opacity-50 cursor-not-allowed'
                        : 'hover:ring-2 hover:ring-blue-500'
                    }`}
                  >
                    <Card card={card} />
                    <div className="mt-1 bg-gray-700 px-2 py-1 rounded flex justify-between items-center">
                      <span className="text-xs text-gray-300">
                        {card.type === 'insect' ? '虫' : card.type === 'spell' ? '術' : '強化'}
                      </span>
                      <span className="text-xs font-medium text-yellow-300">
                        コスト: {card.cost}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              {filteredCards.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  検索条件に一致するカードがありません
                </div>
              )}
            </div>
          </div>

          {/* 右側: デッキ構築エリア */}
          <div className="w-1/2 h-full overflow-hidden flex flex-col">
            {/* タブ切り替え */}
            <div className="flex mb-4">
              <button
                onClick={() => setSelectedTab('player')}
                className={`flex-1 py-2 px-4 rounded-l-lg font-semibold transition-colors ${
                  selectedTab === 'player'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                プレイヤーデッキ
              </button>
              <button
                onClick={() => setSelectedTab('computer')}
                className={`flex-1 py-2 px-4 rounded-r-lg font-semibold transition-colors ${
                  selectedTab === 'computer'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                コンピュータデッキ
              </button>
            </div>

            {/* デッキ内容 */}
            <div className="bg-gray-800 rounded-lg p-4 h-full overflow-y-auto flex-1">
              <div className="flex justify-between items-center mb-4">
                <DeckStats
                  deck={selectedTab === 'player' ? playerDeck : computerDeck}
                  title={selectedTab === 'player' ? 'プレイヤーデッキ' : 'コンピュータデッキ'}
                />
                <div className="flex gap-2">
                  <button
                    onClick={autoFillDeck}
                    disabled={autoBuilding}
                    className="bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 text-white px-3 py-1 rounded text-sm flex items-center gap-1"
                  >
                    <SafeIcon icon={FiShuffle} />
                    自動構築
                  </button>
                  <button
                    onClick={clearDeck}
                    className="bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded text-sm flex items-center gap-1"
                  >
                    <SafeIcon icon={FiTrash2} />
                    クリア
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                {(selectedTab === 'player' ? playerDeck : computerDeck).map((card) => (
                  <div
                    key={card.deckId || card.id}
                    onClick={() => removeCardFromDeck(card)}
                    className="cursor-pointer transition-all duration-200 transform hover:scale-105 hover:ring-2 hover:ring-red-500"
                  >
                    <Card card={card} />
                    <div className="mt-1 bg-gray-700 px-2 py-1 rounded flex justify-between items-center">
                      <span className="text-xs text-gray-300">
                        {card.type === 'insect' ? '虫' : card.type === 'spell' ? '術' : '強化'}
                      </span>
                      <span className="text-xs font-medium text-yellow-300">
                        コスト: {card.cost}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              
              {(selectedTab === 'player' ? playerDeck : computerDeck).length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  左からカードをクリックしてデッキに追加してください
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DeckBuilder;