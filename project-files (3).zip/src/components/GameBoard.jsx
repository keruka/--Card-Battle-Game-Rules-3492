import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import PlayerArea from './PlayerArea';
import GameLog from './GameLog';
import CardManager from './CardManager';
import DeckBuilder from './DeckBuilder';
import { useGame } from '../hooks/useGame';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiPlay, FiHome, FiDatabase, FiLayers, FiMessageSquare, FiSword, FiShield, FiUser, FiArchive, FiDollarSign } = FiIcons;

// 統合されたモーダルコンポーネント
const GameModals = ({
  gameState,
  currentPlayer,
  gamePhase,
  turnCount,
  showPhaseConfirmation,
  lastSetCard,
  handlePhaseConfirmation,
  showSkipFeedConfirmation,
  setShowSkipFeedConfirmation,
  skipFeedPhase,
  showEnhancementTargetModal,
  setShowEnhancementTargetModal,
  pendingEnhancementCard,
  setPendingEnhancementCard,
  applyEnhancementToInsect,
  showExplosiveTargetModal,
  setShowExplosiveTargetModal,
  pendingExplosiveCard,
  setPendingExplosiveCard,
  applyExplosiveEffect,
  showRainbowBridgeTargetModal,
  setShowRainbowBridgeTargetModal,
  pendingRainbowBridgeCard,
  setPendingRainbowBridgeCard,
  applyRainbowBridgeEffect,
  showColorSelectionModal,
  setShowColorSelectionModal,
  pendingColorChangeCard,
  setPendingColorChangeCard,
  selectedColor,
  setSelectedColor,
  applyColorChangeEnhancement,
  playCard
}) => {
  // フェーズ確認モーダル
  const PhaseConfirmationModal = () => {
    if (!showPhaseConfirmation) return null;
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => handlePhaseConfirmation(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-md mx-4 border border-yellow-400/30" 
          onClick={e => e.stopPropagation()}
        >
          <div className="text-center">
            <SafeIcon icon={FiPlay} className="text-yellow-400 text-4xl mx-auto mb-2" />
            <h3 className="text-white text-xl font-bold mb-2">エサセット完了</h3>
            <p className="text-gray-300 text-sm">「{lastSetCard?.name}」をエサ場にセットしました</p>
            
            <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4 my-6">
              <p className="text-yellow-200 text-sm font-semibold mb-2">セットフェーズを終了しますか？</p>
              <p className="text-xs text-yellow-300">※ 「はい」を選択すると手札に戻せません</p>
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={() => handlePhaseConfirmation(true)} 
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
              >
                はい
              </button>
              <button 
                onClick={() => handlePhaseConfirmation(false)} 
                className="flex-1 bg-gray-600 hover:bg-gray-500 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
              >
                いいえ
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  // スキップ確認モーダル
  const SkipFeedConfirmationModal = () => {
    if (!showSkipFeedConfirmation) return null;
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => setShowSkipFeedConfirmation(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-md mx-4 border border-orange-400/30" 
          onClick={e => e.stopPropagation()}
        >
          <div className="text-center">
            <SafeIcon icon={FiPlay} className="text-orange-400 text-4xl mx-auto mb-2" />
            <h3 className="text-white text-xl font-bold mb-2">エサセットをスキップ</h3>
            <p className="text-gray-300 text-sm">エサ場にカードを置かずにメインフェーズに移行します</p>
            
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => {
                  setShowSkipFeedConfirmation(false);
                  skipFeedPhase();
                }} 
                className="flex-1 bg-orange-600 hover:bg-orange-500 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
              >
                はい、スキップ
              </button>
              <button 
                onClick={() => setShowSkipFeedConfirmation(false)} 
                className="flex-1 bg-gray-600 hover:bg-gray-500 text-white px-4 py-3 rounded-lg font-semibold transition-colors"
              >
                いいえ、戻る
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  // 強化対象選択モーダル
  const EnhancementTargetModal = () => {
    if (!showEnhancementTargetModal || !pendingEnhancementCard) return null;
    const targetInsects = gameState?.[`player${currentPlayer}`]?.field.filter(card => card.type === 'insect') || [];
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => setShowEnhancementTargetModal(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto" 
          onClick={e => e.stopPropagation()}
        >
          <h2 className="text-white text-xl font-bold mb-6 flex items-center gap-2">
            <SafeIcon icon={FiPlay} className="text-yellow-400" />
            強化対象を選択
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {targetInsects.map((insect, index) => (
              <motion.div 
                key={insect.id} 
                whileHover={{ scale: 1.05 }} 
                whileTap={{ scale: 0.95 }} 
                onClick={() => {
                  setShowEnhancementTargetModal(false);
                  if (pendingColorChangeCard && selectedColor) {
                    applyColorChangeEnhancement?.(pendingColorChangeCard, insect, selectedColor);
                    setPendingColorChangeCard(null);
                    setSelectedColor(null);
                  } else {
                    applyEnhancementToInsect?.(pendingEnhancementCard, insect);
                  }
                  setPendingEnhancementCard(null);
                }} 
                className="cursor-pointer bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded-lg p-3 transition-all duration-200"
              >
                <div className="text-center">
                  <h4 className="text-white font-semibold text-sm">{insect.name}</h4>
                  <div className="text-xs text-gray-400 space-y-1 mt-1">
                    <div>攻撃: {insect.attack1 || insect.attack || 0}</div>
                    <div>体力: {insect.currentHealth || insect.health}/{insect.health}</div>
                  </div>
                  <button className="mt-2 bg-yellow-600 hover:bg-yellow-500 text-white px-3 py-1 rounded text-xs font-semibold transition-colors">
                    選択
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="flex justify-center">
            <button 
              onClick={() => setShowEnhancementTargetModal(false)} 
              className="bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
            >
              キャンセル
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  // 属性選択モーダル
  const ColorSelectionModal = () => {
    if (!showColorSelectionModal || !pendingColorChangeCard) return null;
    const colorOptions = [
      { value: 'red', name: '赤', bgColor: 'bg-red-600', icon: '🔥' },
      { value: 'blue', name: '青', bgColor: 'bg-blue-600', icon: '💧' },
      { value: 'green', name: '緑', bgColor: 'bg-green-600', icon: '🌿' }
    ];
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => setShowColorSelectionModal(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-md w-full mx-4" 
          onClick={e => e.stopPropagation()}
        >
          <h2 className="text-white text-xl font-bold mb-6">玉虫色の羽化 - 属性選択</h2>
          
          <div className="space-y-3 mb-6">
            {colorOptions.map((color) => (
              <button 
                key={color.value} 
                onClick={() => {
                  setShowColorSelectionModal(false);
                  setSelectedColor(color.value);
                  if (pendingColorChangeCard) {
                    const fieldInsects = gameState?.[`player${currentPlayer}`]?.field.filter(card => card.type === 'insect') || [];
                    if (fieldInsects.length === 1) {
                      applyColorChangeEnhancement?.(pendingColorChangeCard, fieldInsects[0], color.value);
                      setPendingColorChangeCard(null);
                      setSelectedColor(null);
                    } else {
                      setPendingEnhancementCard(pendingColorChangeCard);
                      setShowEnhancementTargetModal(true);
                    }
                  }
                }} 
                className={`w-full ${color.bgColor} hover:opacity-80 text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200`}
              >
                <span className="text-xl">{color.icon}</span>
                <span>{color.name}属性に変更</span>
              </button>
            ))}
          </div>
          
          <button 
            onClick={() => setShowColorSelectionModal(false)} 
            className="w-full bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </motion.div>
      </motion.div>
    );
  };

  // 爆熱弾対象選択モーダル
  const ExplosiveTargetModal = () => {
    if (!showExplosiveTargetModal || !pendingExplosiveCard) return null;
    const opponentPlayer = currentPlayer === 1 ? 2 : 1;
    const opponentState = gameState?.[`player${opponentPlayer}`];
    const targetInsects = opponentState?.field?.filter(card => card.type === 'insect' && !card.isFlipped) || [];
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => setShowExplosiveTargetModal(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto" 
          onClick={e => e.stopPropagation()}
        >
          <h2 className="text-white text-xl font-bold mb-6 flex items-center gap-2">
            <SafeIcon icon={FiSword} className="text-red-400" />
            爆熱弾の対象を選択
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {targetInsects.map((insect, index) => {
              const currentHealth = insect.currentHealth !== undefined ? insect.currentHealth : insect.health;
              const willBeDestroyed = currentHealth <= 600;
              return (
                <motion.div 
                  key={insect.id} 
                  whileHover={{ scale: 1.05 }} 
                  whileTap={{ scale: 0.95 }} 
                  onClick={() => {
                    setShowExplosiveTargetModal(false);
                    if (pendingExplosiveCard && insect) {
                      applyExplosiveEffect(currentPlayer, pendingExplosiveCard, insect);
                      playCard(pendingExplosiveCard);
                    }
                    setPendingExplosiveCard(null);
                  }} 
                  className={`cursor-pointer bg-gray-800/50 hover:bg-gray-700/50 border ${willBeDestroyed ? 'border-red-400' : 'border-gray-600'} rounded-lg p-3 transition-all duration-200`}
                >
                  <div className="text-center">
                    <h4 className="text-white font-semibold text-sm">{insect.name}</h4>
                    <div className="text-xs text-gray-400 space-y-1 mt-1">
                      <div>体力: {currentHealth}/{insect.health}</div>
                    </div>
                    <div className="mt-2 p-2 bg-red-900/30 border border-red-600/30 rounded text-xs">
                      <div className="text-red-300 font-bold">600ダメージ</div>
                      <div className={willBeDestroyed ? 'text-red-400 font-bold' : 'text-yellow-300'}>
                        {willBeDestroyed ? '撃破される！' : `残り体力: ${Math.max(0, currentHealth - 600)}`}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
          
          <button 
            onClick={() => setShowExplosiveTargetModal(false)} 
            className="w-full bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </motion.div>
      </motion.div>
    );
  };

  // 虹の架け橋対象選択モーダル
  const RainbowBridgeTargetModal = () => {
    if (!showRainbowBridgeTargetModal || !pendingRainbowBridgeCard) return null;
    const targetInsects = gameState?.[`player${currentPlayer}`]?.graveyard?.filter(card => card.type === 'insect') || [];
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" 
        onClick={() => setShowRainbowBridgeTargetModal(false)}
      >
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          className="bg-gray-900 rounded-2xl p-6 max-w-4xl w-full mx-4 max-h-[80vh] overflow-y-auto" 
          onClick={e => e.stopPropagation()}
        >
          <h2 className="text-white text-xl font-bold mb-6 flex items-center gap-2">
            <SafeIcon icon={FiHome} className="text-blue-400" />
            虹の架け橋 - 蘇生対象を選択
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
            {targetInsects.map((insect, index) => (
              <motion.div 
                key={insect.id} 
                whileHover={{ scale: 1.05 }} 
                whileTap={{ scale: 0.95 }} 
                onClick={() => {
                  setShowRainbowBridgeTargetModal(false);
                  if (pendingRainbowBridgeCard && insect) {
                    applyRainbowBridgeEffect(currentPlayer, pendingRainbowBridgeCard, insect);
                    playCard(pendingRainbowBridgeCard);
                  }
                  setPendingRainbowBridgeCard(null);
                }} 
                className="cursor-pointer bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-blue-400 rounded-lg p-3 transition-all duration-200"
              >
                <div className="text-center">
                  <h4 className="text-white font-semibold text-sm">{insect.name}</h4>
                  <div className="text-xs text-gray-400 space-y-1 mt-1">
                    <div>攻撃: {insect.attack1 || insect.attack || 0}</div>
                    <div>体力: {insect.health}</div>
                    <div>属性: {insect.element === 'red' ? '赤' : insect.element === 'blue' ? '青' : insect.element === 'green' ? '緑' : '無'}</div>
                  </div>
                  <button className="mt-2 bg-blue-600 hover:bg-blue-500 text-white px-3 py-1 rounded text-xs font-semibold transition-colors">
                    蘇生
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          
          {targetInsects.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-400">捨札に蘇生可能な虫がいません</p>
            </div>
          )}
          
          <button 
            onClick={() => setShowRainbowBridgeTargetModal(false)} 
            className="w-full bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </motion.div>
      </motion.div>
    );
  };

  return (
    <>
      <PhaseConfirmationModal />
      <SkipFeedConfirmationModal />
      <EnhancementTargetModal />
      <ColorSelectionModal />
      <ExplosiveTargetModal />
      <RainbowBridgeTargetModal />
    </>
  );
};

// 統合されたカード表示コンポーネント
const CardImageModal = ({ card, onClose }) => {
  if (!card) return null;
  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4" 
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.6, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }} 
        className="relative max-w-xs w-full" 
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute -top-3 -right-3 w-8 h-8 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center text-white shadow-lg z-10"
        >
          <SafeIcon icon={FiPlay} className="text-sm" />
        </button>
        
        <div className="w-full aspect-[3/4] rounded-xl border-3 border-gray-400 overflow-hidden">
          {card.image_url ? (
            <img src={card.image_url} alt={card.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gray-700 flex items-center justify-center text-white">
              <div className="text-center">
                <h2 className="text-lg font-bold">{card.name}</h2>
                <p className="text-sm opacity-75">画像なし</p>
              </div>
            </div>
          )}
        </div>
        
        <p className="mt-3 text-center text-gray-300 text-xs">ESCキーまたは外側をクリックで閉じる</p>
      </motion.div>
    </motion.div>
  );
};

// TurnIndicator統合コンポーネント
const TurnIndicator = ({ 
  currentPlayer, 
  gamePhase, 
  turnCount, 
  onEndTurn, 
  isAIProcessing, 
  isTurnTransitioning, 
  territoryAttackStatus,
  compact = false
}) => {
  const getPhaseText = () => {
    switch (gamePhase) {
      case 'draw': return 'ドローフェーズ';
      case 'set': return 'セットフェーズ';
      case 'main': return 'メインフェーズ';
      case 'end': return 'エンドフェーズ';
      default: return 'ターン準備中';
    }
  };

  const getPhaseColor = () => {
    switch (gamePhase) {
      case 'draw': return 'text-blue-300';
      case 'set': return 'text-yellow-300';
      case 'main': return 'text-green-300';
      case 'end': return 'text-red-300';
      default: return 'text-gray-300';
    }
  };

  const isPlayer2Turn = currentPlayer === 2;
  const canEndTurn = currentPlayer === 1 && !isAIProcessing && !isTurnTransitioning && gamePhase === 'main';
  const enemyAttackCount = territoryAttackStatus?.enemyAttackCount || 0;
  const canEnemyAttack = territoryAttackStatus?.canEnemyAttack !== false;

  if (compact) {
    return (
      <div className="flex flex-col gap-2">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-black/40 backdrop-blur-md rounded-xl px-4 py-2"
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isTurnTransitioning ? 'bg-yellow-400 animate-pulse' : isPlayer2Turn ? 'bg-red-400 animate-pulse' : 'bg-blue-400 animate-pulse'}`} />
            <span className="text-white font-bold text-sm">
              プレイヤー{currentPlayer} {isPlayer2Turn && <span className="text-red-300 ml-1">(AI)</span>}
            </span>
            <div className="h-3 w-px bg-gray-600" />
            <SafeIcon icon={FiPlay} className={`${getPhaseColor()} text-sm`} />
            <span className={`font-semibold text-sm ${getPhaseColor()}`}>
              {getPhaseText()}
            </span>
            <div className="h-3 w-px bg-gray-600" />
            <span className="text-yellow-300 text-sm">ターン{turnCount}</span>
          </div>
        </motion.div>

        {canEndTurn && (
          <button
            onClick={onEndTurn}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-3 py-2 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200 text-sm"
          >
            <SafeIcon icon={FiPlay} />
            ターン終了
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-black/40 backdrop-blur-md rounded-xl px-6 py-3"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isTurnTransitioning ? 'bg-yellow-400 animate-pulse' : isPlayer2Turn ? 'bg-red-400 animate-pulse' : 'bg-blue-400 animate-pulse'}`} />
            <SafeIcon icon={FiPlay} className="text-emerald-400" />
            <span className="text-white font-bold">
              プレイヤー {currentPlayer} のターン {isPlayer2Turn && <span className="text-red-300 ml-1">(AI)</span>}
            </span>
          </div>
          
          <div className="h-4 w-px bg-gray-600" />
          
          <div className="flex items-center gap-2">
            <SafeIcon icon={FiPlay} className={getPhaseColor()} />
            <span className={`font-semibold ${getPhaseColor()}`}>
              {getPhaseText()}
            </span>
          </div>
          
          <div className="h-4 w-px bg-gray-600" />
          
          <div className="flex items-center gap-1 text-yellow-300">
            <span className="text-sm font-medium">ターン {turnCount}</span>
          </div>
          
          {isPlayer2Turn && gamePhase === 'main' && (
            <>
              <div className="h-4 w-px bg-gray-600" />
              <div className="flex items-center gap-2">
                <SafeIcon icon={FiSword} className={canEnemyAttack ? 'text-red-400 animate-pulse' : 'text-gray-500'} />
                <span className={`text-xs font-medium ${canEnemyAttack ? 'text-red-300' : 'text-gray-400'}`}>
                  攻撃: {enemyAttackCount}/1
                </span>
              </div>
            </>
          )}
        </div>
      </motion.div>

      {canEndTurn && (
        <button
          onClick={onEndTurn}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-4 py-2 rounded-lg font-semibold flex items-center gap-2 transition-all duration-200"
        >
          <SafeIcon icon={FiPlay} />
          ターン終了
        </button>
      )}
    </div>
  );
};

const GameBoard = () => {
  const {
    gameState,
    currentPlayer,
    gamePhase,
    turnCount,
    gameLog,
    initializeGame,
    initializeGameWithDecks,
    endTurn,
    playCard,
    attackWithInsect,
    setFeed,
    drawCard,
    isGameOver,
    winner,
    returnCardToHand,
    isAIProcessing,
    isTurnTransitioning,
    gameSessionId,
    getTurnHistory,
    showPhaseConfirmation,
    lastSetCard,
    handlePhaseConfirmation,
    skipFeedPhase,
    applyEnhancementToInsect,
    getTerritoryAttackStatus,
    // 🆕 弱体化効果関連の関数を公開
    getDebuffStatus,
    getEffectiveAttackPower,
    // 🆕 強化効果関連の関数を公開
    getEffectiveMaxHealth,
    // 🆕 飛蝗の凶相効果関連の関数を公開
    getLocustSpellStatus,
    // 🆕 塵芥虫の爆熱弾効果関連の関数を公開
    applyExplosiveEffect,
    // 🆕 虹の架け橋効果関連の関数を公開
    applyRainbowBridgeEffect,
    // 🆕 玉虫色の羽化効果関連の関数を公開
    applyColorChangeEnhancement,
    // 🆕 ナミアゲハの挑発効果関連の関数を公開
    getTauntStatus,
    // 🔧 修正: 擬態効果関連の関数を公開
    getMimicryStatus,
    // 🆕 擬態効果の強制リフレッシュ用状態
    mimicryRefresh
  } = useGame();

  const [gameStarted, setGameStarted] = useState(false);
  const [showCardManager, setShowCardManager] = useState(false);
  const [showDeckBuilder, setShowDeckBuilder] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);
  const [selectedImageCard, setSelectedImageCard] = useState(null);
  const [showGameLog, setShowGameLog] = useState(false);
  const [showSkipFeedConfirmation, setShowSkipFeedConfirmation] = useState(false);
  const [showEnhancementTargetModal, setShowEnhancementTargetModal] = useState(false);
  const [pendingEnhancementCard, setPendingEnhancementCard] = useState(null);
  const [showExplosiveTargetModal, setShowExplosiveTargetModal] = useState(false);
  const [pendingExplosiveCard, setPendingExplosiveCard] = useState(null);
  const [showRainbowBridgeTargetModal, setShowRainbowBridgeTargetModal] = useState(false);
  const [pendingRainbowBridgeCard, setPendingRainbowBridgeCard] = useState(null);
  const [showColorSelectionModal, setShowColorSelectionModal] = useState(false);
  const [pendingColorChangeCard, setPendingColorChangeCard] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  
  const territoryAttackStatus = getTerritoryAttackStatus ? getTerritoryAttackStatus() : null;

  useEffect(() => {
    if (!gameStarted && !gameState) {
      handleStartGame();
    }
  }, []);

  const handleStartGame = () => {
    initializeGame();
    setGameStarted(true);
  };

  const handleStartGameWithDecks = (decks) => {
    initializeGameWithDecks(decks.playerDeck, decks.computerDeck);
    setGameStarted(true);
    setShowDeckBuilder(false);
  };

  const handleReturnHome = () => {
    setGameStarted(false);
    initializeGame();
  };

  const handleCardClick = (card) => {
    setSelectedCard(card);
  };

  const handleImageClick = (card) => {
    setSelectedImageCard(card);
  };

  const handleSkipFeedPhase = () => {
    setShowSkipFeedConfirmation(true);
  };

  const handleAttackTarget = ({ attacker, target, attackType }) => {
    if (target === 'territory') {
      attackWithInsect(attacker, attackType);
    } else {
      attackWithInsect(attacker, attackType, target);
    }
  };

  const handleSpellToGraveyard = (card) => {
    if (card.name && card.name.includes('虹の架け橋')) {
      const currentPlayerState = gameState?.[`player${currentPlayer}`];
      if (!currentPlayerState) return;
      
      const graveyardInsects = currentPlayerState.graveyard.filter(card => card.type === 'insect');
      if (graveyardInsects.length === 0) {
        playCard(card);
        return;
      }
      
      setPendingRainbowBridgeCard(card);
      setShowRainbowBridgeTargetModal(true);
      return;
    }
    
    if (card.name && card.name.includes('塵芥虫の爆熱弾')) {
      const opponentPlayer = currentPlayer === 1 ? 2 : 1;
      const opponentState = gameState?.[`player${opponentPlayer}`];
      const enemyInsects = opponentState?.field?.filter(card => card.type === 'insect' && !card.isFlipped) || [];
      
      if (enemyInsects.length === 0) {
        playCard(card);
        return;
      }
      
      setPendingExplosiveCard(card);
      setShowExplosiveTargetModal(true);
      return;
    }
    
    playCard(card);
  };

  const handleBreathOfInsectsDrop = (card) => {
    console.log('🌪️ 蟲の息吹が捨札にドロップされました:', card.name);
    playCard(card);
  };

  const handleEnhancementDrop = (enhancementCard) => {
    const currentPlayerState = gameState?.[`player${currentPlayer}`];
    if (!currentPlayerState) return;
    
    const fieldInsects = currentPlayerState.field.filter(card => card.type === 'insect');
    if (fieldInsects.length === 0) {
      return;
    }
    
    if (enhancementCard.name && enhancementCard.name.includes('玉虫色の羽化')) {
      setPendingColorChangeCard(enhancementCard);
      setShowColorSelectionModal(true);
      return;
    }
    
    if (fieldInsects.length === 1) {
      applyEnhancementToInsect?.(enhancementCard, fieldInsects[0]);
    } else {
      setPendingEnhancementCard(enhancementCard);
      setShowEnhancementTargetModal(true);
    }
  };

  const turnHistory = getTurnHistory();

  if (!gameStarted) {
    return (
      <DndProvider backend={HTML5Backend}>
        <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/40 backdrop-blur-md rounded-3xl p-12 text-center max-w-md mx-4"
          >
            <h1 className="text-4xl font-bold text-white mb-6">蟲神器</h1>
            <p className="text-gray-300 mb-8 leading-relaxed">
              完全なターン管理システム搭載<br />
              敵攻撃制限・縄張り攻撃判定機能付きカードゲーム
            </p>
            
            <div className="space-y-4">
              <button
                onClick={handleStartGame}
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-8 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200"
              >
                <SafeIcon icon={FiPlay} />
                クイックゲーム開始
              </button>
              
              <button
                onClick={() => setShowDeckBuilder(true)}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-8 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200"
              >
                <SafeIcon icon={FiLayers} />
                デッキ構築
              </button>
              
              <button
                onClick={() => setShowCardManager(true)}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white px-8 py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all duration-200"
              >
                <SafeIcon icon={FiDatabase} />
                カード管理
              </button>
            </div>
          </motion.div>

          {showCardManager && (
            <CardManager onClose={() => setShowCardManager(false)} />
          )}

          {showDeckBuilder && (
            <DeckBuilder onClose={() => setShowDeckBuilder(false)} onStartGame={handleStartGameWithDecks} />
          )}
        </div>
      </DndProvider>
    );
  }

  return (
    <DndProvider backend={HTML5Backend}>
      {/* 🔧 修正: 全体背景 - プレイヤー2の背景を上に移動 */}
      <div 
        className="min-h-screen relative" 
        style={{
          backgroundImage: 'url("https://quest-media-storage-bucket.s3.us-east-2.amazonaws.com/1751765408013-78492e83d7280f8faa8806f494c49eb6.webp")',
          backgroundSize: '150% 150%',
          backgroundPosition: 'center top', // 🔧 修正: 背景を上に移動
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          transform: 'rotate(180deg)'
        }}
      >
        {/* 🔧 修正: コンテンツエリア（背景の上に表示、回転を戻す） */}
        <div className="min-h-screen" style={{ transform: 'rotate(180deg)' }}>
          <div className="p-1 max-w-screen-2xl mx-auto">
            <div className="h-screen flex flex-col">
              {/* 統合されたモーダル */}
              <GameModals
                gameState={gameState}
                currentPlayer={currentPlayer}
                gamePhase={gamePhase}
                turnCount={turnCount}
                showPhaseConfirmation={showPhaseConfirmation}
                lastSetCard={lastSetCard}
                handlePhaseConfirmation={handlePhaseConfirmation}
                showSkipFeedConfirmation={showSkipFeedConfirmation}
                setShowSkipFeedConfirmation={setShowSkipFeedConfirmation}
                skipFeedPhase={skipFeedPhase}
                showEnhancementTargetModal={showEnhancementTargetModal}
                setShowEnhancementTargetModal={setShowEnhancementTargetModal}
                pendingEnhancementCard={pendingEnhancementCard}
                setPendingEnhancementCard={setPendingEnhancementCard}
                applyEnhancementToInsect={applyEnhancementToInsect}
                showExplosiveTargetModal={showExplosiveTargetModal}
                setShowExplosiveTargetModal={setShowExplosiveTargetModal}
                pendingExplosiveCard={pendingExplosiveCard}
                setPendingExplosiveCard={setPendingExplosiveCard}
                applyExplosiveEffect={applyExplosiveEffect}
                showRainbowBridgeTargetModal={showRainbowBridgeTargetModal}
                setShowRainbowBridgeTargetModal={setShowRainbowBridgeTargetModal}
                pendingRainbowBridgeCard={pendingRainbowBridgeCard}
                setPendingRainbowBridgeCard={setPendingRainbowBridgeCard}
                applyRainbowBridgeEffect={applyRainbowBridgeEffect}
                showColorSelectionModal={showColorSelectionModal}
                setShowColorSelectionModal={setShowColorSelectionModal}
                pendingColorChangeCard={pendingColorChangeCard}
                setPendingColorChangeCard={setPendingColorChangeCard}
                selectedColor={selectedColor}
                setSelectedColor={setSelectedColor}
                applyColorChangeEnhancement={applyColorChangeEnhancement}
                playCard={playCard}
              />

              {/* ゲーム終了モーダル */}
              {isGameOver && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
                >
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="bg-black/80 backdrop-blur-md rounded-3xl p-8 text-center max-w-md mx-4"
                  >
                    <h2 className="text-3xl font-bold text-white mb-4">
                      {winner === 'draw' ? '引き分け' : `プレイヤー ${winner} の勝利！`}
                    </h2>
                    <p className="text-gray-300 mb-6">
                      ターン数: {turnCount} | ゲーム時間: {turnHistory.length}アクション
                    </p>
                    <div className="space-y-3">
                      <button
                        onClick={handleReturnHome}
                        className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200"
                      >
                        ホーム画面に戻る
                      </button>
                      <button
                        onClick={() => setShowDeckBuilder(true)}
                        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200"
                      >
                        デッキを変更
                      </button>
                    </div>
                  </motion.div>
                </motion.div>
              )}

              {/* UIコントロールエリア */}
              <div className="mb-2">
                <div className="flex items-center justify-between gap-4 mb-2">
                  {/* 🔧 修正: プレイヤー、フェーズ、ターン情報の枠をほんの少し右に配置 */}
                  <div className="flex-shrink-0 ml-14"> {/* 🔧 修正: ml-12からml-14に変更 */}
                    <TurnIndicator
                      currentPlayer={currentPlayer}
                      gamePhase={gamePhase}
                      turnCount={turnCount}
                      onEndTurn={endTurn}
                      isAIProcessing={isAIProcessing}
                      isTurnTransitioning={isTurnTransitioning}
                      territoryAttackStatus={territoryAttackStatus}
                      compact={true}
                    />
                  </div>

                  {/* 🔧 修正: ログ、ホームボタンをもう少し左に配置 */}
                  <div className="flex-shrink-0 flex items-center gap-2 mr-16"> {/* 🔧 修正: mr-12からmr-16に変更 */}
                    {territoryAttackStatus && (territoryAttackStatus.hasPlayer1BeenAttacked || territoryAttackStatus.hasPlayer2BeenAttacked) && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-orange-600/20 border border-orange-400/30 text-orange-300 px-2 py-1 rounded-lg font-semibold flex items-center gap-1 text-xs"
                      >
                        <SafeIcon icon={FiHome} className="animate-bounceIn" />
                        縄張り攻撃中
                      </motion.div>
                    )}

                    {currentPlayer === 2 && gamePhase === 'main' && territoryAttackStatus && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`border px-2 py-1 rounded-lg font-semibold flex items-center gap-1 text-xs ${
                          territoryAttackStatus.canEnemyAttack
                            ? 'bg-red-600/20 border-red-400/30 text-red-300'
                            : 'bg-gray-600/20 border-gray-400/30 text-gray-400'
                        }`}
                      >
                        <SafeIcon
                          icon={FiSword}
                          className={territoryAttackStatus.canEnemyAttack ? 'animate-pulse' : ''}
                        />
                        AI攻撃: {territoryAttackStatus.enemyAttackCount}/1
                        {!territoryAttackStatus.canEnemyAttack && (
                          <SafeIcon icon={FiShield} className="text-green-400" />
                        )}
                      </motion.div>
                    )}

                    <button
                      onClick={() => setShowGameLog(true)}
                      className="bg-green-600 hover:bg-green-500 text-white px-3 py-1 rounded-lg font-semibold flex items-center gap-1 text-xs transition-all duration-200"
                    >
                      <SafeIcon icon={FiMessageSquare} />
                      ログ ({gameLog?.length || 0})
                    </button>

                    <button
                      onClick={handleReturnHome}
                      className="bg-red-600 hover:bg-red-500 text-white px-3 py-1 rounded-lg font-semibold flex items-center gap-1 text-xs transition-all duration-200"
                    >
                      <SafeIcon icon={FiHome} />
                      ホーム
                    </button>
                  </div>
                </div>

                {/* プレイヤー2の情報エリア */}
                {gameState?.player2 && (
                  <div className="bg-black/30 backdrop-blur-md rounded-xl p-2 mb-2 max-w-md mx-auto"> {/* 🔧 修正: max-w-lgからmax-w-mdに変更 */}
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div className={`rounded-full ${currentPlayer === 2 ? 'bg-red-400 animate-pulse' : 'bg-gray-500'} w-2 h-2`} />
                        <h3 className="text-white font-bold flex items-center gap-1 text-sm">
                          <SafeIcon icon={FiUser} className="text-xs" />
                          プレイヤー2 (AI)
                        </h3>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs"> {/* 🔧 修正: gap-3からgap-2に変更 */}
                        <div className="flex items-center gap-1 text-blue-300">
                          <SafeIcon icon={FiLayers} className="text-xs" />
                          <span>手札: {gameState.player2.hand.length}</span>
                        </div>
                        
                        {gameState.player2.maxCost !== undefined && (
                          <div className="flex items-center gap-1 text-yellow-300">
                            <SafeIcon icon={FiDollarSign} className="text-xs" />
                            <span>コスト: {gameState.player2.currentCost}/{gameState.player2.maxCost}</span>
                          </div>
                        )}
                        
                        <div className="flex items-center gap-1 text-blue-300">
                          <SafeIcon icon={FiLayers} className="text-xs" />
                          <span>山札: {gameState.player2.deck.length}</span>
                        </div>
                        
                        <div className="flex items-center gap-1 text-gray-300">
                          <SafeIcon icon={FiArchive} className="text-xs" />
                          <span>捨札: {gameState.player2.graveyard.length}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* ゲームエリア */}
              <div className="flex-1 flex flex-col">
                {/* プレイヤー2エリア（上部） */}
                <div className="mb-2">
                  <PlayerArea
                    player={gameState?.player2}
                    isCurrentPlayer={currentPlayer === 2}
                    isOpponent={true}
                    onPlayCard={playCard}
                    onAttack={attackWithInsect}
                    onSetFeed={setFeed}
                    gamePhase={gamePhase}
                    onReturnCardToHand={(card, area) => returnCardToHand(card, area, 2)}
                    onCardClick={handleCardClick}
                    onImageClick={handleImageClick}
                    compact={true}
                    turnCount={turnCount}
                    currentPlayer={currentPlayer}
                    enemyPlayer={gameState?.player1}
                    onAttackTarget={handleAttackTarget}
                    onSpellToGraveyard={handleSpellToGraveyard}
                    onEnhancementDrop={handleEnhancementDrop}
                    territoryAttackStatus={territoryAttackStatus}
                    showUIControls={false}
                    showPlayerInfo={false}
                    getDebuffStatus={getDebuffStatus}
                    getEffectiveAttackPower={getEffectiveAttackPower}
                    getEffectiveMaxHealth={getEffectiveMaxHealth}
                    getLocustSpellStatus={getLocustSpellStatus}
                    getMimicryStatus={getMimicryStatus}
                    onBreathOfInsectsDrop={handleBreathOfInsectsDrop}
                    mimicryRefresh={mimicryRefresh}
                  />
                </div>

                {/* 区切り線 */}
                <div className="h-4 flex items-center justify-center mb-2">
                  <div className="w-full h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent"></div>
                </div>

                {/* プレイヤー1エリア（下部） - 🔧 修正: 全体的に下に移動 */}
                <div className="flex-1 flex flex-col mt-8"> {/* 🔧 修正: mt-8を追加してエリア全体を下に移動 */}
                  <PlayerArea
                    player={gameState?.player1}
                    isCurrentPlayer={currentPlayer === 1}
                    isOpponent={false}
                    onPlayCard={playCard}
                    onAttack={attackWithInsect}
                    onSetFeed={setFeed}
                    gamePhase={gamePhase}
                    onReturnCardToHand={(card, area) => returnCardToHand(card, area, 1)}
                    onCardClick={handleCardClick}
                    onImageClick={handleImageClick}
                    compact={false}
                    turnCount={turnCount}
                    currentPlayer={currentPlayer}
                    enemyPlayer={gameState?.player2}
                    onAttackTarget={handleAttackTarget}
                    onSkipFeedPhase={handleSkipFeedPhase}
                    onSpellToGraveyard={handleSpellToGraveyard}
                    onEnhancementDrop={handleEnhancementDrop}
                    territoryAttackStatus={territoryAttackStatus}
                    showUIControls={true}
                    getDebuffStatus={getDebuffStatus}
                    getEffectiveAttackPower={getEffectiveAttackPower}
                    getEffectiveMaxHealth={getEffectiveMaxHealth}
                    getLocustSpellStatus={getLocustSpellStatus}
                    getMimicryStatus={getMimicryStatus}
                    onBreathOfInsectsDrop={handleBreathOfInsectsDrop}
                    mimicryRefresh={mimicryRefresh}
                  />
                </div>
              </div>
            </div>

            {/* 追加モーダル */}
            <GameLog logs={gameLog} isOpen={showGameLog} onClose={() => setShowGameLog(false)} />
            {selectedImageCard && (
              <CardImageModal card={selectedImageCard} onClose={() => setSelectedImageCard(null)} />
            )}
            {showCardManager && (
              <CardManager onClose={() => setShowCardManager(false)} />
            )}
            {showDeckBuilder && (
              <DeckBuilder onClose={() => setShowDeckBuilder(false)} onStartGame={handleStartGameWithDecks} />
            )}
          </div>
        </div>
      </div>
    </DndProvider>
  );
};

export default GameBoard;