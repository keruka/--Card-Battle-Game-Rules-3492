import React from 'react';
import { motion } from 'framer-motion';
import { useDrop } from 'react-dnd';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const { FiArchive } = FiIcons;

const GraveyardArea = ({
  graveyard,
  onCardClick,
  compact = false,
  // 🆕 術カードドロップ用の新しいプロパティ
  onSpellDrop,
  isCurrentPlayer = false,
  gamePhase = 'main',
  // 🆕 プレイヤー2判定用のプロパティ
  isOpponent = false,
  // 🆕 飛蝗の凶相効果用のプロパティ
  getLocustSpellStatus,
  currentPlayer = 1,
  // 🆕 蟲の息吹捨札ドロップ用のプロパティ
  onBreathOfInsectsDrop
}) => {
  // 🆕 術カードのドロップ処理
  const [{ isOver, canDrop }, drop] = useDrop(
    () => ({
      accept: 'card',
      drop: (item) => {
        if (item.card.type === 'spell' && isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main')) {
          // 🆕 蟲の息吹の特別処理
          if (item.card.name && item.card.name.includes('蟲の息吹')) {
            console.log('🌪️ 蟲の息吹が捨札にドロップされました！');
            onBreathOfInsectsDrop?.(item.card);
            return;
          }
          // 🆕 飛蝗の凶相の特別処理
          if (item.card.name && item.card.name.includes('飛蝗の凶相')) {
            console.log('🦗 飛蝗の凶相がドロップされました！');
          }
          onSpellDrop?.(item.card);
        }
      },
      canDrop: (item) => {
        return item.card.type === 'spell' && isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main');
      },
      collect: (monitor) => ({
        isOver: monitor.isOver(),
        canDrop: monitor.canDrop(),
      }),
    }),
    [isCurrentPlayer, gamePhase, onSpellDrop, onBreathOfInsectsDrop]
  );

  const topCard = graveyard[graveyard.length - 1];
  const isHighlighted = isOver && canDrop;

  // 🆕 飛蝗の凶相効果の取得
  const locustSpellBonus = getLocustSpellStatus ? getLocustSpellStatus(currentPlayer) : 0;
  const hasLocustSpellEffect = locustSpellBonus > 0;

  return (
    <div
      ref={drop}
      className={`
        bg-purple-900/50 rounded-xl p-2 border-4 border-dashed border-purple-600/50
        ${compact ? 'min-h-6' : 'min-h-12'}
        ${isHighlighted ? 'border-purple-400 bg-purple-400/20 shadow-lg shadow-purple-400/30' : ''}
        ${hasLocustSpellEffect ? 'ring-2 ring-yellow-400/50 shadow-lg shadow-yellow-400/30' : ''}
        transition-all duration-300
      `} // 🔧 修正: 色を濃く、枠を太く
    >
      <h4
        className={`text-white font-semibold text-center flex items-center justify-center gap-1 ${
          compact ? 'text-xs mb-1' : 'text-sm mb-1'
        } ${isOpponent ? 'transform rotate-180' : ''}`}
      >
        <SafeIcon icon={FiArchive} className={compact ? 'text-xs' : 'text-sm'} />
        捨札 ({graveyard.length})
        {/* 🆕 飛蝗の凶相効果インジケーター */}
        {hasLocustSpellEffect && !compact && (
          <span className="text-yellow-300 text-xs ml-1 animate-pulse">
            🦗+{locustSpellBonus}
          </span>
        )}
        {/* 🆕 術カードドロップヒント */}
        {isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && !compact && (
          <span className="text-purple-300 text-xs ml-1">
            (術カードをドロップ)
          </span>
        )}
      </h4>
      <div className={`flex items-center justify-center ${compact ? 'h-4' : 'h-8'} relative`}>
        {graveyard.length === 0 ? (
          <div
            className={`text-gray-400 ${compact ? 'text-xs' : 'text-sm'} text-center ${
              isOpponent ? 'transform rotate-180' : ''
            }`}
          >
            {isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && !compact
              ? '術カードをドロップ'
              : 'なし'}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="cursor-pointer"
            onClick={() => onCardClick && onCardClick(topCard)}
          >
            {/* 🔧 統一サイズシステムを使用 */}
            <Card
              card={topCard}
              compact={compact}
              smallAreaSize={true} // 🆕 小エリア統一サイズを使用
              onCardClick={() => onCardClick && onCardClick(topCard)}
            />
          </motion.div>
        )}

        {/* 🆕 ドロップゾーンハイライト */}
        {isCurrentPlayer && (gamePhase === 'set' || gamePhase === 'main') && !compact && (
          <div className="absolute inset-0 border-2 border-dashed border-purple-300/50 rounded-xl pointer-events-none">
            {isHighlighted && (
              <div className="absolute inset-0 bg-purple-400/20 rounded-xl border-2 border-purple-400 animate-pulse" />
            )}
          </div>
        )}
      </div>

      {/* 🆕 ドロップ時の視覚的フィードバック */}
      {isHighlighted && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute inset-0 bg-purple-400/20 rounded-xl border-2 border-purple-400 pointer-events-none flex items-center justify-center"
        >
          <div className="bg-purple-600/80 px-2 py-1 rounded text-white font-bold text-xs">
            術カードを使用
          </div>
        </motion.div>
      )}

      {/* 🆕 飛蝗の凶相効果の詳細表示 */}
      {hasLocustSpellEffect && !compact && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute -top-2 -right-2 bg-yellow-500/90 text-black text-xs font-bold px-2 py-1 rounded-full shadow-lg z-10"
        >
          🦗 全虫+{locustSpellBonus}
        </motion.div>
      )}
    </div>
  );
};

export default GraveyardArea;