import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiMessageSquare, FiX } = FiIcons;

const GameLog = ({ logs, isOpen, onClose }) => {
  const logEndRef = useRef(null);
  const scrollContainerRef = useRef(null);

  // Auto-scroll to bottom when new logs are added
  useEffect(() => {
    if (logEndRef.current && isOpen) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isOpen]);

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-gray-900 rounded-2xl p-6 max-w-4xl w-full max-h-[80vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-2xl font-bold flex items-center gap-2">
            <SafeIcon icon={FiMessageSquare} />
            ゲームログ ({logs.length})
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <SafeIcon icon={FiX} className="text-2xl" />
          </button>
        </div>
        
        <div 
          ref={scrollContainerRef}
          className="flex-1 overflow-y-auto space-y-2 scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800 hover:scrollbar-thumb-gray-500 pr-2"
          style={{
            scrollbarWidth: 'thin',
            scrollbarColor: '#4B5563 #1F2937'
          }}
        >
          {logs.length === 0 ? (
            <p className="text-gray-400 text-center py-8">ゲームが開始されました</p>
          ) : (
            <>
              {logs.map((log, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.02 }}
                  className={`p-3 rounded-lg transition-colors hover:bg-opacity-80 ${
                    log.type === 'error' 
                      ? 'bg-red-900/50 text-red-200 border-l-4 border-red-500' 
                      : log.type === 'success' 
                      ? 'bg-green-900/50 text-green-200 border-l-4 border-green-500' 
                      : log.type === 'attack' 
                      ? 'bg-orange-900/50 text-orange-200 border-l-4 border-orange-500' 
                      : 'bg-gray-900/50 text-gray-200 border-l-4 border-gray-600'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="flex-1 text-sm">{log.message}</span>
                    <span className="text-xs text-gray-400 ml-3 flex-shrink-0 opacity-70">
                      {log.timestamp}
                    </span>
                  </div>
                </motion.div>
              ))}
              <div ref={logEndRef} />
            </>
          )}
        </div>

        {/* Close button at bottom */}
        <div className="flex justify-center mt-6">
          <button
            onClick={onClose}
            className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
          >
            閉じる
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default GameLog;