import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import supabase from '../lib/supabase';

const { FiPlus, FiUpload, FiEdit, FiTrash2, FiImage, FiSave, FiDatabase, FiAlertTriangle } = FiIcons;

const CardManager = ({ onClose }) => {
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [editingCard, setEditingCard] = useState(null);
  const [initializing, setInitializing] = useState(false);
  const [cleaningUp, setCleaningUp] = useState(false);
  const [newCard, setNewCard] = useState({
    name: '',
    type: 'insect',
    cost: 1,
    attack: 100,
    attack1: 100,
    attack2: 150,
    health: 100,
    effect_text: '',
    effect1_text: '',
    effect2_text: '',
    passive_effect_text: '',
    rarity: 'N',
    element: 'green'
  });
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    loadCards();
  }, []);

  const loadCards = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('cards_mushi_a7x9k2')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCards(data || []);
    } catch (error) {
      console.error('Error loading cards:', error);
      alert('カードの読み込みに失敗しました: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const cleanupImagelessCards = async () => {
    if (!confirm('画像がアップロードされていないカードをすべて削除しますか？\n\nこの操作は元に戻せません。')) {
      return;
    }

    try {
      setCleaningUp(true);
      
      // First get the cards that will be deleted
      const { data: cardsToDelete, error: fetchError } = await supabase
        .from('cards_mushi_a7x9k2')
        .select('id, name, image_url')
        .or('image_url.is.null,image_url.eq.');

      if (fetchError) throw fetchError;

      if (!cardsToDelete || cardsToDelete.length === 0) {
        alert('削除対象のカードはありません。');
        return;
      }

      // Delete cards without images
      const { error: deleteError } = await supabase
        .from('cards_mushi_a7x9k2')
        .delete()
        .or('image_url.is.null,image_url.eq.');

      if (deleteError) throw deleteError;

      alert(`${cardsToDelete.length}枚の画像なしカードを削除しました。`);
      await loadCards();
    } catch (error) {
      console.error('Error cleaning up imageless cards:', error);
      alert('画像なしカードの削除に失敗しました: ' + error.message);
    } finally {
      setCleaningUp(false);
    }
  };

  const initializeDefaultCards = async () => {
    try {
      setInitializing(true);
      const defaultCards = [
        // Enhanced cards with placeholder images for demo
        {
          name: 'プレミアム甲虫',
          type: 'insect',
          cost: 2,
          attack: 250,
          attack1: 250,
          attack2: 350,
          health: 200,
          element: 'green',
          rarity: 'R',
          effect_text: '強化された甲虫',
          effect1_text: '強力な突進',
          effect2_text: '必殺突進',
          passive_effect_text: '防御強化: ダメージ-50',
          image_url: 'https://via.placeholder.com/150x200/22c55e/ffffff?text=プレミアム甲虫'
        },
        {
          name: '炎の蝶',
          type: 'insect',
          cost: 2,
          attack: 200,
          attack1: 200,
          attack2: 400,
          health: 150,
          element: 'red',
          rarity: 'R',
          effect_text: '炎を纏う美しい蝶',
          effect1_text: '炎の粉',
          effect2_text: '業火の舞',
          passive_effect_text: '火傷: 敵に継続ダメージ',
          image_url: 'https://via.placeholder.com/150x200/ef4444/ffffff?text=炎の蝶'
        },
        {
          name: '氷結蜘蛛',
          type: 'insect',
          cost: 3,
          attack: 300,
          attack1: 300,
          attack2: 500,
          health: 250,
          element: 'blue',
          rarity: 'SR',
          effect_text: '氷を操る巨大蜘蛛',
          effect1_text: '氷の糸',
          effect2_text: '氷結の網',
          passive_effect_text: '凍結: 敵の行動を封じる',
          image_url: 'https://via.placeholder.com/150x200/3b82f6/ffffff?text=氷結蜘蛛'
        },
        {
          name: '雷神の蜂',
          type: 'insect',
          cost: 4,
          attack: 600,
          attack1: 600,
          attack2: 900,
          health: 400,
          element: 'red',
          rarity: 'LR',
          effect_text: '雷を司る伝説の蜂',
          effect1_text: '雷の針',
          effect2_text: '神雷',
          passive_effect_text: '雷鳴: 全ての敵にダメージ',
          image_url: 'https://via.placeholder.com/150x200/fbbf24/000000?text=雷神の蜂'
        },
        // Enhanced spells
        {
          name: '上級強化術',
          type: 'spell',
          cost: 2,
          attack: null,
          attack1: null,
          attack2: null,
          health: null,
          element: 'neutral',
          rarity: 'R',
          effect_text: '全ての虫の攻撃力+200',
          effect1_text: '全ての虫の攻撃力+200',
          image_url: 'https://via.placeholder.com/150x200/8b5cf6/ffffff?text=上級強化術'
        },
        {
          name: '完全回復術',
          type: 'spell',
          cost: 2,
          attack: null,
          attack1: null,
          attack2: null,
          health: null,
          element: 'neutral',
          rarity: 'R',
          effect_text: '全ての虫の体力を完全回復し、+100',
          effect1_text: '全ての虫の体力を完全回復し、+100',
          image_url: 'https://via.placeholder.com/150x200/10b981/ffffff?text=完全回復術'
        }
      ];

      // Insert enhanced cards
      let successCount = 0;
      for (const card of defaultCards) {
        try {
          const { error } = await supabase
            .from('cards_mushi_a7x9k2')
            .insert([card]);

          if (error) {
            console.error(`Error inserting card ${card.name}:`, error);
          } else {
            successCount++;
          }
        } catch (err) {
          console.error(`Failed to insert card ${card.name}:`, err);
        }
      }

      alert(`${successCount}枚の新しいカードをデータベースに追加しました！`);
      loadCards();
    } catch (error) {
      console.error('Error initializing default cards:', error);
      alert('デフォルトカードの追加に失敗しました: ' + error.message);
    } finally {
      setInitializing(false);
    }
  };

  const uploadImage = async (file) => {
    try {
      setUploadingImage(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `card-${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
      
      console.log('Uploading file:', fileName);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('card-images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        if (uploadError.message.includes('Bucket not found')) {
          console.log('Bucket not found, creating...');
          const { error: bucketError } = await supabase.storage.createBucket('card-images', {
            public: true,
            fileSizeLimit: 5242880,
            allowedMimeTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
          });

          if (bucketError && !bucketError.message.includes('already exists')) {
            console.error('Error creating bucket:', bucketError);
            throw bucketError;
          }

          const { data: retryUploadData, error: retryUploadError } = await supabase.storage
            .from('card-images')
            .upload(fileName, file, {
              cacheControl: '3600',
              upsert: false
            });

          if (retryUploadError) {
            throw retryUploadError;
          }
          console.log('Retry upload successful:', retryUploadData);
        } else {
          throw uploadError;
        }
      } else {
        console.log('Upload successful:', uploadData);
      }

      const { data: urlData } = supabase.storage
        .from('card-images')
        .getPublicUrl(fileName);

      console.log('Public URL:', urlData.publicUrl);
      return urlData.publicUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      if (error.message.includes('row-level security policy')) {
        alert('ストレージへのアクセス権限がありません。管理者にお問い合わせください。');
      } else if (error.message.includes('File size')) {
        alert('ファイルサイズが大きすぎます。5MB以下のファイルを選択してください。');
      } else if (error.message.includes('File type')) {
        alert('サポートされていないファイル形式です。JPEG、PNG、GIF、WebPファイルを選択してください。');
      } else {
        alert('画像のアップロードに失敗しました: ' + error.message);
      }
      return null;
    } finally {
      setUploadingImage(false);
    }
  };

  const saveCard = async (cardData, imageFile = null) => {
    try {
      setSaving(true);
      let imageUrl = cardData.image_url;

      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
        if (!imageUrl) return;
      }

      // Require image for new cards
      if (!editingCard?.id && !imageUrl) {
        alert('新規カードには画像が必要です。画像をアップロードしてください。');
        return;
      }

      const cardToSave = {
        name: cardData.name.trim(),
        type: cardData.type,
        cost: parseInt(cardData.cost) || 0,
        rarity: cardData.rarity,
        element: cardData.element
      };

      if (cardData.type === 'insect') {
        cardToSave.attack = parseInt(cardData.attack1) || parseInt(cardData.attack) || 0;
        cardToSave.health = parseInt(cardData.health) || 1;
      }

      if (cardData.effect1_text) {
        cardToSave.effect_text = cardData.effect1_text;
      }

      if (imageUrl) {
        cardToSave.image_url = imageUrl;
      }

      try {
        if (cardData.type === 'insect') {
          cardToSave.attack1 = parseInt(cardData.attack1) || 0;
          cardToSave.attack2 = parseInt(cardData.attack2) || 0;
        }
        if (cardData.effect1_text) cardToSave.effect1_text = cardData.effect1_text;
        if (cardData.effect2_text) cardToSave.effect2_text = cardData.effect2_text;
        if (cardData.passive_effect_text) cardToSave.passive_effect_text = cardData.passive_effect_text;
      } catch (schemaError) {
        console.warn('Some fields may not exist in schema:', schemaError);
      }

      console.log('Saving card data:', cardToSave);

      let result;
      if (editingCard && editingCard.id) {
        result = await supabase
          .from('cards_mushi_a7x9k2')
          .update(cardToSave)
          .eq('id', editingCard.id)
          .select()
          .single();
      } else {
        result = await supabase
          .from('cards_mushi_a7x9k2')
          .insert([cardToSave])
          .select()
          .single();
      }

      if (result.error) {
        console.error('Database error:', result.error);
        throw result.error;
      }

      console.log('Card saved successfully:', result.data);
      alert(editingCard?.id ? 'カードを更新しました！' : 'カードを作成しました！');

      await loadCards();
      setEditingCard(null);
      setNewCard({
        name: '',
        type: 'insect',
        cost: 1,
        attack: 100,
        attack1: 100,
        attack2: 150,
        health: 100,
        effect_text: '',
        effect1_text: '',
        effect2_text: '',
        passive_effect_text: '',
        rarity: 'N',
        element: 'green'
      });
    } catch (error) {
      console.error('Error saving card:', error);
      alert('カードの保存に失敗しました: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const deleteCard = async (card) => {
    const confirmMessage = `本当に「${card.name}」を削除しますか？\n\n削除されたカードは復元できません。`;
    
    if (!confirm(confirmMessage)) {
      return;
    }

    try {
      setDeleting(card.id);
      console.log('Deleting card with ID:', card.id);

      const { error } = await supabase
        .from('cards_mushi_a7x9k2')
        .delete()
        .eq('id', card.id);

      if (error) {
        console.error('Delete error:', error);
        throw error;
      }

      console.log('Card deleted successfully');

      if (card.image_url) {
        try {
          const imagePath = card.image_url.split('/').pop();
          if (imagePath) {
            const { error: imageError } = await supabase.storage
              .from('card-images')
              .remove([imagePath]);
            
            if (imageError) {
              console.warn('Failed to delete image:', imageError);
            }
          }
        } catch (imageErr) {
          console.warn('Image deletion failed:', imageErr);
        }
      }

      alert(`「${card.name}」を削除しました`);
      await loadCards();
    } catch (error) {
      console.error('Error deleting card:', error);
      
      let errorMessage = 'カードの削除に失敗しました。';
      
      if (error.message.includes('row level security')) {
        errorMessage += '\n権限エラー: 管理者にお問い合わせください。';
      } else if (error.message.includes('foreign key')) {
        errorMessage += '\n関連データが存在するため削除できません。';
      } else {
        errorMessage += `\nエラー詳細: ${error.message}`;
      }
      
      alert(errorMessage);
    } finally {
      setDeleting(null);
    }
  };

  const getRarityDisplay = (rarity) => {
    switch (rarity) {
      case 'N': return 'ノーマル (N)';
      case 'R': return 'レア (R)';
      case 'SR': return 'スーパーレア (SR)';
      case 'LR': return 'レジェンダリーレア (LR)';
      default: return rarity;
    }
  };

  const CardForm = ({ card, onSave, onCancel }) => {
    const [formData, setFormData] = useState(card);
    const [imageFile, setImageFile] = useState(null);

    const handleSubmit = (e) => {
      e.preventDefault();

      if (!formData.name.trim()) {
        alert('カード名を入力してください');
        return;
      }

      if (formData.type === 'insect' && parseInt(formData.health) <= 0) {
        alert('虫カードの体力は1以上にしてください');
        return;
      }

      console.log('Form submission:', formData);
      onSave(formData, imageFile);
    };

    const handleImageChange = (e) => {
      const file = e.target.files[0];
      if (file) {
        if (file.size > 5 * 1024 * 1024) {
          alert('ファイルサイズが大きすぎます。5MB以下のファイルを選択してください。');
          return;
        }

        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
          alert('サポートされていないファイル形式です。JPEG、PNG、GIF、WebPファイルを選択してください。');
          return;
        }

        setImageFile(file);
      }
    };

    const handleNumberInput = (field, value) => {
      if (value === '' || value === null || value === undefined) {
        setFormData({ ...formData, [field]: value });
        return;
      }

      const numValue = parseInt(value);
      if (!isNaN(numValue) && numValue >= 0) {
        setFormData({ ...formData, [field]: numValue });
      }
    };

    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
      >
        <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
          <h3 className="text-white text-xl font-bold mb-4">
            {card.id ? 'カード編集' : 'カード追加'}
          </h3>

          {!card.id && (
            <div className="bg-yellow-900/50 border border-yellow-600 rounded-lg p-3 mb-4">
              <div className="flex items-center gap-2 text-yellow-200">
                <SafeIcon icon={FiAlertTriangle} />
                <span className="font-semibold">重要:</span>
                <span className="text-sm">新規カードには画像のアップロードが必要です</span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-white block mb-2">カード名 *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-white block mb-2">種類</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                >
                  <option value="insect">ムシ</option>
                  <option value="spell">術</option>
                  <option value="enhancement">強化</option>
                </select>
              </div>

              <div>
                <label className="text-white block mb-2">コスト</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={formData.cost}
                  onChange={(e) => handleNumberInput('cost', e.target.value)}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {formData.type === 'insect' && (
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-white block mb-2">攻撃1</label>
                  <input
                    type="number"
                    min="0"
                    max="9999"
                    value={formData.attack1 !== null && formData.attack1 !== undefined ? formData.attack1 : ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      handleNumberInput('attack1', value);
                      if (value !== '' && !isNaN(parseInt(value))) {
                        setFormData(prev => ({ ...prev, attack1: parseInt(value), attack: parseInt(value) }));
                      } else {
                        setFormData(prev => ({ ...prev, attack1: value, attack: value }));
                      }
                    }}
                    className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                    placeholder="100"
                  />
                </div>

                <div>
                  <label className="text-white block mb-2">攻撃2</label>
                  <input
                    type="number"
                    min="0"
                    max="9999"
                    value={formData.attack2 !== null && formData.attack2 !== undefined ? formData.attack2 : ''}
                    onChange={(e) => handleNumberInput('attack2', e.target.value)}
                    className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                    placeholder="150"
                  />
                </div>

                <div>
                  <label className="text-white block mb-2">体力 *</label>
                  <input
                    type="number"
                    min="1"
                    max="9999"
                    value={formData.health !== null && formData.health !== undefined ? formData.health : ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === '' || (!isNaN(parseInt(value)) && parseInt(value) >= 1)) {
                        setFormData({ ...formData, health: value === '' ? '' : parseInt(value) });
                      }
                    }}
                    className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                    placeholder="100"
                    required
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-white block mb-2">レアリティ</label>
                <select
                  value={formData.rarity}
                  onChange={(e) => setFormData({ ...formData, rarity: e.target.value })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                >
                  <option value="N">ノーマル (N)</option>
                  <option value="R">レア (R)</option>
                  <option value="SR">スーパーレア (SR)</option>
                  <option value="LR">レジェンダリーレア (LR)</option>
                </select>
              </div>

              <div>
                <label className="text-white block mb-2">属性</label>
                <select
                  value={formData.element}
                  onChange={(e) => setFormData({ ...formData, element: e.target.value })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                >
                  <option value="red">赤</option>
                  <option value="blue">青</option>
                  <option value="green">緑</option>
                  <option value="neutral">無属性</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-white block mb-2">効果1 (攻撃1時発動)</label>
                <textarea
                  value={formData.effect1_text || formData.effect_text || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    effect1_text: e.target.value, 
                    effect_text: e.target.value 
                  })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500 h-16"
                  placeholder="攻撃1を使用した時に発動する効果..."
                />
              </div>

              <div>
                <label className="text-white block mb-2">効果2 (攻撃2時発動)</label>
                <textarea
                  value={formData.effect2_text || ''}
                  onChange={(e) => setFormData({ ...formData, effect2_text: e.target.value })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500 h-16"
                  placeholder="攻撃2を使用した時に発動する効果..."
                />
              </div>

              <div>
                <label className="text-white block mb-2">常時効果</label>
                <textarea
                  value={formData.passive_effect_text || ''}
                  onChange={(e) => setFormData({ ...formData, passive_effect_text: e.target.value })}
                  className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500 h-16"
                  placeholder="場にいる間常時発動する効果..."
                />
              </div>
            </div>

            <div>
              <label className="text-white block mb-2">
                カード画像 {!card.id && <span className="text-red-400">*必須</span>}
              </label>
              <input
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp"
                onChange={handleImageChange}
                className="w-full p-2 rounded bg-gray-800 text-white border border-gray-600 focus:border-emerald-500"
                required={!card.id}
              />
              <p className="text-gray-400 text-xs mt-1">
                対応形式: JPEG, PNG, GIF, WebP (最大5MB)
              </p>
              {formData.image_url && (
                <img
                  src={formData.image_url}
                  alt="Card preview"
                  className="mt-2 w-20 h-28 object-cover rounded border"
                />
              )}
              {imageFile && (
                <p className="text-emerald-400 text-sm mt-1">
                  新しい画像が選択されました: {imageFile.name}
                </p>
              )}
            </div>

            <div className="flex gap-2 pt-4">
              <button
                type="submit"
                disabled={saving || uploadingImage}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white py-2 px-4 rounded flex items-center justify-center gap-2 transition-colors"
              >
                <SafeIcon icon={FiSave} />
                {saving ? '保存中...' : uploadingImage ? '画像アップ中...' : '保存'}
              </button>
              <button
                type="button"
                onClick={onCancel}
                disabled={saving}
                className="bg-gray-600 hover:bg-gray-500 disabled:bg-gray-800 text-white py-2 px-4 rounded transition-colors"
              >
                キャンセル
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black/90 flex items-center justify-center z-50"
    >
      <div className="bg-gray-900 rounded-xl p-6 max-w-6xl w-full mx-4 max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-2xl font-bold">カード管理</h2>
          <div className="flex gap-2">
            <button
              onClick={cleanupImagelessCards}
              disabled={cleaningUp}
              className="bg-orange-600 hover:bg-orange-500 disabled:bg-gray-600 text-white px-4 py-2 rounded flex items-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiAlertTriangle} />
              {cleaningUp ? '削除中...' : '画像なしカード削除'}
            </button>
            <button
              onClick={initializeDefaultCards}
              disabled={initializing}
              className="bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 text-white px-4 py-2 rounded flex items-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiDatabase} />
              {initializing ? 'データ追加中...' : 'サンプルカード追加'}
            </button>
            <button
              onClick={() => setEditingCard(newCard)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded flex items-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiPlus} />
              新規カード
            </button>
            <button
              onClick={onClose}
              className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded transition-colors"
            >
              閉じる
            </button>
          </div>
        </div>

        {loading ? (
          <div className="text-white text-center py-8">読み込み中...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-h-[60vh] overflow-y-auto">
            {cards.length === 0 ? (
              <div className="col-span-full text-center text-gray-400 py-8">
                <p>カードがありません。</p>
                <p>「サンプルカード追加」ボタンでテスト用カードを追加できます。</p>
              </div>
            ) : (
              cards.map((card) => (
                <motion.div
                  key={card.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`bg-gray-800 rounded-lg p-4 border ${
                    !card.image_url || card.image_url === '' 
                      ? 'border-red-500 bg-red-900/20' 
                      : 'border-gray-700'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-bold text-sm">{card.name}</h3>
                    <div className="flex gap-1">
                      {(!card.image_url || card.image_url === '') && (
                        <SafeIcon icon={FiAlertTriangle} className="text-red-400" />
                      )}
                      <button
                        onClick={() => setEditingCard(card)}
                        disabled={deleting === card.id}
                        className="text-blue-400 hover:text-blue-300 p-1 rounded hover:bg-gray-700 transition-colors disabled:opacity-50"
                      >
                        <SafeIcon icon={FiEdit} />
                      </button>
                      <button
                        onClick={() => deleteCard(card)}
                        disabled={deleting === card.id}
                        className="text-red-400 hover:text-red-300 p-1 rounded hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {deleting === card.id ? (
                          <div className="animate-spin w-4 h-4 border-2 border-red-400 border-t-transparent rounded-full"></div>
                        ) : (
                          <SafeIcon icon={FiTrash2} />
                        )}
                      </button>
                    </div>
                  </div>

                  {card.image_url ? (
                    <img
                      src={card.image_url}
                      alt={card.name}
                      className="w-full h-24 object-cover rounded mb-2"
                    />
                  ) : (
                    <div className="w-full h-24 bg-red-900/50 border-2 border-dashed border-red-500 rounded mb-2 flex items-center justify-center">
                      <div className="text-center text-red-400">
                        <SafeIcon icon={FiImage} className="text-2xl mb-1" />
                        <p className="text-xs">画像なし</p>
                      </div>
                    </div>
                  )}

                  <div className="text-gray-300 text-xs space-y-1">
                    <p>種類: <span className="text-white">{card.type}</span></p>
                    <p>コスト: <span className="text-yellow-300">{card.cost}</span></p>
                    {card.type === 'insect' && (
                      <>
                        <p className="text-red-300">攻撃1: {card.attack1 ?? card.attack ?? 0}</p>
                        <p className="text-orange-300">攻撃2: {card.attack2 ?? 0}</p>
                        <p className="text-green-300">体力: {card.health}</p>
                      </>
                    )}
                    <p>レアリティ: <span className="text-white">{getRarityDisplay(card.rarity)}</span></p>
                    <p>属性: <span className="text-white">{card.element}</span></p>
                    {card.effect1_text && (
                      <p className="text-yellow-300">効果1: {card.effect1_text.substring(0, 30)}{card.effect1_text.length > 30 ? '...' : ''}</p>
                    )}
                    {card.effect2_text && (
                      <p className="text-orange-300">効果2: {card.effect2_text.substring(0, 30)}{card.effect2_text.length > 30 ? '...' : ''}</p>
                    )}
                    {card.passive_effect_text && (
                      <p className="text-blue-300">常時: {card.passive_effect_text.substring(0, 30)}{card.passive_effect_text.length > 30 ? '...' : ''}</p>
                    )}
                    {!card.effect1_text && !card.effect2_text && !card.passive_effect_text && card.effect_text && (
                      <p className="text-yellow-300">効果: {card.effect_text.substring(0, 30)}{card.effect_text.length > 30 ? '...' : ''}</p>
                    )}
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}
      </div>

      {editingCard && (
        <CardForm
          card={editingCard}
          onSave={saveCard}
          onCancel={() => setEditingCard(null)}
        />
      )}
    </motion.div>
  );
};

export default CardManager;