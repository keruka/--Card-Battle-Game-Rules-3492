import React from 'react';
import {motion} from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const {FiTarget,FiX,FiCheckCircle} = FiIcons;

const ColorSelectionModal = ({isOpen, enhancementCard, targetInsect, onSelectColor, onCancel}) => {
  if (!isOpen || !enhancementCard) return null;

  const colorOptions = [
    {
      value: 'red',
      name: '赤',
      bgColor: 'bg-red-600',
      hoverColor: 'hover:bg-red-500',
      borderColor: 'border-red-400',
      textColor: 'text-red-300',
      icon: '🔥'
    },
    {
      value: 'blue', 
      name: '青',
      bgColor: 'bg-blue-600',
      hoverColor: 'hover:bg-blue-500',
      borderColor: 'border-blue-400',
      textColor: 'text-blue-300',
      icon: '💧'
    },
    {
      value: 'green',
      name: '緑',
      bgColor: 'bg-green-600',
      hoverColor: 'hover:bg-green-500',
      borderColor: 'border-green-400',
      textColor: 'text-green-300',
      icon: '🌿'
    }
  ];

  return (
    <motion.div
      initial={{opacity: 0}}
      animate={{opacity: 1}}
      exit={{opacity: 0}}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onCancel}
    >
      <motion.div
        initial={{scale: 0.8, opacity: 0}}
        animate={{scale: 1, opacity: 1}}
        exit={{scale: 0.8, opacity: 0}}
        className="bg-gray-900 rounded-2xl p-6 max-w-md w-full mx-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-white text-xl font-bold flex items-center gap-2">
            <SafeIcon icon={FiTarget} className="text-yellow-400" />
            玉虫色の羽化 - 属性選択
          </h2>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <SafeIcon icon={FiX} className="text-xl" />
          </button>
        </div>

        {/* 🔧 修正: 対象虫の情報表示は条件付きで表示 */}
        {targetInsect && (
          <div className="mb-6 p-4 bg-yellow-900/20 border border-yellow-600/30 rounded-lg">
            <div className="text-center">
              <h3 className="text-yellow-300 font-bold text-lg mb-2">{targetInsect.name}</h3>
              <p className="text-gray-300 text-sm">
                現在の属性: {
                  targetInsect.element === 'red' ? '🔥 赤' :
                  targetInsect.element === 'blue' ? '💧 青' :
                  targetInsect.element === 'green' ? '🌿 緑' : '⚪ 無属性'
                }
              </p>
            </div>
          </div>
        )}

        {/* 属性選択説明 */}
        <div className="mb-4 text-center">
          <p className="text-gray-300 text-sm">
            {targetInsect ? 'この虫を変更したい属性を選択してください' : '装備対象の虫を変更したい属性を選択してください'}
          </p>
          <p className="text-yellow-300 text-xs mt-1">
            ※ 選択した属性に永続的に変更されます
          </p>
        </div>

        {/* 属性選択ボタン */}
        <div className="space-y-3 mb-6">
          {colorOptions.map((color) => (
            <motion.button
              key={color.value}
              whileHover={{scale: 1.02}}
              whileTap={{scale: 0.98}}
              onClick={() => onSelectColor(color.value)}
              className={`w-full ${color.bgColor} ${color.hoverColor} text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200 border-2 ${color.borderColor}`}
            >
              <span className="text-xl">{color.icon}</span>
              <span>{color.name}属性に変更</span>
              <SafeIcon icon={FiCheckCircle} />
            </motion.button>
          ))}
        </div>

        {/* 効果説明 */}
        <div className="mb-6 p-3 bg-gray-800/50 border border-gray-600 rounded-lg">
          <h4 className="text-yellow-300 font-semibold text-sm mb-2">玉虫色の羽化の効果</h4>
          <p className="text-gray-300 text-xs leading-relaxed">
            装備した虫の属性を選択した色に変更します。属性変更により、バトルでの相性が変わります。
          </p>
          <div className="mt-2 text-xs text-gray-400">
            <p>🔥 赤 → 🌿 緑に有利</p>
            <p>💧 青 → 🔥 赤に有利</p>
            <p>🌿 緑 → 💧 青に有利</p>
          </div>
        </div>

        {/* キャンセルボタン */}
        <div className="flex justify-center">
          <button
            onClick={onCancel}
            className="bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
          >
            キャンセル
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ColorSelectionModal;