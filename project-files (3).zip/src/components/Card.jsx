import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useDrag } from 'react-dnd';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiSword, FiRotateCcw, FiPlay, FiLock, FiTarget, FiHome, FiHeart, FiArrowDown, FiZap, FiShield, FiEye } = FiIcons;

const Card = ({
  card,
  inHand = false,
  inFeed = false,
  inField = false,
  isPlayable = false,
  canAttack = false,
  canDrag = true,
  onPlay,
  onAttack,
  hasAttacked = false,
  gamePhase,
  onReturnToHand,
  onCardClick,
  onImageClick,
  canReturnToHand = true,
  showBack = false,
  feedAreaSize = false,
  turnCount = 1,
  cardPlayedTurn = null,
  currentPlayer = 1,
  enemyField = [],
  onAttackTarget,
  compact = false,
  graveyardSize = false,
  smallAreaSize = false,
  getDebuffStatus,
  getEffectiveAttackPower,
  getEffectiveMaxHealth,
  getMimicryStatus,
  // 🆕 擬態効果の強制リフレッシュ用（useGame.jsから渡される）
  mimicryRefresh = 0
}) => {
  const [showAttackOptions, setShowAttackOptions] = useState(false);
  const [showTargetSelection, setShowTargetSelection] = useState(false);
  const [showAdvantageIndicator, setShowAdvantageIndicator] = useState(false);
  const [selectedAttackType, setSelectedAttackType] = useState(1);

  // 🆕 カードが裏返っているかどうかの状態
  const isFlipped = card.isFlipped || false;

  // 🆕 弱体化効果の取得
  const debuffInfo = getDebuffStatus ? getDebuffStatus(card.id) : { totalDebuff: 0, activeDebuffs: [] };
  const hasDebuff = debuffInfo.totalDebuff > 0;

  // 🔧 修正: 擬態効果の取得 - 強制リフレッシュを考慮
  const mimicryInfo = getMimicryStatus ? getMimicryStatus(card.id) : { isActive: false, effectDetails: null };

  // 🔧 修正: 擬態効果の表示判定を厳密化 - mimicryRefreshも考慮
  const hasMimicry = mimicryInfo.isActive && inField;

  // 🆕 デバッグ用ログ
  if (card.name && card.name.includes('ナナフシモドキ') && inField) {
    console.log(`🦎🔍 ${card.name} 擬態状態チェック:`, {
      isActive: mimicryInfo.isActive,
      inField,
      hasMimicry,
      mimicryRefresh,
      effectDetails: mimicryInfo.effectDetails
    });
  }

  // 🔧 修正: ナナフシモドキの擬態能力チェック - 完全に削除
  // 擬態効果がアクティブでない場合は、「擬態能力」も一切表示しない
  const hasNanafushiMimicry = false; // 🔧 修正: 完全に無効化

  // 🆕 ナミアゲハの挑発効果チェック（幼虫は除外、場にいる時のみ）
  const isNamiagehaTaunt = inField &&
    card.name && card.name.includes('ナミアゲハ') &&
    !card.name.includes('幼虫') &&
    card.type === 'insect' &&
    !card.isFlipped;

  // 🆕 玉虫色の羽化による色変更効果をチェック
  const getColorChangeEffect = () => {
    if (!card || !card.appliedEnhancements) {
      return { hasColorChange: false };
    }

    const colorChangeEnhancement = card.appliedEnhancements.find(enhancement =>
      enhancement && enhancement.name && enhancement.name.includes('玉虫色の羽化')
    );

    if (colorChangeEnhancement && card.element) {
      const colorNames = {
        'red': { name: '赤', emoji: '🔥', bgColor: 'bg-red-500', textColor: 'text-red-300', borderColor: 'border-red-400' },
        'blue': { name: '青', emoji: '💧', bgColor: 'bg-blue-500', textColor: 'text-blue-300', borderColor: 'border-blue-400' },
        'green': { name: '緑', emoji: '🌿', bgColor: 'bg-green-500', textColor: 'text-green-300', borderColor: 'border-green-400' }
      };

      return {
        hasColorChange: true,
        color: card.element,
        colorInfo: colorNames[card.element] || {
          name: '無',
          emoji: '⚪',
          bgColor: 'bg-gray-500',
          textColor: 'text-gray-300',
          borderColor: 'border-gray-400'
        }
      };
    }

    return { hasColorChange: false };
  };

  const colorChangeEffect = getColorChangeEffect() || { hasColorChange: false };

  // 🆕 強化効果の計算
  const calculateEnhancementEffects = (insect) => {
    let attackBonus = 0;
    let healthBonus = 0;

    if (insect && insect.appliedEnhancements) {
      insect.appliedEnhancements.forEach(enhancement => {
        if (!enhancement) return;

        if (enhancement.name && enhancement.name.includes('天牛の大顎')) {
          attackBonus += 300;
        }

        if (enhancement.name && enhancement.name.includes('蓑虫の隠れ蓑')) {
          healthBonus += 500;
        }
      });
    }

    return { attackBonus, healthBonus };
  };

  const isDraggable = inHand && canDrag !== false && (gamePhase === 'set' || isPlayable);

  const [{ isDragging }, drag] = useDrag(
    () => ({
      type: 'card',
      item: { card },
      canDrag: isDraggable,
      collect: (monitor) => ({
        isDragging: monitor.isDragging(),
      }),
    }),
    [isDraggable, card]
  );

  const checkElementAdvantage = (attackerElement, defenderElement) => {
    const advantages = {
      'red': 'green',
      'blue': 'red',
      'green': 'blue'
    };
    return advantages[attackerElement] === defenderElement;
  };

  useEffect(() => {
    if (showAdvantageIndicator) {
      const timer = setTimeout(() => {
        setShowAdvantageIndicator(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showAdvantageIndicator]);

  // 🔧 修正: 攻撃2を持つかどうかの判定を特別なケースを含めて判定
  const hasAttack2 = () => {
    // 🆕 特別なケース: ナミアゲハ（幼虫）とカブトムシは攻撃2が0でも選択肢を表示
    if (card.name && (
      (card.name.includes('ナミアゲハ') && card.name.includes('幼虫')) ||
      card.name.includes('カブトムシ')
    )) {
      return card.attack2 !== null && card.attack2 !== undefined;
    }
    
    // 通常のケース: 攻撃2が0より大きい場合のみ
    return card.attack2 !== null && card.attack2 !== undefined && card.attack2 > 0;
  };

  const canReturnFromField = () => {
    if (!inField || !onReturnToHand || card.hasPlayed) {
      return false;
    }

    if (card.hasAttacked || hasAttacked) {
      return false;
    }

    const playedTurn = cardPlayedTurn || card.playedTurn;
    const isCurrentTurn = playedTurn === turnCount;

    return isCurrentTurn;
  };

  const canReturnFromFeed = () => {
    if (!inFeed || !onReturnToHand || card.hasPlayed) {
      return false;
    }

    if (gamePhase === 'main') {
      return false;
    }

    return true;
  };

  const shouldShowReturnButton = () => {
    if (feedAreaSize || smallAreaSize || graveyardSize) {
      return false;
    }

    if (inHand) {
      return false;
    }

    if (inField) {
      return canReturnFromField();
    }

    if (inFeed) {
      return canReturnFromFeed();
    }

    return false;
  };

  const canActuallyReturn = () => {
    if (inField) {
      return canReturnFromField();
    }

    if (inFeed) {
      return canReturnFromFeed();
    }

    return false;
  };

  const handleReturnIconClick = (e) => {
    e.stopPropagation();
    if (canActuallyReturn() && onReturnToHand) {
      onReturnToHand();
    }
  };

  const determineAttackTarget = (attackType = 1) => {
    const validTargets = enemyField?.filter(target => target.type === 'insect' && !target.isFlipped) || [];

    if (!validTargets || validTargets.length === 0) {
      onAttackTarget?.({
        attacker: card,
        target: 'territory',
        attackType: attackType
      });
      return;
    }

    if (validTargets.length === 1) {
      const target = validTargets[0];
      const isAdvantage = checkElementAdvantage(card.element, target.element);

      if (isAdvantage) {
        setShowAdvantageIndicator(true);
      }

      onAttackTarget?.({
        attacker: card,
        target: target,
        attackType: attackType
      });
      return;
    }

    setSelectedAttackType(attackType);
    setShowTargetSelection(true);
  };

  const isCardAttacked = hasAttacked || card.hasAttacked || card.hasAttackedThisTurn;

  const handleCardClick = (e) => {
    e.stopPropagation();

    if (e.ctrlKey || e.metaKey || e.button === 2) {
      onCardClick?.(card);
      return;
    }

    // 🆕 攻撃済み状態の虫を押すと拡大画像が出る
    if (isCardAttacked && inField && card.type === 'insect') {
      onImageClick?.(card);
      return;
    }

    if (inField) {
      if (canAttack && card.type === 'insect' && gamePhase === 'main') {
        if (card.attack1 && hasAttack2()) {
          setShowAttackOptions(true);
        } else {
          determineAttackTarget(1);
        }
      } else {
        onImageClick?.(card);
      }
      return;
    }

    if (inHand) {
      if (canAttack && card.type === 'insect') {
        if (card.attack1 && hasAttack2()) {
          setShowAttackOptions(true);
        } else {
          determineAttackTarget(1);
        }
      } else {
        onImageClick?.(card);
      }
      return;
    }

    if (inFeed) {
      onImageClick?.(card);
      return;
    }
  };

  const handleAttackChoice = (attackType) => {
    setShowAttackOptions(false);
    determineAttackTarget(attackType);
  };

  const handleTargetChoice = (target) => {
    setShowTargetSelection(false);

    if (target !== 'territory') {
      const isAdvantage = checkElementAdvantage(card.element, target.element);
      if (isAdvantage) {
        setShowAdvantageIndicator(true);
      }
    }

    onAttackTarget?.({
      attacker: card,
      target: target,
      attackType: selectedAttackType
    });
  };

  // カードサイズを条件に基づいて調整
  const cardClasses = feedAreaSize
    ? "relative w-full h-full rounded cursor-pointer select-none overflow-hidden"
    : (smallAreaSize || graveyardSize)
    ? "relative w-6 h-8 rounded cursor-pointer select-none overflow-hidden"
    : compact
    ? "relative w-16 h-20 rounded cursor-pointer select-none overflow-hidden"
    : "relative w-24 h-32 rounded-lg cursor-pointer select-none overflow-hidden";

  // 🆕 強化効果を考慮した体力計算
  const maxHealth = inField && getEffectiveMaxHealth ? getEffectiveMaxHealth(card) : card.health;
  const currentHealth = card.currentHealth !== undefined ? card.currentHealth : maxHealth;
  const healthPercentage = maxHealth > 0 ? (currentHealth / maxHealth) * 100 : 0;

  const getHealthColor = () => {
    if (healthPercentage > 70) return 'text-green-400';
    if (healthPercentage > 30) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getHealthBarColor = () => {
    if (healthPercentage > 70) return 'bg-green-500';
    if (healthPercentage > 30) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const isEnemyAttacked = card.hasAttackedThisTurn;

  // 🆕 カードの画像を決定する関数
  const getCardImage = () => {
    if (showBack || isFlipped) {
      return "https://quest-media-storage-bucket.s3.us-east-2.amazonaws.com/1751171703200-back.jpg";
    }
    return card.image_url;
  };

  // 🆕 カードの表示名を決定する関数
  const getCardDisplayName = () => {
    if (isFlipped && !showBack) {
      return "???";
    }
    return card.name;
  };

  // 🆕 弱体化効果を考慮した攻撃力を表示する関数
  const getDisplayAttackPower = (attackType) => {
    if (!getEffectiveAttackPower || !inField) {
      return attackType === 2 ? card.attack2 : (card.attack1 || card.attack);
    }
    return getEffectiveAttackPower(card, attackType);
  };

  // 🆕 強化効果の表示判定
  const enhancementEffects = calculateEnhancementEffects(card);
  const hasEnhancementEffects = enhancementEffects.attackBonus > 0 || enhancementEffects.healthBonus > 0;

  // 🆕 玉虫色の羽化による色変更のカードボーダー効果
  const getCardBorderEffect = () => {
    if (colorChangeEffect?.hasColorChange && colorChangeEffect.colorInfo) {
      const colorInfo = colorChangeEffect.colorInfo;
      return `ring-2 ${colorInfo.borderColor.replace('border-', 'ring-')} shadow-lg shadow-${colorInfo.bgColor.replace('bg-', '')}-400/50`;
    }
    return '';
  };

  // 🔧 修正: 攻撃済みカードのスタイリング（虫タイプのみ）
  const getAttackedCardStyle = () => {
    if (isCardAttacked && inField && card.type === 'insect') {
      return 'ring-2 ring-gray-400 shadow-lg shadow-gray-400/50 hover:ring-gray-300 cursor-pointer';
    }
    return '';
  };

  return (
    <div className="relative">
      <motion.div
        ref={inHand ? drag : null}
        whileHover={
          isPlayable || canAttack || inHand || (isCardAttacked && inField && card.type === 'insect')
            ? { scale: feedAreaSize ? 1.02 : (smallAreaSize || graveyardSize) ? 1.1 : compact ? 1.02 : 1.05 }
            : {}
        }
        whileTap={
          isPlayable || canAttack || inHand || (isCardAttacked && inField && card.type === 'insect')
            ? { scale: feedAreaSize ? 0.98 : (smallAreaSize || graveyardSize) ? 0.9 : compact ? 0.98 : 0.95 }
            : {}
        }
        className={`
          ${cardClasses}
          ${isPlayable ? 'ring-2 ring-emerald-400 shadow-lg shadow-emerald-400/50' : ''}
          ${canAttack ? 'ring-2 ring-red-400 shadow-lg shadow-red-400/50' : ''}
          ${isDraggable ? 'cursor-grab active:cursor-grabbing' : ''}
          ${inHand ? 'hover:ring-2 hover:ring-blue-300 hover:shadow-lg hover:shadow-blue-300/30' : ''}
          ${inField && !canAttack && !isCardAttacked ? 'hover:ring-2 hover:ring-yellow-300 hover:shadow-lg hover:shadow-yellow-300/30' : ''}
          ${isFlipped ? 'ring-2 ring-purple-400 shadow-lg shadow-purple-400/50 opacity-60' : ''}
          ${hasDebuff ? 'ring-2 ring-orange-400 shadow-lg shadow-orange-400/50' : ''}
          ${hasEnhancementEffects && !colorChangeEffect?.hasColorChange ? 'ring-2 ring-yellow-400 shadow-lg shadow-yellow-400/50' : ''}
          ${isNamiagehaTaunt ? 'ring-4 ring-pink-400 shadow-lg shadow-pink-400/70 animate-pulse' : ''}
          ${getCardBorderEffect()}
          ${getAttackedCardStyle()}
          ${hasMimicry ? 'ring-2 ring-cyan-400 shadow-lg shadow-cyan-400/50' : ''}
        `}
        onClick={handleCardClick}
        onContextMenu={handleCardClick}
        style={{ opacity: isDragging ? 0.5 : 1 }}
      >
        {/* 各種インジケーター */}
        {inHand && gamePhase === 'set' && isDraggable && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className={`absolute bottom-1 right-1 ${compact ? 'w-3 h-3' : 'w-4 h-4'} bg-green-500 rounded-full flex items-center justify-center z-10`}>
            <SafeIcon icon={FiPlay} className={`${compact ? 'text-xs' : 'text-xs'} text-white`} />
          </div>
        )}

        {inField && canAttack && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className={`absolute top-1 right-1 ${compact ? 'w-3 h-3' : 'w-4 h-4'} bg-red-500 rounded-full flex items-center justify-center z-10 animate-pulse`}>
            <SafeIcon icon={FiSword} className={`${compact ? 'text-xs' : 'text-xs'} text-white`} />
          </div>
        )}

        {showAdvantageIndicator && (
          <motion.div
            initial={{ scale: 0, opacity: 0, y: -10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0, opacity: 0, y: 10 }}
            transition={{ duration: 0.3 }}
            className={`absolute top-1 left-1 bg-yellow-500 text-black ${(compact || smallAreaSize || graveyardSize) ? 'text-xs' : 'text-xs'} font-bold px-1 py-0.5 rounded-full z-20 shadow-lg`}
          >
            ×2
          </motion.div>
        )}

        {/* 🔧 修正: 擬態効果インジケーター（発動済み） - hasMimicryの状態を厳密にチェック */}
        {hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <motion.div
            key={`mimicry-active-${card.id}-${mimicryRefresh}`} // 🆕 強制リレンダリング用キー
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }} // 🆕 退場アニメーション追加
            className={`absolute top-1 left-1 bg-cyan-500 text-white ${(compact || smallAreaSize || graveyardSize) ? 'text-xs' : 'text-xs'} font-bold px-1 py-0.5 rounded-full z-20 shadow-lg animate-pulse`}
          >
            擬態中
          </motion.div>
        )}

        {/* 🔧 修正: ナナフシモドキの擬態能力インジケーター（完全削除） */}
        {/* hasNanafushiMimicryは常にfalseなので、このブロックは表示されない */}

        {/* 🆕 玉虫色の羽化による色変更インジケーター */}
        {colorChangeEffect?.hasColorChange && colorChangeEffect.colorInfo && !feedAreaSize && !smallAreaSize && !graveyardSize && !hasMimicry && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`absolute top-1 left-1 ${colorChangeEffect.colorInfo.bgColor} text-white ${(compact || smallAreaSize || graveyardSize) ? 'text-xs' : 'text-xs'} font-bold px-1 py-0.5 rounded-full z-20 shadow-lg flex items-center gap-1`}
          >
            <span className="text-xs">{colorChangeEffect.colorInfo.emoji}</span>
            <span className="text-xs">{colorChangeEffect.colorInfo.name}</span>
          </motion.div>
        )}

        {/* 🆕 ナミアゲハの挑発効果インジケーター */}
        {isNamiagehaTaunt && !colorChangeEffect?.hasColorChange && !hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`absolute top-1 left-1 bg-pink-500 text-white ${(compact || smallAreaSize || graveyardSize) ? 'text-xs' : 'text-xs'} font-bold px-1 py-0.5 rounded-full z-20 shadow-lg animate-pulse`}
          >
            挑発
          </motion.div>
        )}

        {/* カード画像部分 */}
        <div className={`w-full h-full ${(hasAttacked || isEnemyAttacked) ? 'opacity-60' : ''} ${hasDebuff ? 'filter brightness-75' : ''} ${hasEnhancementEffects ? 'filter brightness-110' : ''} ${isNamiagehaTaunt ? 'filter brightness-125 hue-rotate-15' : ''} ${colorChangeEffect?.hasColorChange && colorChangeEffect.color ? `filter brightness-110 ${colorChangeEffect.color === 'red' ? 'hue-rotate-0' : colorChangeEffect.color === 'blue' ? 'hue-rotate-180' : 'hue-rotate-90'}` : ''} ${hasMimicry ? 'filter brightness-125 saturate-150' : ''}`}>
          {getCardImage() ? (
            <img
              src={getCardImage()}
              alt={getCardDisplayName()}
              className={`w-full h-full ${feedAreaSize || smallAreaSize || graveyardSize ? 'rounded' : 'rounded-lg'}`}
            />
          ) : (
            <div className={`w-full h-full bg-gradient-to-br from-gray-600 to-gray-800 ${feedAreaSize || smallAreaSize || graveyardSize ? 'rounded' : 'rounded-lg'} flex items-center justify-center`}>
              <span className={`text-white text-center p-1 ${feedAreaSize ? 'text-xs leading-tight' : (smallAreaSize || graveyardSize) ? 'text-xs p-0.5' : compact ? 'text-xs p-1' : 'text-xs p-2'}`}>
                {feedAreaSize ? getCardDisplayName().substring(0, 4) : (smallAreaSize || graveyardSize) ? getCardDisplayName().substring(0, 2) : compact ? getCardDisplayName().substring(0, 6) : getCardDisplayName()}
              </span>
            </div>
          )}
        </div>

        {/* 体力バー部分 */}
        {inField && card.type === 'insect' && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute bottom-0 left-0 right-0 bg-black/80 px-1 py-0.5 z-10">
            <div className={`w-full ${compact ? 'h-0.5' : 'h-1'} bg-gray-600 rounded-full mb-1`}>
              <div
                className={`h-full rounded-full transition-all duration-300 ${getHealthBarColor()}`}
                style={{ width: `${Math.max(0, healthPercentage)}%` }}
              />
            </div>
            <div className="flex items-center justify-center gap-1">
              <SafeIcon icon={FiHeart} className={`${compact ? 'text-xs' : 'text-xs'} ${getHealthColor()}`} />
              <span className={`${compact ? 'text-xs' : 'text-xs'} font-bold ${getHealthColor()}`}>
                {currentHealth}/{maxHealth}
                {enhancementEffects.healthBonus > 0 && (
                  <span className="text-yellow-300 ml-1">(+{enhancementEffects.healthBonus})</span>
                )}
              </span>
            </div>
          </div>
        )}

        {/* 戻しボタン */}
        {shouldShowReturnButton() && (
          <motion.div
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleReturnIconClick}
            className={`
              absolute -bottom-1 -left-1 ${compact ? 'w-4 h-4' : 'w-5 h-5'} rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 hover:shadow-lg z-30
              ${canActuallyReturn() ? 'bg-blue-500 hover:bg-blue-400' : 'bg-gray-600 hover:bg-gray-500'}
            `}
            title={
              inField ? (
                canActuallyReturn()
                  ? '手札に戻す（同じターンのみ）'
                  : card.hasAttacked || hasAttacked
                  ? '攻撃済みのため戻せません'
                  : 'このターンに出したカードではありません'
              ) : inFeed ? (
                canActuallyReturn()
                  ? 'エサ場から手札に戻す'
                  : 'メインフェーズでは戻せません'
              ) : '手札に戻す'
            }
          >
            <SafeIcon icon={canActuallyReturn() ? FiRotateCcw : FiLock} className={`${compact ? 'text-xs' : 'text-xs'} text-white`} />
          </motion.div>
        )}

        {/* 攻撃済み表示とクリックヒント（虫タイプのみ） */}
        {(hasAttacked || isEnemyAttacked) && card.type === 'insect' && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            <div className={`bg-red-600/80 px-2 py-1 rounded text-white font-bold ${(compact || smallAreaSize || graveyardSize) ? 'text-xs' : 'text-xs'} text-center`}>
              <div>攻撃済</div>
              {inField && !compact && (
                <div className="text-xs text-red-200 mt-1">クリックで拡大</div>
              )}
            </div>
          </div>
        )}

        {/* 裏向きカードの無効化表示 */}
        {isFlipped && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            <div className="bg-purple-600/80 px-2 py-1 rounded text-white font-bold text-xs">
              無効
            </div>
          </div>
        )}

        {/* 🔧 修正: 擬態効果の詳細表示（発動済み） - hasMimicryの状態を厳密にチェック */}
        {hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-19">
            <div className="bg-cyan-600/80 px-2 py-1 rounded text-white font-bold text-xs">
              擬態中
            </div>
          </div>
        )}

        {/* 🔧 修正: ナナフシモドキの擬態能力詳細表示（完全削除） */}
        {/* hasNanafushiMimicryは常にfalseなので、このブロックは表示されない */}

        {/* 玉虫色の羽化による色変更の詳細表示 */}
        {colorChangeEffect?.hasColorChange && colorChangeEffect.colorInfo && !hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-19">
            <div className={`${colorChangeEffect.colorInfo.bgColor}/90 px-2 py-1 rounded text-white font-bold text-xs flex items-center gap-1`}>
              <span>{colorChangeEffect.colorInfo.emoji}</span>
              <span>{colorChangeEffect.colorInfo.name}属性</span>
            </div>
          </div>
        )}

        {/* 弱体化効果の詳細表示 */}
        {hasDebuff && !isFlipped && !isNamiagehaTaunt && !colorChangeEffect?.hasColorChange && !hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-19">
            <div className="bg-orange-600/80 px-2 py-1 rounded text-white font-bold text-xs">
              弱体化中
            </div>
          </div>
        )}

        {/* 強化効果の詳細表示 */}
        {hasEnhancementEffects && !isFlipped && !hasDebuff && !isNamiagehaTaunt && !colorChangeEffect?.hasColorChange && !hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-19">
            <div className="bg-yellow-600/80 px-2 py-1 rounded text-black font-bold text-xs">
              強化中
            </div>
          </div>
        )}

        {/* ナミアゲハの挑発効果の詳細表示 */}
        {isNamiagehaTaunt && !colorChangeEffect?.hasColorChange && !hasMimicry && !feedAreaSize && !smallAreaSize && !graveyardSize && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-19">
            <div className="bg-pink-600/80 px-2 py-1 rounded text-white font-bold text-xs">
              挑発中
            </div>
          </div>
        )}
      </motion.div>

      {/* 攻撃選択モーダル */}
      {showAttackOptions && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-0 left-0 z-50 bg-black/90 rounded-lg p-3 min-w-32"
        >
          <h4 className="text-white text-xs font-bold mb-2 text-center">攻撃選択</h4>
          <div className="space-y-2">
            <button
              onClick={() => handleAttackChoice(1)}
              className="w-full bg-red-600 hover:bg-red-500 text-white text-xs py-1 px-2 rounded flex items-center gap-1"
            >
              <SafeIcon icon={FiSword} className="text-red-300" />
              攻撃1 ({getDisplayAttackPower(1) || 0})
              {enhancementEffects.attackBonus > 0 && (
                <span className="text-yellow-300 text-xs ml-1">(+{enhancementEffects.attackBonus})</span>
              )}
              {hasDebuff && inField && (
                <span className="text-orange-300 text-xs ml-1">(-{debuffInfo.totalDebuff})</span>
              )}
            </button>

            {/* 🔧 修正: ナミアゲハ（幼虫）とカブトムシの攻撃2は威力0でも表示 */}
            {hasAttack2() && (
              <button
                onClick={() => handleAttackChoice(2)}
                className="w-full bg-orange-600 hover:bg-orange-500 text-white text-xs py-1 px-2 rounded flex items-center gap-1"
              >
                <SafeIcon icon={FiSword} className="text-orange-300" />
                攻撃2 ({getDisplayAttackPower(2) || 0})
                {enhancementEffects.attackBonus > 0 && (
                  <span className="text-yellow-300 text-xs ml-1">(+{enhancementEffects.attackBonus})</span>
                )}
                {hasDebuff && inField && (
                  <span className="text-orange-300 text-xs ml-1">(-{debuffInfo.totalDebuff})</span>
                )}
                {/* 🆕 特別なカードの効果表示 */}
                {card.name && card.name.includes('カブトムシ') && (
                  <span className="text-purple-300 text-xs ml-1">裏返し</span>
                )}
                {card.name && card.name.includes('ナミアゲハ') && card.name.includes('幼虫') && (
                  <span className="text-gray-300 text-xs ml-1">無力</span>
                )}
                {card.name && card.name.includes('ナミアゲハ') && !card.name.includes('幼虫') && (
                  <span className="text-blue-300 text-xs ml-1">弱体化</span>
                )}
              </button>
            )}

            <button
              onClick={() => setShowAttackOptions(false)}
              className="w-full bg-gray-600 hover:bg-gray-500 text-white text-xs py-1 px-2 rounded"
            >
              キャンセル
            </button>
          </div>
        </motion.div>
      )}

      {/* ターゲット選択モーダル */}
      {showTargetSelection && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-0 left-0 z-50 bg-black/95 rounded-lg p-4 min-w-48"
        >
          <h4 className="text-white text-sm font-bold mb-3 text-center flex items-center gap-2">
            <SafeIcon icon={FiTarget} className="text-red-400" />
            攻撃対象を選択
          </h4>

          <div className="space-y-2 max-h-32 overflow-y-auto">
            {(!enemyField || enemyField.filter(bug => !bug.isFlipped).length === 0) && (
              <button
                onClick={() => handleTargetChoice('territory')}
                className="w-full bg-orange-600 hover:bg-orange-500 text-white text-xs py-2 px-2 rounded flex items-center gap-2 transition-colors"
              >
                <SafeIcon icon={FiHome} className="text-orange-300" />
                <div className="text-left">
                  <div className="font-semibold">縄張りを直接攻撃</div>
                  {enemyField.filter(bug => bug.isFlipped).length > 0 && (
                    <div className="text-xs text-orange-200">裏向きの虫は守れない</div>
                  )}
                </div>
              </button>
            )}

            {enemyField.filter(bug => !bug.isFlipped).map((enemyInsect, index) => {
              const enemyMaxHealth = getEffectiveMaxHealth ? getEffectiveMaxHealth(enemyInsect) : enemyInsect.health;
              const enemyCurrentHealth = enemyInsect.currentHealth !== undefined ? enemyInsect.currentHealth : enemyMaxHealth;
              const enemyHealthPercentage = enemyMaxHealth > 0 ? (enemyCurrentHealth / enemyMaxHealth) * 100 : 0;
              const isAdvantage = checkElementAdvantage(card.element, enemyInsect.element);

              return (
                <button
                  key={enemyInsect.id || index}
                  onClick={() => handleTargetChoice(enemyInsect)}
                  className={`w-full text-white text-xs py-2 px-2 rounded flex items-center gap-2 transition-colors ${
                    isAdvantage
                      ? 'bg-yellow-600 hover:bg-yellow-500 border border-yellow-400'
                      : 'bg-red-600 hover:bg-red-500'
                  }`}
                >
                  <SafeIcon icon={FiSword} className={isAdvantage ? "text-yellow-300" : "text-red-300"} />
                  <div className="text-left flex-1">
                    <div className="font-semibold flex items-center gap-1">
                      {enemyInsect.name}
                      {isAdvantage && <span className="text-yellow-200 font-bold">×2</span>}
                      {/* 🆕 特別なカードの効果表示 */}
                      {card.name && card.name.includes('カブトムシ') && selectedAttackType === 2 && (
                        <span className="text-purple-300 text-xs">裏返し</span>
                      )}
                      {card.name && card.name.includes('ナミアゲハ') && !card.name.includes('幼虫') && selectedAttackType === 2 && (
                        <span className="text-blue-300 text-xs">弱体化</span>
                      )}
                    </div>
                    <div className="w-full h-1 bg-gray-700 rounded-full mt-1">
                      <div
                        className={`h-full rounded-full ${
                          enemyHealthPercentage > 70 ? 'bg-green-400' : enemyHealthPercentage > 30 ? 'bg-yellow-400' : 'bg-red-400'
                        }`}
                        style={{ width: `${Math.max(0, enemyHealthPercentage)}%` }}
                      />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => setShowTargetSelection(false)}
            className="w-full bg-gray-600 hover:bg-gray-500 text-white text-xs py-1 px-2 rounded mt-2"
          >
            キャンセル
          </button>
        </motion.div>
      )}
    </div>
  );
};

export default Card;