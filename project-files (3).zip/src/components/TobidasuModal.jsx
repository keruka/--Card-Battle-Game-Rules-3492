import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const { FiZap, FiX, FiCheckCircle, FiHome } = FiIcons;

const TobidasuModal = ({ isOpen, card, onConfirm, onCancel }) => {
  if (!isOpen || !card) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
      onClick={onCancel}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-gray-900 rounded-2xl p-6 max-w-md mx-4 border border-yellow-400/30"
        onClick={e => e.stopPropagation()}
      >
        <div className="text-center">
          {/* タイトル */}
          <div className="mb-4">
            <SafeIcon icon={FiZap} className="text-yellow-400 text-4xl mx-auto mb-2" />
            <h3 className="text-white text-xl font-bold mb-2">
              ＜とびだす＞効果発動
            </h3>
            <p className="text-gray-300 text-sm">
              縄張りから手札に移動しました
            </p>
          </div>

          {/* カード表示 */}
          <div className="mb-6 p-4 bg-yellow-900/20 border border-yellow-600/30 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="w-16 h-20 flex-shrink-0">
                <Card card={card} compact={true} />
              </div>
              <div className="text-left">
                <h4 className="text-yellow-300 font-bold text-lg">{card.name}</h4>
                <p className="text-gray-300 text-sm mt-1">
                  {card.passive_effect_text || 'とびだす: 縄張りから手札に移動した時、コストを支払わずに場に出すことができる'}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-yellow-400 text-xs">攻撃力: {card.attack1 || card.attack || 0}</span>
                  <span className="text-yellow-400 text-xs">•</span>
                  <span className="text-yellow-400 text-xs">体力: {card.health}</span>
                  <span className="text-yellow-400 text-xs">•</span>
                  <span className="text-yellow-400 text-xs">通常コスト: {card.cost}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 効果説明 */}
          <div className="bg-green-900/20 border border-green-600/30 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-2 mb-2">
              <SafeIcon icon={FiHome} className="text-green-400" />
              <p className="text-green-200 text-sm font-semibold">
                ＜とびだす＞を使用しますか？
              </p>
            </div>
            <p className="text-xs text-green-300 mb-2">
              ※ コストを支払わずに場に出すことができます
            </p>
            <p className="text-xs text-gray-400">
              ※ 場がいっぱい（5体）の場合は使用できません
            </p>
          </div>

          {/* ボタン */}
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onConfirm}
              className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiCheckCircle} />
              はい、場に出す
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onCancel}
              className="flex-1 bg-gray-600 hover:bg-gray-500 text-white px-4 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <SafeIcon icon={FiX} />
              いいえ、手札に
            </motion.button>
          </div>

          <p className="text-xs text-gray-400 mt-3">
            「いいえ」を選択すると、通常通り手札に残ります
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default TobidasuModal;