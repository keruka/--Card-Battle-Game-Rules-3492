import React from 'react';
import { motion } from 'framer-motion';
import { useDrop } from 'react-dnd';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import Card from './Card';

const { FiCoffee } = FiIcons;

const FeedArea = ({
  feedCards,
  currentCost,
  maxCost,
  onSetFeed,
  isCurrentPlayer,
  gamePhase,
  onReturnToHand,
  compact = false,
  hasSetFeed = false,
  turnCount = 1,
  playerNumber = 1,
  // 🆕 プレイヤー2判定用のプロパティ
  isOpponent = false
}) => {
  const [{ isOver }, drop] = useDrop(
    () => ({
      accept: 'card',
      drop: (item) => {
        if (isCurrentPlayer && gamePhase === 'set' && !hasSetFeed) {
          onSetFeed(item.card);
        }
      },
      canDrop: (item) => {
        return isCurrentPlayer && gamePhase === 'set' && !hasSetFeed;
      },
      collect: (monitor) => ({
        isOver: monitor.isOver() && monitor.canDrop(),
      }),
    }),
    [isCurrentPlayer, gamePhase, hasSetFeed, onSetFeed]
  );

  const feedCount = feedCards.length;

  // カードが手札に戻せるかどうかを判定（メインフェーズでは戻せない）
  const getCardReturnability = (card, index) => {
    // メインフェーズでは一切戻せない
    if (gamePhase === 'main') {
      return false;
    }
    // セットフェーズでは既存のロジックを適用
    const isLastCard = index === feedCards.length - 1;
    const canReturn = turnCount === 1 || isLastCard;
    return canReturn;
  };

  const FeedCard = ({ card, index, compact }) => {
    const canReturnToHand = getCardReturnability(card, index);

    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: index * 0.1 }}
        className={`cursor-pointer overflow-hidden flex-shrink-0 ${compact ? 'w-4 h-6' : 'w-6 h-8'}`} // 🔧 統一サイズに変更
      >
        <div className="w-full h-full">
          <Card
            card={card}
            inFeed={true}
            onReturnToHand={
              isCurrentPlayer && !card.hasPlayed && canReturnToHand ? () => onReturnToHand(card) : null
            }
            canReturnToHand={canReturnToHand}
            turnCount={turnCount}
            cardAddedTurn={index === feedCards.length - 1 ? turnCount : 1}
            compact={true}
            smallAreaSize={true} // 🆕 小エリア統一サイズを使用
            gamePhase={gamePhase}
            onCardClick={(clickedCard) => {
              console.log(`📋 Feed card clicked: ${clickedCard.name}`);
            }}
          />
        </div>
      </motion.div>
    );
  };

  return (
    <div
      ref={drop}
      className={`
        bg-yellow-900/50 rounded-xl p-2 border-4 border-dashed border-yellow-600/50 relative
        ${isOver ? 'border-yellow-400 bg-yellow-400/20' : ''}
        ${hasSetFeed ? 'opacity-60' : ''}
        ${compact ? 'min-h-6' : 'min-h-12'}
      `} // 🔧 修正: 色を濃く、枠を太く
    >
      <h4
        className={`text-white font-semibold text-center flex items-center justify-center gap-1 ${
          compact ? 'text-xs mb-1' : 'text-sm mb-1'
        } ${isOpponent ? 'transform rotate-180' : ''}`}
      >
        <SafeIcon icon={FiCoffee} className={compact ? 'text-xs' : 'text-sm'} />
        エサ場 ({feedCount}枚)
        {/* 🔧 修正: (今ターン済み)の表示を削除 */}
      </h4>
      {/* 🔧 修正: 利用可能コストの表示を削除 */}
      <div className={compact ? 'min-h-4' : 'min-h-8'}>
        {feedCards.length === 0 ? (
          <div
            className={`flex items-center justify-center h-full text-gray-400 ${
              compact ? 'text-xs' : 'text-sm'
            } ${isOpponent ? 'transform rotate-180' : ''}`}
          >
            {isCurrentPlayer && gamePhase === 'set' && !hasSetFeed
              ? compact
                ? 'ドロップ'
                : 'カードをドロップ'
              : 'なし'}
          </div>
        ) : (
          <div className="flex gap-1 justify-start items-center flex-wrap">
            {feedCards.map((card, index) => (
              <FeedCard key={`${card.id}-${index}`} card={card} index={index} compact={compact} />
            ))}
          </div>
        )}
      </div>

      {/* ドロップゾーンハイライト */}
      {isCurrentPlayer && gamePhase === 'set' && !hasSetFeed && (
        <div className="absolute inset-0 border-2 border-dashed border-yellow-300/50 rounded-xl pointer-events-none">
          {isOver && (
            <div className="absolute inset-0 bg-yellow-400/20 rounded-xl border-2 border-yellow-400 animate-pulse" />
          )}
        </div>
      )}

      {/* ドロップ時の視覚的フィードバック */}
      {isOver && (
        <div className="absolute inset-0 bg-yellow-400/20 rounded-xl border-2 border-yellow-400 pointer-events-none" />
      )}
    </div>
  );
};

export default FeedArea;