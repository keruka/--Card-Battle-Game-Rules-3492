import React from 'react';
import {motion} from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const {FiPlay,FiPause,FiSkipForward,FiStopCircle,FiDatabase,FiRefreshCw,FiArrowRight,FiSword}=FiIcons;

const TurnIndicator=({
  currentPlayer,
  gamePhase,
  turnCount,
  onEndTurn,
  isAIProcessing,
  isTurnTransitioning,
  gameSessionId,
  // 🆕 敵攻撃状況表示用のプロパティ
  territoryAttackStatus,
  // 🆕 コンパクトモード
  compact=false
})=> {
  const getPhaseText=()=> {
    switch (gamePhase) {
      case 'draw': return 'ドローフェーズ';
      case 'set': return 'セットフェーズ';
      case 'main': return 'メインフェーズ';
      case 'end': return 'エンドフェーズ';
      default: return 'ターン準備中';
    }
  };

  const getPhaseIcon=()=> {
    switch (gamePhase) {
      case 'draw': return FiRefreshCw;
      case 'set': return FiDatabase;
      case 'main': return FiPlay;
      case 'end': return FiStopCircle;
      default: return FiPlay;
    }
  };

  const getPhaseColor=()=> {
    switch (gamePhase) {
      case 'draw': return 'text-blue-300';
      case 'set': return 'text-yellow-300';
      case 'main': return 'text-green-300';
      case 'end': return 'text-red-300';
      default: return 'text-gray-300';
    }
  };

  const isPlayer2Turn=currentPlayer===2;
  const canEndTurn=currentPlayer===1 && !isAIProcessing && !isTurnTransitioning && gamePhase==='main';

  // 🆕 敵攻撃状況の取得
  const enemyAttackCount=territoryAttackStatus?.enemyAttackCount || 0;
  const canEnemyAttack=territoryAttackStatus?.canEnemyAttack !==false;

  if (compact) {
    return (
      <div className="flex flex-col gap-2">
        <motion.div
          initial={{opacity: 0,x: -20}}
          animate={{opacity: 1,x: 0}}
          className="bg-black/40 backdrop-blur-md rounded-xl px-4 py-2"
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              isTurnTransitioning ? 'bg-yellow-400 animate-pulse' : 
              isPlayer2Turn ? 'bg-red-400 animate-pulse' : 'bg-blue-400 animate-pulse'
            }`} />
            <span className="text-white font-bold text-sm">
              {/* 🎯 P1をプレイヤー1に変更 */}
              プレイヤー{currentPlayer}
              {isPlayer2Turn && <span className="text-red-300 ml-1">(AI)</span>}
            </span>
            <div className="h-3 w-px bg-gray-600" />
            <SafeIcon icon={getPhaseIcon()} className={`${getPhaseColor()} text-sm`} />
            <span className={`font-semibold text-sm ${getPhaseColor()}`}>
              {getPhaseText()}
            </span>
            <div className="h-3 w-px bg-gray-600" />
            {/* 🎯 T1をターン1に変更 */}
            <span className="text-yellow-300 text-sm">ターン{turnCount}</span>
          </div>
        </motion.div>

        {/* プレイヤー1のメインフェーズでのみターン終了ボタンを表示 */}
        {canEndTurn && (
          <motion.button
            whileHover={{scale: 1.05}}
            whileTap={{scale: 0.95}}
            onClick={onEndTurn}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-3 py-2 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all duration-200 text-sm"
          >
            <SafeIcon icon={FiSkipForward} />
            ターン終了
          </motion.button>
        )}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4">
      <motion.div
        initial={{opacity: 0,x: -20}}
        animate={{opacity: 1,x: 0}}
        className="bg-black/40 backdrop-blur-md rounded-xl px-6 py-3"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              isTurnTransitioning ? 'bg-yellow-400 animate-pulse' : 
              isPlayer2Turn ? 'bg-red-400 animate-pulse' : 'bg-blue-400 animate-pulse'
            }`} />
            <SafeIcon icon={FiPlay} className="text-emerald-400" />
            <span className="text-white font-bold">
              {/* 🎯 P1をプレイヤー1に変更 */}
              プレイヤー {currentPlayer} のターン
              {isPlayer2Turn && <span className="text-red-300 ml-1">(AI)</span>}
            </span>
          </div>

          <div className="h-4 w-px bg-gray-600" />

          <div className="flex items-center gap-2">
            <SafeIcon icon={getPhaseIcon()} className={getPhaseColor()} />
            <span className={`font-semibold ${getPhaseColor()}`}>
              {getPhaseText()}
            </span>
          </div>

          <div className="h-4 w-px bg-gray-600" />

          <div className="flex items-center gap-1 text-yellow-300">
            {/* 🎯 T1をターン1に変更 */}
            <span className="text-sm font-medium">ターン {turnCount}</span>
          </div>

          {/* 🆕 敵攻撃状況表示 */}
          {isPlayer2Turn && gamePhase==='main' && (
            <>
              <div className="h-4 w-px bg-gray-600" />
              <div className="flex items-center gap-2">
                <SafeIcon icon={FiSword} className={canEnemyAttack ? 'text-red-400 animate-pulse' : 'text-gray-500'} />
                <span className={`text-xs font-medium ${canEnemyAttack ? 'text-red-300' : 'text-gray-400'}`}>
                  攻撃: {enemyAttackCount}/1
                </span>
              </div>
            </>
          )}
        </div>

        {/* 状態表示 */}
        {(isAIProcessing || isTurnTransitioning) && (
          <div className="mt-2 text-center">
            <span className="text-xs text-gray-400">
              {isTurnTransitioning ? 'ターン移行中...' : 
               isAIProcessing ? 'AI思考中...' : ''}
            </span>
          </div>
        )}

        {/* フェーズ進行ヒント */}
        {currentPlayer===1 && !isAIProcessing && !isTurnTransitioning && (
          <div className="mt-2 text-center">
            <span className="text-xs text-gray-300">
              {gamePhase==='draw' && 'カードを引いてセットフェーズに進行します'}
              {gamePhase==='set' && turnCount===1 && 'エサをセットしてメインフェーズに進みます'}
              {gamePhase==='set' && turnCount >=2 && 'エサをセットしてください（必須）'}
              {gamePhase==='main' && 'カードをプレイしてターンを終了できます'}
              {gamePhase==='end' && '次のプレイヤーのターンに移行します'}
            </span>
          </div>
        )}

        {/* 🆕 AI攻撃制限ヒント */}
        {isPlayer2Turn && gamePhase==='main' && !canEnemyAttack && (
          <div className="mt-2 text-center">
            <span className="text-xs text-orange-300">
              🚫 AIは今ターンで攻撃済み（1回制限）
            </span>
          </div>
        )}
      </motion.div>

      {/* プレイヤー1のメインフェーズでのみターン終了ボタンを表示 */}
      {canEndTurn && (
        <motion.button
          whileHover={{scale: 1.05}}
          whileTap={{scale: 0.95}}
          onClick={onEndTurn}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-4 py-2 rounded-lg font-semibold flex items-center gap-2 transition-all duration-200"
        >
          <SafeIcon icon={FiSkipForward} />
          ターン終了
        </motion.button>
      )}

      {/* プレイヤー2の場合はAI動作中表示 */}
      {isPlayer2Turn && (
        <motion.div
          initial={{opacity: 0}}
          animate={{opacity: 1}}
          className="bg-gradient-to-r from-red-600/20 to-orange-600/20 border border-red-400/30 text-red-300 px-4 py-2 rounded-lg font-semibold flex items-center gap-2"
        >
          <motion.div
            animate={{rotate: 360}}
            transition={{duration: 2,repeat: Infinity,ease: "linear"}}
            className="w-2 h-2 bg-red-400 rounded-full"
          />
          {isAIProcessing ? 'AI行動中...' : 'AI待機中...'}
          {gamePhase==='main' && !canEnemyAttack && (
            <span className="text-orange-300 text-xs ml-1">(攻撃済み)</span>
          )}
        </motion.div>
      )}

      {/* ターン移行中の表示 */}
      {isTurnTransitioning && (
        <motion.div
          initial={{opacity: 0}}
          animate={{opacity: 1}}
          className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-400/30 text-yellow-300 px-4 py-2 rounded-lg font-semibold flex items-center gap-2"
        >
          <SafeIcon icon={FiRefreshCw} className="animate-spin" />
          ターン移行中...
        </motion.div>
      )}
    </div>
  );
};

export default TurnIndicator;