import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiHome, FiAlertTriangle, FiShield } = FiIcons;

const TerritoryArea = ({
  territory,
  compact = false,
  // 🆕 縄張り攻撃状況表示用のプロパティ
  hasBeenAttacked = false,
  attackCount = 0,
  isCurrentPlayer = false,
  playerNumber = 1,
  // 🆕 プレイヤー2判定用のプロパティ
  isOpponent = false
}) => {
  // 🆕 縄張り状況に応じたスタイリング - 色を濃く
  const getTerritoryStatusStyle = () => {
    if (territory.length === 0) {
      return 'border-red-500 bg-red-900/70 border-4'; // 🔧 修正: 色を濃く、枠を太く
    }
    if (hasBeenAttacked) {
      return 'border-orange-500 bg-orange-900/70 animate-pulse border-4'; // 🔧 修正: 色を濃く、枠を太く
    }
    if (territory.length <= 2) {
      return 'border-yellow-500 bg-yellow-900/70 border-4'; // 🔧 修正: 色を濃く、枠を太く
    }
    return 'border-blue-600/50 bg-blue-900/50 border-4'; // 🔧 修正: 色を濃く、枠を太く
  };

  // 🆕 縄張り状況メッセージ
  const getTerritoryStatusMessage = () => {
    if (territory.length === 0) {
      return isCurrentPlayer ? '次の攻撃で敗北！' : '勝利まであと一歩！';
    }
    if (hasBeenAttacked && attackCount > 0) {
      return `今ターン ${attackCount}回攻撃された！`;
    }
    if (territory.length <= 2) {
      return '縄張りが少なくなっています';
    }
    return null;
  };

  const statusMessage = getTerritoryStatusMessage();

  return (
    <div
      className={`
        rounded-xl p-2 border-dashed ${getTerritoryStatusStyle()}
        ${compact ? 'min-h-6' : 'min-h-12'}
        transition-all duration-300
      `}
    >
      <h4
        className={`
          text-white font-semibold text-center flex items-center justify-center gap-1
          ${compact ? 'text-xs mb-1' : 'text-sm mb-1'}
          ${isOpponent ? 'transform rotate-180' : ''}
        `}
      >
        <SafeIcon icon={FiHome} className={compact ? 'text-xs' : 'text-sm'} />
        縄張り ({territory.length}/6)
        {/* 🆕 攻撃警告アイコン */}
        {hasBeenAttacked && (
          <SafeIcon
            icon={FiAlertTriangle}
            className={`${compact ? 'text-xs' : 'text-sm'} text-orange-400 animate-bounce`}
          />
        )}
        {/* 🆕 保護されている状態のアイコン */}
        {territory.length >= 5 && (
          <SafeIcon
            icon={FiShield}
            className={`${compact ? 'text-xs' : 'text-sm'} text-green-400`}
          />
        )}
      </h4>

      {/* 🆕 状況メッセージ表示 */}
      {statusMessage && !compact && (
        <div className={`text-center mb-2 ${isOpponent ? 'transform rotate-180' : ''}`}>
          <span
            className={`
              text-xs font-bold px-2 py-1 rounded
              ${territory.length === 0 ? 'bg-red-600/80 text-white' : hasBeenAttacked ? 'bg-orange-600/80 text-white' : 'bg-yellow-600/80 text-white'}
            `}
          >
            {statusMessage}
          </span>
        </div>
      )}

      <div className={compact ? 'min-h-4' : 'min-h-8'}>
        {territory.length === 0 ? (
          <div
            className={`
              flex items-center justify-center h-full text-red-400 font-bold
              ${compact ? 'text-xs' : 'text-sm'} animate-pulse
              ${isOpponent ? 'transform rotate-180' : ''}
            `}
          >
            危険！
          </div>
        ) : (
          <div className="flex gap-1 justify-center items-center">
            {territory.map((_, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`
                  rounded border border-blue-400/50
                  ${compact ? 'w-4 h-6' : 'w-6 h-8'}
                  hover:bg-blue-600/50 transition-colors overflow-hidden flex-shrink-0
                  ${hasBeenAttacked ? 'ring-2 ring-orange-400 ring-opacity-75' : ''}
                `}
                whileHover={{ scale: 1.05, y: -2 }}
              >
                <img
                  src="https://quest-media-storage-bucket.s3.us-east-2.amazonaws.com/1751171703200-back.jpg"
                  alt="Card back"
                  className="w-full h-full object-cover rounded"
                />
                {/* 🆕 攻撃された縄張りカードのエフェクト */}
                {hasBeenAttacked && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 1, 0] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="absolute inset-0 bg-orange-400/30 rounded"
                  />
                )}
              </motion.div>
            ))}
            {/* 空の縄張りスロット */}
            {Array.from({ length: 6 - territory.length }).map((_, index) => (
              <div
                key={`empty-${index}`}
                className={`
                  rounded border-2 border-dashed border-blue-400/30
                  ${compact ? 'w-4 h-6' : 'w-6 h-8'}
                  bg-blue-900/10 flex-shrink-0 flex items-center justify-center
                `}
              >
                {/* 🆕 空スロットに縄張り番号表示 */}
                <span
                  className={`
                    text-blue-400/50 font-bold
                    ${compact ? 'text-xs' : 'text-sm'}
                    ${isOpponent ? 'transform rotate-180' : ''}
                  `}
                >
                  {territory.length + index + 1}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 🆕 敵プレイヤーの縄張り攻撃予告 */}
      {!isCurrentPlayer && territory.length > 0 && !compact && (
        <div className={`mt-1 text-center ${isOpponent ? 'transform rotate-180' : ''}`}>
          <span className="text-xs text-blue-300 opacity-75">
            💡 敵のムシがいない時に直接攻撃される
          </span>
        </div>
      )}
    </div>
  );
};

export default TerritoryArea;