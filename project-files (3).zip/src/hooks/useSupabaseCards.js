import { useState, useEffect, useCallback } from 'react';
import supabase from '../lib/supabase';

export const useSupabaseCards = () => {
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadCards = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('cards_mushi_a7x9k2')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCards(data || []);
      setError(null);
    } catch (err) {
      console.error('Error loading cards:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const createCard = useCallback(async (cardData) => {
    try {
      const { data, error } = await supabase
        .from('cards_mushi_a7x9k2')
        .insert([cardData])
        .select()
        .single();

      if (error) throw error;
      
      await loadCards();
      return data;
    } catch (err) {
      console.error('Error creating card:', err);
      setError(err.message);
      throw err;
    }
  }, [loadCards]);

  const updateCard = useCallback(async (cardId, cardData) => {
    try {
      const { data, error } = await supabase
        .from('cards_mushi_a7x9k2')
        .update(cardData)
        .eq('id', cardId)
        .select()
        .single();

      if (error) throw error;
      
      await loadCards();
      return data;
    } catch (err) {
      console.error('Error updating card:', err);
      setError(err.message);
      throw err;
    }
  }, [loadCards]);

  const deleteCard = useCallback(async (cardId) => {
    try {
      const { error } = await supabase
        .from('cards_mushi_a7x9k2')
        .delete()
        .eq('id', cardId);

      if (error) throw error;
      
      await loadCards();
    } catch (err) {
      console.error('Error deleting card:', err);
      setError(err.message);
      throw err;
    }
  }, [loadCards]);

  const uploadCardImage = useCallback(async (file) => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `card-${Date.now()}.${fileExt}`;
      const filePath = `card-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('card-images')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('card-images')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (err) {
      console.error('Error uploading image:', err);
      setError(err.message);
      throw err;
    }
  }, []);

  const convertToGameFormat = useCallback((dbCard) => {
    return {
      id: dbCard.id,
      name: dbCard.name,
      type: dbCard.type,
      cost: dbCard.cost,
      attack: dbCard.attack,
      health: dbCard.health,
      element: dbCard.element,
      rarity: dbCard.rarity,
      effect: dbCard.effect_text,
      image_url: dbCard.image_url
    };
  }, []);

  useEffect(() => {
    loadCards();
  }, [loadCards]);

  return {
    cards,
    loading,
    error,
    loadCards,
    createCard,
    updateCard,
    deleteCard,
    uploadCardImage,
    convertToGameFormat
  };
};