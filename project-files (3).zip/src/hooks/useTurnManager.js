import { useState, useCallback, useRef, useEffect } from 'react';

export const useTurnManager = () => {
  const [currentPlayer, setCurrentPlayer] = useState(1);
  const [gamePhase, setGamePhase] = useState('setup');
  const [turnCount, setTurnCount] = useState(0);
  const [gameSessionId, setGameSessionId] = useState(null);
  const [turnHistory, setTurnHistory] = useState([]);

  const turnTransitionRef = useRef(false);
  const aiProcessingRef = useRef(false);
  const phaseTransitionRef = useRef(false);
  const executedPhasesRef = useRef(new Map());

  const turnStateRef = useRef({
    currentPlayer: 1,
    gamePhase: 'setup',
    turnCount: 0,
    lastUpdate: Date.now()
  });

  const updateTurnState = useCallback(async (newState) => {
    try {
      const timestamp = Date.now();
      const turnData = {
        ...newState,
        lastUpdate: timestamp,
        turnHistory: [...turnHistory, {
          player: newState.currentPlayer,
          phase: newState.gamePhase,
          turnCount: newState.turnCount,
          timestamp: new Date().toISOString()
        }]
      };

      turnStateRef.current = turnData;
      setCurrentPlayer(newState.currentPlayer);
      setGamePhase(newState.gamePhase);
      setTurnCount(newState.turnCount);
      setTurnHistory(turnData.turnHistory);

      const turnKey = `${newState.currentPlayer}-${newState.turnCount}`;
      if (!executedPhasesRef.current.has(turnKey)) {
        executedPhasesRef.current.set(turnKey, new Set());
      }

      return turnData;
    } catch (error) {
      console.error('❌ Turn state update failed:', error);
      return null;
    }
  }, [turnHistory]);

  const isPhaseExecuted = useCallback((player, turn, phase) => {
    const turnKey = `${player}-${turn}`;
    const executedPhases = executedPhasesRef.current.get(turnKey);
    return executedPhases ? executedPhases.has(phase) : false;
  }, []);

  const markPhaseAsExecuted = useCallback((player, turn, phase) => {
    const turnKey = `${player}-${turn}`;
    if (!executedPhasesRef.current.has(turnKey)) {
      executedPhasesRef.current.set(turnKey, new Set());
    }
    executedPhasesRef.current.get(turnKey).add(phase);
  }, []);

  const initializeGameSession = useCallback(async () => {
    try {
      const sessionId = 'session-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
      setGameSessionId(sessionId);
      executedPhasesRef.current.clear();
      await updateTurnState({
        currentPlayer: 1,
        gamePhase: 'set',
        turnCount: 1
      });
      return sessionId;
    } catch (error) {
      console.error('Failed to initialize game session:', error);
      executedPhasesRef.current.clear();
      await updateTurnState({
        currentPlayer: 1,
        gamePhase: 'set',
        turnCount: 1
      });
      return null;
    }
  }, [updateTurnState]);

  const advancePhase = useCallback(async () => {
    if (phaseTransitionRef.current) {
      return false;
    }

    phaseTransitionRef.current = true;
    try {
      const currentState = turnStateRef.current;
      markPhaseAsExecuted(currentState.currentPlayer, currentState.turnCount, currentState.gamePhase);

      let nextPhase = currentState.gamePhase;
      switch (currentState.gamePhase) {
        case 'draw':
          nextPhase = 'set';
          break;
        case 'set':
          nextPhase = 'main';
          break;
        case 'main':
          nextPhase = 'end';
          break;
        case 'end':
          markPhaseAsExecuted(currentState.currentPlayer, currentState.turnCount, 'end');
          return await transitionToNextPlayer();
        default:
          if (currentState.currentPlayer === 1 && currentState.turnCount === 1) {
            nextPhase = 'set';
          } else {
            nextPhase = 'draw';
          }
      }

      await updateTurnState({
        currentPlayer: currentState.currentPlayer,
        gamePhase: nextPhase,
        turnCount: currentState.turnCount
      });

      return true;
    } catch (error) {
      console.error('❌ Phase transition failed:', error);
      return false;
    } finally {
      phaseTransitionRef.current = false;
    }
  }, [updateTurnState, markPhaseAsExecuted]);

  const transitionToNextPlayer = useCallback(async () => {
    if (turnTransitionRef.current) {
      return false;
    }

    turnTransitionRef.current = true;
    try {
      const currentState = turnStateRef.current;
      const nextPlayer = currentState.currentPlayer === 1 ? 2 : 1;
      const nextTurnCount = nextPlayer === 1 ? currentState.turnCount + 1 : currentState.turnCount;
      const nextPhase = (nextPlayer === 1 && nextTurnCount === 1) ? 'set' : 'draw';

      const newTurnKey = `${nextPlayer}-${nextTurnCount}`;
      if (!executedPhasesRef.current.has(newTurnKey)) {
        executedPhasesRef.current.set(newTurnKey, new Set());
      }

      await new Promise(resolve => setTimeout(resolve, 300));

      await updateTurnState({
        currentPlayer: nextPlayer,
        gamePhase: nextPhase,
        turnCount: nextTurnCount
      });

      return true;
    } catch (error) {
      console.error('❌ Turn transition failed:', error);
      return false;
    } finally {
      turnTransitionRef.current = false;
    }
  }, [updateTurnState]);

  const transitionToPhase = useCallback(async (newPhase) => {
    const currentState = turnStateRef.current;
    if (isPhaseExecuted(currentState.currentPlayer, currentState.turnCount, newPhase)) {
      return false;
    }

    await updateTurnState({
      currentPlayer: currentPlayer,
      gamePhase: newPhase,
      turnCount: turnCount
    });
    return true;
  }, [currentPlayer, turnCount, updateTurnState, isPhaseExecuted]);

  const startAITurn = useCallback(async () => {
    if (currentPlayer !== 2) {
      return;
    }

    if (aiProcessingRef.current) {
      return;
    }

    if (isPhaseExecuted(currentPlayer, turnCount, gamePhase)) {
      return;
    }

    aiProcessingRef.current = true;
    try {
      const currentState = turnStateRef.current;
      switch (currentState.gamePhase) {
        case 'draw':
          await new Promise(resolve => setTimeout(resolve, 1000));
          await advancePhase();
          break;
        case 'set':
          break;
        case 'main':
          break;
        case 'end':
          await new Promise(resolve => setTimeout(resolve, 500));
          await advancePhase();
          break;
      }
    } catch (error) {
      console.error('❌ AI turn failed:', error);
    } finally {
      aiProcessingRef.current = false;
    }
  }, [currentPlayer, gamePhase, turnCount, isPhaseExecuted, advancePhase]);

  const endPlayerTurn = useCallback(async () => {
    if (aiProcessingRef.current || turnTransitionRef.current) {
      return false;
    }

    await updateTurnState({
      currentPlayer: currentPlayer,
      gamePhase: 'end',
      turnCount: turnCount
    });

    await new Promise(resolve => setTimeout(resolve, 500));
    return await transitionToNextPlayer();
  }, [currentPlayer, turnCount, updateTurnState, transitionToNextPlayer]);

  useEffect(() => {
    if (currentPlayer === 2 && !aiProcessingRef.current && !turnTransitionRef.current && 
        !isPhaseExecuted(currentPlayer, turnCount, gamePhase)) {
      const timer = setTimeout(() => {
        startAITurn();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, gamePhase, turnCount, startAITurn, isPhaseExecuted]);

  const restoreGameSession = useCallback(async (sessionId) => {
    try {
      setGameSessionId(sessionId);
      setCurrentPlayer(1);
      setGamePhase('setup');
      setTurnCount(0);
      setTurnHistory([]);
      executedPhasesRef.current.clear();

      turnStateRef.current = {
        currentPlayer: 1,
        gamePhase: 'setup',
        turnCount: 0,
        lastUpdate: Date.now()
      };

      return {
        currentPlayer: 1,
        gamePhase: 'setup',
        turnCount: 0
      };
    } catch (error) {
      console.error('Failed to restore game session:', error);
      return null;
    }
  }, []);

  const getTurnHistory = useCallback(() => {
    return turnHistory.map((entry, index) => ({
      id: index,
      player: entry.player,
      phase: entry.phase,
      turn: entry.turnCount,
      timestamp: entry.timestamp,
      description: `プレイヤー${entry.player} - ${entry.phase}フェーズ (ターン${entry.turnCount})`
    }));
  }, [turnHistory]);

  const getExecutedPhases = useCallback(() => {
    const result = {};
    for (const [turnKey, phases] of executedPhasesRef.current.entries()) {
      result[turnKey] = Array.from(phases);
    }
    return result;
  }, []);

  return {
    currentPlayer,
    gamePhase,
    turnCount,
    gameSessionId,
    isAIProcessing: aiProcessingRef.current,
    isTurnTransitioning: turnTransitionRef.current,
    initializeGameSession,
    transitionToNextPlayer,
    startAITurn,
    endPlayerTurn,
    transitionToPhase,
    advancePhase,
    restoreGameSession,
    getTurnHistory,
    getCurrentTurnState: () => turnStateRef.current,
    isPhaseExecuted,
    markPhaseAsExecuted,
    getExecutedPhases,
    turnHistory
  };
};