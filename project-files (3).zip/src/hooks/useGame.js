import { useState, useCallback, useRef, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { createInitialDeck, shuffleDeck } from '../utils/cardUtils';
import { useTurnManager } from './useTurnManager';

// Lazy import Supabase to prevent blocking
let supabaseInstance = null;
const getSupabase = async () => {
  if (!supabaseInstance) {
    try {
      const { default: supabase } = await import('../lib/supabase');
      supabaseInstance = supabase;
    } catch (error) {
      console.warn('Supabase not available:', error);
      return null;
    }
  }
  return supabaseInstance;
};

export const useGame = () => {
  const [gameState, setGameState] = useState(null);
  const [gameLog, setGameLog] = useState([]);
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState(null);
  const [showPhaseConfirmation, setShowPhaseConfirmation] = useState(false);
  const [lastSetCard, setLastSetCard] = useState(null);
  const [mimicryRefresh, setMimicryRefresh] = useState(0);

  const {
    currentPlayer,
    gamePhase,
    turnCount,
    gameSessionId,
    isAIProcessing,
    isTurnTransitioning,
    initializeGameSession,
    endPlayerTurn,
    advancePhase,
    getTurnHistory,
    isPhaseExecuted,
    markPhaseAsExecuted
  } = useTurnManager();

  const gameRefs = useRef({
    turnInitialized: new Map(),
    turnStartFeedCount: new Map(),
    cardTurnAdded: new Map(),
    cardPlayedTurn: new Map(),
    enemyAttackHistory: new Map(),
    territoryAttackHistory: new Map(),
    enemyAttackCount: new Map(),
    debuffHistory: new Map(),
    locustSpellEffects: new Map(),
    breathOfInsectsCards: new Map(),
    phaseLogTracker: new Map(),
    mimicryEffects: new Map(),
    cardNames: new Map(),
    // 🆕 セアカゴケグモの攻撃2使用履歴管理
    seakagokeGumoAttack2Usage: new Map()
  });

  const addLog = useCallback((message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = {
      message,
      type,
      timestamp,
      player: currentPlayer,
      turn: turnCount,
      phase: gamePhase
    };
    console.log(`📝 [${type.toUpperCase()}] ${message}`);
    setGameLog(prev => [...prev, logEntry]);
    return logEntry;
  }, [currentPlayer, turnCount, gamePhase]);

  // 🆕 セアカゴケグモの攻撃2使用制限管理システム
  const manageSeakagokeGumoAttack2 = useCallback({
    // 攻撃2を使用済みとしてマーク
    markUsed: (cardId, playerNumber, turnNumber) => {
      const usageKey = `${cardId}-${playerNumber}`;
      gameRefs.current.seakagokeGumoAttack2Usage.set(usageKey, {
        cardId,
        playerNumber,
        usedTurn: turnNumber,
        usedTimestamp: Date.now(),
        isUsed: true
      });
      console.log(`🕷️ セアカゴケグモ攻撃2使用記録: カードID ${cardId}, プレイヤー${playerNumber}, ターン${turnNumber}`);
    },

    // 攻撃2が使用済みかチェック
    hasUsedAttack2: (cardId, playerNumber) => {
      const usageKey = `${cardId}-${playerNumber}`;
      const usage = gameRefs.current.seakagokeGumoAttack2Usage.get(usageKey);
      return usage ? usage.isUsed : false;
    },

    // 攻撃2が使用可能かチェック
    canUseAttack2: (cardId, playerNumber, cardName) => {
      // セアカゴケグモ以外は制限なし
      if (!cardName || !cardName.includes('セアカゴケグモ')) {
        return true;
      }

      return !manageSeakagokeGumoAttack2.hasUsedAttack2(cardId, playerNumber);
    },

    // 使用履歴をリセット（カードが場を離れた時など）
    resetUsage: (cardId, playerNumber) => {
      const usageKey = `${cardId}-${playerNumber}`;
      gameRefs.current.seakagokeGumoAttack2Usage.delete(usageKey);
      console.log(`🕷️ セアカゴケグモ攻撃2使用履歴リセット: カードID ${cardId}, プレイヤー${playerNumber}`);
    },

    // 全ての使用履歴を取得
    getAllUsage: () => {
      return new Map(gameRefs.current.seakagokeGumoAttack2Usage);
    },

    // デバッグ用：使用状況をログ出力
    debugUsage: (cardId, playerNumber, cardName) => {
      if (cardName && cardName.includes('セアカゴケグモ')) {
        const hasUsed = manageSeakagokeGumoAttack2.hasUsedAttack2(cardId, playerNumber);
        const canUse = manageSeakagokeGumoAttack2.canUseAttack2(cardId, playerNumber, cardName);
        console.log(`🕷️🔍 ${cardName} 攻撃2状態チェック:`, {
          cardId,
          playerNumber,
          hasUsed,
          canUse,
          usageKey: `${cardId}-${playerNumber}`
        });
      }
    }
  }, []);

  const checkElementAdvantage = useCallback((attackerElement, defenderElement) => {
    const advantages = {
      'red': 'green',
      'blue': 'red',
      'green': 'blue'
    };
    return advantages[attackerElement] === defenderElement;
  }, []);

  // 🆕 ナミアゲハの挑発効果をチェックする関数
  const checkTauntEffect = useCallback((targetPlayerField) => {
    const namiagehaCards = targetPlayerField.filter(
      card => card.type === 'insect' && card.name && card.name.includes('ナミアゲハ') && !card.name.includes('幼虫') && !card.isFlipped
    );
    
    if (namiagehaCards.length > 0) {
      console.log(`🦋 ナミアゲハの挑発効果発動中: ${namiagehaCards.length}体のナミアゲハ（成虫）が場にいます`);
      return {
        hasTaunt: true,
        tauntCards: namiagehaCards,
        validTargets: namiagehaCards
      };
    }
    
    return {
      hasTaunt: false,
      tauntCards: [],
      validTargets: targetPlayerField.filter(card => card.type === 'insect' && !card.isFlipped)
    };
  }, []);

  // 🔧 修正: 擬態効果管理システム - 場にいないもの扱い
  const manageMimicryEffects = useCallback({
    apply: (cardId, playerId, currentTurn, cardName) => {
      gameRefs.current.cardNames.set(cardId, cardName);
      const enemyPlayer = playerId === 1 ? 2 : 1;
      gameRefs.current.mimicryEffects.set(cardId, {
        playerId,
        enemyPlayer,
        activatedTurn: currentTurn,
        isActive: true,
        cardName
      });
      console.log(`🦎 擬態効果適用: ${cardName} (ID: ${cardId}), プレイヤー${playerId}, 現在ターン: ${currentTurn}, 敵プレイヤー: ${enemyPlayer}`);
    },

    isActive: (cardId, currentTurn, currentPhase, activePlayer) => {
      const mimicry = gameRefs.current.mimicryEffects.get(cardId);
      if (!mimicry) return false;
      return mimicry.isActive;
    },

    getEffect: (cardId) => {
      return gameRefs.current.mimicryEffects.get(cardId) || null;
    },

    updateForPhase: (currentTurn, currentPhase, activePlayer) => {
      console.log(`🦎 擬態効果フェーズ更新: ターン${currentTurn}, フェーズ${currentPhase}, アクティブプレイヤー${activePlayer}`);
      for (const [cardId, effect] of gameRefs.current.mimicryEffects.entries()) {
        if (!effect.isActive) continue;
        
        console.log(`🦎 擬態効果チェック: ${effect.cardName} (ID: ${cardId}), 所有者P${effect.playerId}, 敵P${effect.enemyPlayer}, 現在アクティブP${activePlayer}, フェーズ${currentPhase}`);
        
        const isEnemyEndPhase = (
          currentPhase === 'end' && activePlayer === effect.enemyPlayer
        );
        
        if (isEnemyEndPhase) {
          effect.isActive = false;
          console.log(`🦎 擬態効果期限切れ（敵P${effect.enemyPlayer}のエンドフェーズ）: ${effect.cardName} (ID: ${cardId}), 所有者P${effect.playerId}`);
          addLog(`🦎 ${effect.cardName}の擬態効果が敵のエンドフェーズで解除されました！`, 'info');
          setMimicryRefresh(prev => prev + 1);
        }
      }
    },

    cleanupExpiredEffects: (currentTurn, currentPhase, activePlayer) => {
      const keysToDelete = [];
      for (const [cardId, effect] of gameRefs.current.mimicryEffects.entries()) {
        if (!effect.isActive) {
          keysToDelete.push(cardId);
        }
      }
      
      keysToDelete.forEach(cardId => {
        const effect = gameRefs.current.mimicryEffects.get(cardId);
        console.log(`🦎 擬態効果削除: ${effect?.cardName || cardId} (ID: ${cardId}), プレイヤー${effect?.playerId || 'unknown'}`);
        gameRefs.current.mimicryEffects.delete(cardId);
        gameRefs.current.cardNames.delete(cardId);
      });
    },
        
    deactivate: (cardId) => {
      const mimicry = gameRefs.current.mimicryEffects.get(cardId);
      if (mimicry) {
        mimicry.isActive = false;
        console.log(`🦎 擬態効果無効化: ${mimicry.cardName || cardId} (ID: ${cardId})`);
      }
    },

    getAllEffects: () => {
      return new Map(gameRefs.current.mimicryEffects);
    }
  }, [addLog]);

  // 🔧 修正: 擬態中の虫を除外して攻撃可能な虫を取得する関数
  const getValidAttackTargets = useCallback((playerField, currentTurn, currentPhase, activePlayer) => {
    return playerField.filter(card => {
      if (card.type !== 'insect' || card.isFlipped) {
        return false;
      }
      
      // 🔧 修正: 擬態効果をチェック - 擬態中の虫は場にいないもの扱い
      const hasMimicry = manageMimicryEffects.isActive(card.id, currentTurn, currentPhase, activePlayer);
      if (hasMimicry) {
        console.log(`🦎 ${card.name} は擬態効果により場にいないもの扱い - 攻撃対象から除外`);
        return false;
      }
      
      return true;
    });
  }, [manageMimicryEffects]);

  const logAttackToDatabase = useCallback(async (attackData) => {
    try {
      const supabase = await getSupabase();
      if (!supabase) return;
      
      const { error } = await supabase
        .from('attack_logs_a7x9k2')
        .insert([{
          game_session_id: gameSessionId,
          attacker_player: attackData.attackerPlayer,
          target_player: attackData.targetPlayer,
          attacker_card_id: attackData.attackerCard.id,
          attacker_card_name: attackData.attackerCard.name,
          target_type: attackData.targetType,
          target_card_id: attackData.targetCard?.id || null,
          target_card_name: attackData.targetCard?.name || 'Territory',
          attack_value: attackData.attackValue,
          attack_type: attackData.attackType,
          is_advantage: attackData.isAdvantage,
          damage_dealt: attackData.damageDealt,
          turn_count: turnCount,
          game_phase: gamePhase
        }]);

      if (error) {
        console.warn('Failed to log attack:', error);
      } else {
        console.log('✅ Attack logged successfully to database');
      }
    } catch (err) {
      console.warn('Attack logging failed:', err);
    }
  }, [gameSessionId, turnCount, gamePhase]);

  const manageTerritoryAttackHistory = useCallback({
    record: (attackerPlayer, targetPlayer, turn, attackerCard, damageDealt) => {
      const attackKey = `${attackerPlayer}->${targetPlayer}-${turn}`;
      if (!gameRefs.current.territoryAttackHistory.has(attackKey)) {
        gameRefs.current.territoryAttackHistory.set(attackKey, []);
      }
      gameRefs.current.territoryAttackHistory.get(attackKey).push({
        attackerCard: attackerCard.name,
        attackerId: attackerCard.id,
        damageDealt,
        timestamp: Date.now()
      });
    },
    
    getTerritoryAttacks: (attackerPlayer, targetPlayer, turn) => {
      const attackKey = `${attackerPlayer}->${targetPlayer}-${turn}`;
      return gameRefs.current.territoryAttackHistory.get(attackKey) || [];
    },
    
    hasTerritoryBeenAttacked: (targetPlayer, turn) => {
      const pattern = `2->${targetPlayer}-${turn}`;
      for (const [key] of gameRefs.current.territoryAttackHistory.entries()) {
        if (key === pattern) {
          return true;
        }
      }
      return false;
    },
    
    clearTurn: (turn) => {
      const keysToDelete = [];
      for (const [key] of gameRefs.current.territoryAttackHistory.entries()) {
        if (key.endsWith(`-${turn}`)) {
          keysToDelete.push(key);
        }
      }
      keysToDelete.forEach(key => gameRefs.current.territoryAttackHistory.delete(key));
    }
  }, []);

  const manageEnemyAttackCount = useCallback({
    increment: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      const currentCount = gameRefs.current.enemyAttackCount.get(turnKey) || 0;
      gameRefs.current.enemyAttackCount.set(turnKey, currentCount + 1);
      return currentCount + 1;
    },
    
    getCount: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      return gameRefs.current.enemyAttackCount.get(turnKey) || 0;
    },
    
    canAttack: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      const currentCount = gameRefs.current.enemyAttackCount.get(turnKey) || 0;
      return currentCount === 0;
    },
    
    reset: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      gameRefs.current.enemyAttackCount.set(turnKey, 0);
    },
    
    clearTurn: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      gameRefs.current.enemyAttackCount.delete(turnKey);
    }
  }, []);

  const manageDebuffEffects = useCallback({
    apply: (targetCardId, debuffValue, currentTurn) => {
      const expireTurn = currentTurn + 2;
      const debuffKey = `${targetCardId}-${currentTurn}`;
      gameRefs.current.debuffHistory.set(debuffKey, {
        debuffValue,
        expireTurn,
        appliedTurn: currentTurn
      });
      console.log(`🦋 弱体化効果適用: カードID ${targetCardId}, 弱体化値: -${debuffValue}, 期限ターン: ${expireTurn}`);
    },
    
    getActiveDebuffs: (targetCardId, currentTurn) => {
      let totalDebuff = 0;
      const activeDebuffs = [];
      
      for (const [key, debuff] of gameRefs.current.debuffHistory.entries()) {
        if (key.startsWith(`${targetCardId}-`) && currentTurn < debuff.expireTurn) {
          totalDebuff += debuff.debuffValue;
          activeDebuffs.push(debuff);
        }
      }
      
      return { totalDebuff, activeDebuffs };
    },
    
    cleanupExpiredDebuffs: (currentTurn) => {
      const keysToDelete = [];
      for (const [key, debuff] of gameRefs.current.debuffHistory.entries()) {
        if (currentTurn >= debuff.expireTurn) {
          keysToDelete.push(key);
        }
      }
      
      keysToDelete.forEach(key => {
        const debuff = gameRefs.current.debuffHistory.get(key);
        console.log(`🦋 弱体化効果期限切れ: ${key}, 弱体化値: -${debuff.debuffValue}`);
        gameRefs.current.debuffHistory.delete(key);
      });
    },
    
    getAllDebuffs: () => {
      return new Map(gameRefs.current.debuffHistory);
    }
  }, []);

  const manageLocustSpellEffects = useCallback({
    apply: (player, currentTurn, attackBonus = 200) => {
      const expireTurn = currentTurn + 1;
      const spellKey = `${player}-${currentTurn}`;
      gameRefs.current.locustSpellEffects.set(spellKey, {
        attackBonus,
        expireTurn,
        appliedTurn: currentTurn,
        appliedPlayer: player
      });
      console.log(`🦗 飛蝗の凶相効果適用: プレイヤー${player}, 攻撃力+${attackBonus}, 期限ターン: ${expireTurn}`);
    },
    
    getActiveBonus: (player, currentTurn) => {
      let totalBonus = 0;
      for (const [key, effect] of gameRefs.current.locustSpellEffects.entries()) {
        if (key.startsWith(`${player}-`) && currentTurn < effect.expireTurn) {
          totalBonus += effect.attackBonus;
        }
      }
      return totalBonus;
    },
    
    cleanupExpiredEffects: (currentTurn) => {
      const keysToDelete = [];
      for (const [key, effect] of gameRefs.current.locustSpellEffects.entries()) {
        if (currentTurn >= effect.expireTurn) {
          keysToDelete.push(key);
        }
      }
      
      keysToDelete.forEach(key => {
        const effect = gameRefs.current.locustSpellEffects.get(key);
        console.log(`🦗 飛蝗の凶相効果期限切れ: ${key}, 攻撃力+${effect.attackBonus}`);
        gameRefs.current.locustSpellEffects.delete(key);
      });
    },
    
    getAllEffects: () => {
      return new Map(gameRefs.current.locustSpellEffects);
    }
  }, []);

  const manageBreathOfInsectsCards = useCallback({
    register: (cardId, playerId, turn) => {
      gameRefs.current.breathOfInsectsCards.set(cardId, {
        playerId,
        turnAdded: turn,
        isBreathOfInsects: true
      });
      console.log(`🌪️ 蟲の息吹カード登録: カードID ${cardId}, プレイヤー${playerId}, ターン${turn}`);
    },
    
    isBreathOfInsectsCard: (cardId) => {
      return gameRefs.current.breathOfInsectsCards.has(cardId);
    },
    
    remove: (cardId) => {
      const wasBreathCard = gameRefs.current.breathOfInsectsCards.has(cardId);
      gameRefs.current.breathOfInsectsCards.delete(cardId);
      if (wasBreathCard) {
        console.log(`🌪️ 蟲の息吹カード削除: カードID ${cardId}`);
      }
      return wasBreathCard;
    },
    
    getAllBreathCards: () => {
      return new Map(gameRefs.current.breathOfInsectsCards);
    }
  }, []);

  const calculateEnhancementEffects = useCallback((insect) => {
    let attackBonus = 0;
    let healthBonus = 0;
    
    if (insect && insect.appliedEnhancements) {
      insect.appliedEnhancements.forEach(enhancement => {
        if (!enhancement) return;
        
        if (enhancement.name && enhancement.name.includes('天牛の大顎')) {
          attackBonus += 300;
          console.log(`⚡ ${enhancement.name}により攻撃力+300`);
        }
        
        if (enhancement.name && enhancement.name.includes('蓑虫の隠れ蓑')) {
          healthBonus += 500;
          console.log(`🛡️ ${enhancement.name}により体力+500`);
        }
      });
    }
    
    return { attackBonus, healthBonus };
  }, []);

  const checkNeedlewormRoadCompanionEffect = useCallback((destroyedInsect, attackerInsect) => {
    if (!destroyedInsect.appliedEnhancements) return null;
    
    const hasNeedlewormRoadCompanion = destroyedInsect.appliedEnhancements.some(
      enhancement => enhancement.name && enhancement.name.includes('針金虫の道連れ')
    );
    
    if (hasNeedlewormRoadCompanion && attackerInsect) {
      return {
        shouldDestroy: true,
        destroyedByNeedleworm: destroyedInsect,
        targetToDestroy: attackerInsect
      };
    }
    
    return null;
  }, []);

  const processNeedlewormRoadCompanionEffect = useCallback((needlewormEffect, attackerPlayer, targetPlayer) => {
    if (!needlewormEffect?.shouldDestroy) return { updatedAttackerField: null, updatedAttackerGraveyard: null };
    
    const { destroyedByNeedleworm, targetToDestroy } = needlewormEffect;
    addLog(`💀🪱 針金虫の道連れの効果発動！${destroyedByNeedleworm.name}を破壊した${targetToDestroy.name}も道連れで破壊されます！`, 'attack');
    
    setGameState(prev => {
      if (!prev) return prev;
      
      const attackerPlayerState = prev[`player${attackerPlayer}`];
      const updatedAttackerField = attackerPlayerState.field.filter(insect => insect.id !== targetToDestroy.id);
      const updatedAttackerGraveyard = [...attackerPlayerState.graveyard, {...targetToDestroy, isFlipped: false}];
      
      let updatedAttackerHand = [...attackerPlayerState.hand];
      let updatedAttackerTerritory = [...attackerPlayerState.territory];
      
      if (updatedAttackerTerritory.length > 0) {
        const drawnCard = updatedAttackerTerritory[updatedAttackerTerritory.length - 1];
        updatedAttackerTerritory = updatedAttackerTerritory.slice(0, -1);
        updatedAttackerHand = [...updatedAttackerHand, drawnCard];
        // 🔧 修正: プレイヤー番号を明記
        addLog(`🏠 針金虫の道連れで虫が撃破されたため、プレイヤー${attackerPlayer}のカードが縄張りから手札に移動しました`, 'info');
      }
      
      return {
        ...prev,
        [`player${attackerPlayer}`]: {
          ...attackerPlayerState,
          field: updatedAttackerField,
          graveyard: updatedAttackerGraveyard,
          hand: updatedAttackerHand,
          territory: updatedAttackerTerritory
        }
      };
    });
    
    return { updatedAttackerField: true, updatedAttackerGraveyard: true };
  }, [addLog]);

  const healAllInsects = useCallback((playerNumber) => {
    setGameState(prev => {
      if (!prev) return prev;
      
      const player = prev[`player${playerNumber}`];
      const healedField = player.field.map(insect => {
        const { healthBonus } = calculateEnhancementEffects(insect);
        const maxHealth = insect.health + healthBonus;
        return {
          ...insect,
          currentHealth: maxHealth,
          isFlipped: false
        };
      });
      
      return {
        ...prev,
        [`player${playerNumber}`]: {
          ...player,
          field: healedField
        }
      };
    });
  }, [calculateEnhancementEffects]);

  const manageEnemyAttackHistory = useCallback({
    record: (attackerId, player, turn) => {
      const turnKey = `${player}-${turn}`;
      if (!gameRefs.current.enemyAttackHistory.has(turnKey)) {
        gameRefs.current.enemyAttackHistory.set(turnKey, new Set());
      }
      gameRefs.current.enemyAttackHistory.get(turnKey).add(attackerId);
    },
    
    hasAttacked: (attackerId, player, turn) => {
      const turnKey = `${player}-${turn}`;
      const attackers = gameRefs.current.enemyAttackHistory.get(turnKey);
      return attackers ? attackers.has(attackerId) : false;
    },
    
    getAttackers: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      return Array.from(gameRefs.current.enemyAttackHistory.get(turnKey) || []);
    },
    
    clearTurn: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      gameRefs.current.enemyAttackHistory.delete(turnKey);
    }
  }, []);

  const manageTurnStartFeedCount = useCallback({
    record: (player, turn, feedCount) => {
      const turnKey = `${player}-${turn}`;
      gameRefs.current.turnStartFeedCount.set(turnKey, feedCount);
    },
    
    get: (player, turn) => {
      const turnKey = `${player}-${turn}`;
      return gameRefs.current.turnStartFeedCount.get(turnKey) || 0;
    },
    
    hasIncreasedByOne: (player, turn, currentCount) => {
      const startCount = gameRefs.current.turnStartFeedCount.get(`${player}-${turn}`) || 0;
      return currentCount === startCount + 1;
    }
  }, []);

  const manageCardTurnAdded = useCallback({
    record: (cardId, player, turn) => {
      gameRefs.current.cardTurnAdded.set(cardId, { player, turn });
    },
    
    canReturnToHand: (cardId, area, player, turn) => {
      if (area !== 'feed') return true;
      
      const cardInfo = gameRefs.current.cardTurnAdded.get(cardId);
      if (!cardInfo) return true;
      
      return cardInfo.player === player && cardInfo.turn === turn;
    },
    
    remove: (cardId) => {
      gameRefs.current.cardTurnAdded.delete(cardId);
    }
  }, []);

  const manageCardPlayedTurn = useCallback({
    record: (cardId, player, turn) => {
      const turnKey = `${cardId}-${player}`;
      gameRefs.current.cardPlayedTurn.set(turnKey, {
        cardId,
        player,
        turn,
        timestamp: Date.now()
      });
    },
    
    canReturnFromField: (cardId, player, turn) => {
      const turnKey = `${cardId}-${player}`;
      const cardInfo = gameRefs.current.cardPlayedTurn.get(turnKey);
      if (!cardInfo) return false;
      
      return cardInfo.player === player && cardInfo.turn === turn;
    },
    
    remove: (cardId, player) => {
      const turnKey = `${cardId}-${player}`;
      gameRefs.current.cardPlayedTurn.delete(turnKey);
    }
  }, []);

  const initializeTurnStart = useCallback((playerNumber, turn, phase) => {
    const turnKey = `${playerNumber}-${turn}-${phase}`;
    if (gameRefs.current.turnInitialized.has(turnKey)) return;
    gameRefs.current.turnInitialized.set(turnKey, true);
    
    if (phase === 'draw' || (phase === 'set' && playerNumber === 1 && turn === 1)) {
      manageEnemyAttackCount.reset(playerNumber, turn);
      healAllInsects(playerNumber);
      manageDebuffEffects.cleanupExpiredDebuffs(turn);
      manageLocustSpellEffects.cleanupExpiredEffects(turn);
      manageMimicryEffects.cleanupExpiredEffects(turn, phase, playerNumber);
    }
    
    manageMimicryEffects.updateForPhase(turn, phase, playerNumber);
    
    setGameState(prev => {
      if (!prev) return prev;
      
      const player = prev[`player${playerNumber}`];
      
      if (phase === 'draw' || (phase === 'set' && playerNumber === 1 && turn === 1)) {
        manageTurnStartFeedCount.record(playerNumber, turn, player.feedArea.length);
        
        const updatedPlayer = {
          ...player,
          hasSetFeed: false,
          currentCost: player.maxCost || player.feedArea.length,
          field: player.field.map(insect => {
            const { healthBonus } = calculateEnhancementEffects(insect);
            const maxHealth = insect.health + healthBonus;
            return {
              ...insect,
              hasAttacked: false,
              hasPlayed: false,
              currentHealth: maxHealth,
              hasAttackedThisTurn: false,
              isFlipped: false
            };
          }),
          feedArea: player.feedArea.map(card => ({
            ...card,
            hasPlayed: false
          }))
        };
        
        return {
          ...prev,
          [`player${playerNumber}`]: updatedPlayer
        };
      }
      
      return prev;
    });
  }, [
    manageTurnStartFeedCount,
    healAllInsects,
    manageEnemyAttackCount,
    manageDebuffEffects,
    manageLocustSpellEffects,
    manageMimicryEffects,
    calculateEnhancementEffects
  ]);

  const initializeGameState = useCallback((player1Cards, player2Cards) => {
    const initialState = {
      player1: {
        deck: player1Cards.slice(10),
        hand: player1Cards.slice(0, 4),
        territory: player1Cards.slice(4, 10),
        field: [],
        feedArea: [],
        graveyard: [],
        currentCost: 0,
        maxCost: 0,
        hasSetFeed: false
      },
      player2: {
        deck: player2Cards.slice(10),
        hand: player2Cards.slice(0, 4),
        territory: player2Cards.slice(4, 10),
        field: [],
        feedArea: [],
        graveyard: [],
        currentCost: 0,
        maxCost: 0,
        hasSetFeed: false
      }
    };
    
    setGameState(initialState);
    setGameLog([]);
    setIsGameOver(false);
    setWinner(null);
    setShowPhaseConfirmation(false);
    setLastSetCard(null);
    
    Object.values(gameRefs.current).forEach(map => map.clear());
  }, []);

  const initializeGame = useCallback(async () => {
    try {
      const player1Deck = shuffleDeck(await createInitialDeck());
      const player2Deck = shuffleDeck(await createInitialDeck());
      
      initializeGameState(player1Deck, player2Deck);
      await initializeGameSession();
      
      addLog('ゲームが開始されました', 'success');
    } catch (error) {
      console.error('Failed to initialize game:', error);
      addLog('ゲーム初期化中にエラーが発生しました', 'error');
    }
  }, [initializeGameSession, addLog, initializeGameState]);

  const initializeGameWithDecks = useCallback(async (playerDeck, computerDeck) => {
    try {
      const player1Cards = shuffleDeck(playerDeck.map(card => ({ ...card, id: uuidv4() })));
      const player2Cards = shuffleDeck(computerDeck.map(card => ({ ...card, id: uuidv4() })));
      
      initializeGameState(player1Cards, player2Cards);
      await initializeGameSession();
      
      addLog('カスタムデッキでゲームが開始されました', 'success');
    } catch (error) {
      console.error('Failed to initialize game with decks:', error);
      addLog('カスタムデッキゲーム初期化中にエラーが発生しました', 'error');
    }
  }, [initializeGameSession, addLog, initializeGameState]);

  const applyDebuffEffect = useCallback((attackerCard, targetCard) => {
    if (attackerCard.name && attackerCard.name.includes('ナミアゲハ')) {
      manageDebuffEffects.apply(targetCard.id, 400, turnCount);
      addLog(`🦋 ${attackerCard.name}の攻撃2により、${targetCard.name}の攻撃力が次のターンに400低下します！`, 'success');
    }
  }, [manageDebuffEffects, turnCount, addLog]);

  const applyLocustSpellEffect = useCallback((player) => {
    manageLocustSpellEffects.apply(player, turnCount, 200);
    addLog(`🦗 飛蝗の凶相の効果により、プレイヤー${player}の全ての虫の攻撃力がターン終了時まで+200されます！`, 'success');
  }, [manageLocustSpellEffects, turnCount, addLog]);

  // 🔧 修正: 擬態効果を適用する関数 - 場にいないもの扱い
  const applyMimicryEffect = useCallback((insectCard, playerId) => {
    manageMimicryEffects.apply(insectCard.id, playerId, turnCount, insectCard.name);
    addLog(`🦎 ${insectCard.name}の擬態能力が発動！場にいないものとして扱われ、敵のエンドフェーズまで攻撃されません！`, 'success');
  }, [manageMimicryEffects, turnCount, addLog]);

  const applyBreathOfInsectsEffect = useCallback((player, spellCard) => {
    setGameState(prev => {
      if (!prev) return prev;
      
      const currentPlayer = prev[`player${player}`];
      const breathCardInGraveyard = currentPlayer.graveyard.find(
        card => card.id === spellCard.id && card.name && card.name.includes('蟲の息吹')
      );
      
      if (!breathCardInGraveyard) {
        console.warn('🌪️ 蟲の息吹カードが捨札に見つかりません');
        return prev;
      }
      
      const newGraveyard = currentPlayer.graveyard.filter(card => card.id !== spellCard.id);
      const breathCard = {
        ...breathCardInGraveyard,
        hasPlayed: false,
        isBreathOfInsects: true
      };
      
      manageBreathOfInsectsCards.register(breathCard.id, player, turnCount);
      
      const newFeedArea = [...currentPlayer.feedArea, breathCard];
      const newMaxCost = newFeedArea.length;
      
      addLog(`🌪️ 蟲の息吹の効果により、捨札から「${breathCard.name}」がエサ場にコストなしで追加されました！ (利用可能コスト: ${currentPlayer.currentCost} → ${newMaxCost})`, 'success');
      
      return {
        ...prev,
        [`player${player}`]: {
          ...currentPlayer,
          graveyard: newGraveyard,
          feedArea: newFeedArea,
          maxCost: newMaxCost,
          currentCost: currentPlayer.currentCost
        }
      };
    });
  }, [manageBreathOfInsectsCards, turnCount, addLog]);

  const applyExplosiveEffect = useCallback((player, spellCard, targetInsect) => {
    const opponentPlayer = player === 1 ? 2 : 1;
    const explosiveDamage = 600;
    
    setGameState(prev => {
      if (!prev) return prev;
      
      const opponent = prev[`player${opponentPlayer}`];
      const currentHealth = targetInsect.currentHealth !== undefined ? targetInsect.currentHealth : targetInsect.health;
      const newHealth = Math.max(0, currentHealth - explosiveDamage);
      
      let newOpponentField = [...opponent.field];
      let newOpponentGraveyard = [...opponent.graveyard];
      
      // 🔧 修正: 術で虫が撃破されても縄張りから手札に移動させない
      if (newHealth <= 0) {
        newOpponentField = opponent.field.filter(insect => insect.id !== targetInsect.id);
        newOpponentGraveyard = [...opponent.graveyard, {...targetInsect, isFlipped: false}];
        addLog(`💥 塵芥虫の爆熱弾により${targetInsect.name}が撃破されました！`, 'attack');
        // 🔧 修正: 縄張りから手札への移動処理を削除
      } else {
        newOpponentField = opponent.field.map(insect => 
          insect.id === targetInsect.id ? {...insect, currentHealth: newHealth} : insect
        );
        addLog(`💥 塵芥虫の爆熱弾により${targetInsect.name}が${explosiveDamage}ダメージを受けました (${currentHealth} → ${newHealth})`, 'attack');
      }
      
      logAttackToDatabase({
        attackerPlayer: player,
        targetPlayer: opponentPlayer,
        attackerCard: spellCard,
        targetType: 'insect',
        targetCard: targetInsect,
        attackValue: explosiveDamage,
        attackType: 1,
        isAdvantage: false,
        damageDealt: explosiveDamage
      });
      
      return {
        ...prev,
        [`player${opponentPlayer}`]: {
          ...opponent,
          field: newOpponentField,
          graveyard: newOpponentGraveyard
        }
      };
    });
  }, [addLog, logAttackToDatabase]);

  const applyRainbowBridgeEffect = useCallback((player, spellCard, targetInsect) => {
    setGameState(prev => {
      if (!prev) return prev;
      
      const currentPlayer = prev[`player${player}`];
      const newGraveyard = currentPlayer.graveyard.filter(card => card.id !== targetInsect.id);
      
      const revivedInsect = {
        ...targetInsect,
        currentHealth: targetInsect.health,
        hasAttacked: false,
        hasPlayed: false,
        hasAttackedThisTurn: false,
        isFlipped: false,
        appliedEnhancements: targetInsect.appliedEnhancements || []
      };
      
      addLog(`🌈 虹の架け橋の効果により、捨札から「${targetInsect.name}」が手札に蘇生されました！`, 'success');
      
      return {
        ...prev,
        [`player${player}`]: {
          ...currentPlayer,
          graveyard: newGraveyard,
          hand: [...currentPlayer.hand, revivedInsect]
        }
      };
    });
  }, [addLog]);

  const applyColorChangeEnhancement = useCallback((enhancementCard, targetInsect, selectedColor) => {
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      
      if (enhancementCard.cost > player.currentCost) {
        addLog(`コストが足りません (必要: ${enhancementCard.cost}, 現在: ${player.currentCost})`, 'error');
        return prev;
      }
      
      const updatedField = player.field.map(insect => {
        if (insect.id === targetInsect.id) {
          const appliedEnhancements = insect.appliedEnhancements || [];
          const newEnhancements = [...appliedEnhancements, enhancementCard];
          
          const colorNames = {
            'red': '赤',
            'blue': '青',
            'green': '緑'
          };
          
          addLog(`🌈 ${enhancementCard.name}により${targetInsect.name}の属性が${colorNames[selectedColor]}に変更されました！`, 'success');
          
          return {
            ...insect,
            element: selectedColor,
            appliedEnhancements: newEnhancements
          };
        }
        return insect;
      });
      
      addLog(`プレイヤー${currentPlayer}が${enhancementCard.name}を${targetInsect.name}に適用しました (コスト: ${enhancementCard.cost})`, 'success');
      
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          hand: player.hand.filter(c => c.id !== enhancementCard.id),
          field: updatedField,
          currentCost: player.currentCost - enhancementCard.cost
        }
      };
    });
  }, [currentPlayer, addLog]);

  const getEffectiveAttackPower = useCallback((insect, attackType = 1, playerNumber = null) => {
    let baseAttack = attackType === 2 ? (insect.attack2 || 0) : (insect.attack1 || insect.attack || 0);
    
    const { attackBonus } = calculateEnhancementEffects(insect);
    baseAttack += attackBonus;
    
    if (playerNumber) {
      const locustBonus = manageLocustSpellEffects.getActiveBonus(playerNumber, turnCount);
      baseAttack += locustBonus;
    }
    
    const { totalDebuff } = manageDebuffEffects.getActiveDebuffs(insect.id, turnCount);
    const effectiveAttack = Math.max(0, baseAttack - totalDebuff);
    
    if (totalDebuff > 0 || attackBonus > 0 || (playerNumber && manageLocustSpellEffects.getActiveBonus(playerNumber, turnCount) > 0)) {
      const locustBonus = playerNumber ? manageLocustSpellEffects.getActiveBonus(playerNumber, turnCount) : 0;
      console.log(`🎯 攻撃力計算: ${insect.name} 基本${attackType === 2 ? insect.attack2 || 0 : insect.attack1 || insect.attack || 0} + 強化${attackBonus} + 飛蝗${locustBonus} - 弱体化${totalDebuff}=${effectiveAttack}`);
    }
    
    return effectiveAttack;
  }, [manageDebuffEffects, turnCount, calculateEnhancementEffects, manageLocustSpellEffects]);

  const getEffectiveMaxHealth = useCallback((insect) => {
    const { healthBonus } = calculateEnhancementEffects(insect);
    return insect.health + healthBonus;
  }, [calculateEnhancementEffects]);

  // 🆕 セアカゴケグモの攻撃2使用可能チェック関数
  const getSeakagokeGumoAttack2Status = useCallback((cardId, playerNumber, cardName) => {
    if (!cardName || !cardName.includes('セアカゴケグモ')) {
      return { 
        isSeakagokegumo: false, 
        canUseAttack2: true, 
        hasUsedAttack2: false 
      };
    }

    const canUse = manageSeakagokeGumoAttack2.canUseAttack2(cardId, playerNumber, cardName);
    const hasUsed = manageSeakagokeGumoAttack2.hasUsedAttack2(cardId, playerNumber);

    // デバッグ情報を出力
    manageSeakagokeGumoAttack2.debugUsage(cardId, playerNumber, cardName);

    return {
      isSeakagokegumo: true,
      canUseAttack2: canUse,
      hasUsedAttack2: hasUsed
    };
  }, [manageSeakagokeGumoAttack2]);

  // useEffect hooks
  useEffect(() => {
    const turnKey = `${currentPlayer}-${turnCount}-${gamePhase}`;
    if (gamePhase === 'draw' && gameState && !gameRefs.current.turnInitialized.has(turnKey)) {
      initializeTurnStart(currentPlayer, turnCount, gamePhase);
      addLog(`プレイヤー${currentPlayer}のターン${turnCount}開始 - ドローフェーズ`, 'info');
    }
  }, [gamePhase, currentPlayer, turnCount, gameState, initializeTurnStart, addLog]);

  useEffect(() => {
    const turnKey = `${currentPlayer}-${turnCount}-${gamePhase}`;
    if (gamePhase === 'set' && currentPlayer === 1 && turnCount === 1 && gameState && !gameRefs.current.turnInitialized.has(turnKey)) {
      initializeTurnStart(currentPlayer, turnCount, gamePhase);
      addLog(`プレイヤー${currentPlayer}のターン${turnCount}開始 - セットフェーズ`, 'info');
    }
  }, [gamePhase, currentPlayer, turnCount, gameState, initializeTurnStart, addLog]);

  useEffect(() => {
    if (gameState && gamePhase !== 'setup') {
      const turnKey = `${currentPlayer}-${turnCount}-${gamePhase}`;
      if (!gameRefs.current.turnInitialized.has(turnKey)) {
        initializeTurnStart(currentPlayer, turnCount, gamePhase);
      }
    }
  }, [gamePhase, currentPlayer, turnCount, gameState, initializeTurnStart]);

  useEffect(() => {
    if (gamePhase === 'draw' && gameState && !isGameOver && !isPhaseExecuted(currentPlayer, turnCount, 'draw')) {
      const timer = setTimeout(() => {
        drawCard();
        markPhaseAsExecuted(currentPlayer, turnCount, 'draw');
        setTimeout(async () => {
          await advancePhase();
        }, 1000);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [gamePhase, currentPlayer, turnCount, gameState, isGameOver, advancePhase, isPhaseExecuted, markPhaseAsExecuted]);

  useEffect(() => {
    if (gameState && gamePhase !== 'setup') {
      const phaseLogKey = `${currentPlayer}-${turnCount}-${gamePhase}`;
      if (!gameRefs.current.phaseLogTracker.has(phaseLogKey) && !isPhaseExecuted(currentPlayer, turnCount, gamePhase)) {
        const phaseNames = {
          'draw': 'ドローフェーズ',
          'set': 'セットフェーズ',
          'main': 'メインフェーズ',
          'end': 'エンドフェーズ'
        };
        
        if (gamePhase in phaseNames) {
          if (!(gamePhase === 'set' && currentPlayer === 1 && turnCount === 1)) {
            addLog(`${phaseNames[gamePhase]}に移行しました`, 'info');
          }
          gameRefs.current.phaseLogTracker.set(phaseLogKey, true);
        }
      }
    }
  }, [gamePhase, gameState, addLog, currentPlayer, turnCount, isPhaseExecuted]);

  // 🎯 プレイヤー2（敵）の攻撃システム - 🔧 修正: 複数攻撃を合計値で処理
  const executeEnemyTurnAttacks = useCallback(() => {
    setGameState(prev => {
      if (!prev) return prev;
      
      const enemyPlayer = prev.player2;
      // 🔧 修正: 擬態効果を考慮して攻撃可能な虫を取得
      const validTargets = getValidAttackTargets(prev.player1.field, turnCount, gamePhase, currentPlayer);
      
      let updatedPlayer1 = prev.player1;
      let updatedPlayer2 = prev.player2;
      
      console.log('🎯 敵ターン攻撃開始');
      console.log(`📊 敵の場の虫: ${enemyPlayer.field.length}匹`);
      console.log(`📊 プレイヤーの場の虫（攻撃可能・擬態除く）: ${validTargets.length}匹`);
      
      const tauntStatus = checkTauntEffect(validTargets);
      const finalTargets = tauntStatus.validTargets;
      
      if (tauntStatus.hasTaunt) {
        console.log(`🦋 ナミアゲハの挑発効果発動中: ${tauntStatus.tauntCards.length}体のナミアゲハが場にいます`);
        addLog(`🦋 ナミアゲハの挑発効果により、敵はナミアゲハしか攻撃できません！`, 'info');
      }
      
      // 🔧 修正: 擬態中の虫がいる場合のログ
      const mimicryCards = prev.player1.field.filter(card => {
        const hasMimicry = manageMimicryEffects.isActive(card.id, turnCount, gamePhase, currentPlayer);
        return hasMimicry;
      });
      
      if (mimicryCards.length > 0) {
        addLog(`🦎 ${mimicryCards.map(c => c.name).join(',')}が擬態効果により場にいないものとして扱われています`, 'info');
      }
      
      // 🆕 敵の虫リストを定義
      const enemyUnits = enemyPlayer.field.filter(enemyBug => {
        if (enemyBug.type !== 'insect') return false;
        if (manageEnemyAttackHistory.hasAttacked(enemyBug.id, 2, turnCount)) {
          console.log(`🚫 ${enemyBug.name} は既に攻撃済み`);
          return false;
        }
        
        const effectiveAttackPower = getEffectiveAttackPower(enemyBug, 1, 2);
        if (effectiveAttackPower <= 0) {
          console.log(`🚫 ${enemyBug.name} の攻撃力が0以下（弱体化効果含む）`);
          return false;
        }
        
        return true;
      });
      
      if (enemyUnits.length === 0) {
        console.log('🚫 攻撃可能な敵の虫がいません');
        return prev;
      }
      
      // 🆕 合計攻撃力を計算
      let totalAttackPower = 0;
      const attackers = [];
      
      enemyUnits.forEach(enemyBug => {
        const effectiveAttackPower = getEffectiveAttackPower(enemyBug, 1, 2);
        totalAttackPower += effectiveAttackPower;
        attackers.push({
          bug: enemyBug,
          power: effectiveAttackPower,
          skill: {
            name: enemyBug.effect1_text || '攻撃',
            color: enemyBug.element
          }
        });
        
        // 各虫を攻撃済みとして記録
        manageEnemyAttackHistory.record(enemyBug.id, 2, turnCount);
        
        // 弱体化・強化効果のログ
        const { totalDebuff } = manageDebuffEffects.getActiveDebuffs(enemyBug.id, turnCount);
        const locustBonus = manageLocustSpellEffects.getActiveBonus(2, turnCount);
        
        if (totalDebuff > 0) {
          addLog(`🦋 ${enemyBug.name}は弱体化効果により攻撃力が${totalDebuff}低下中！`, 'info');
        }
        
        if (locustBonus > 0) {
          addLog(`🦗 ${enemyBug.name}は飛蝗の凶相効果により攻撃力が${locustBonus}増加中！`, 'info');
        }
      });
      
      console.log(`🎯 合計攻撃力: ${totalAttackPower} (${attackers.length}匹の合計)`);
      
      // 🆕 敵虫の攻撃ログ表示
      const attackerNames = attackers.map(a => `${a.bug.name}(${a.power})`).join(', ');
      addLog(`⚔️ 敵の虫が複数攻撃！ ${attackerNames} - 合計攻撃力: ${totalAttackPower}`, 'attack');
      
      // 🆕 短い遅延（アニメーション用）
      setTimeout(() => {
        console.log('🎯 合計ダメージ適用開始');
      }, 100);
      
      // 🆕 プレイヤーにダメージを適用
      const aliveBugs = finalTargets.filter(bug => {
        const maxHealth = getEffectiveMaxHealth(bug);
        const currentHealth = bug.currentHealth !== undefined ? bug.currentHealth : maxHealth;
        return currentHealth > 0 && !bug.isFlipped;
      });
      
      if (aliveBugs.length > 0) {
        // 🎯 虫への攻撃 - 合計攻撃力を最も弱い虫に集中
        let remainingDamage = totalAttackPower;
        const sortedTargets = [...aliveBugs].sort((a, b) => {
          const aHealth = a.currentHealth !== undefined ? a.currentHealth : getEffectiveMaxHealth(a);
          const bHealth = b.currentHealth !== undefined ? b.currentHealth : getEffectiveMaxHealth(b);
          return aHealth - bHealth; // 体力の少ない順
        });
        
        for (const targetBug of sortedTargets) {
          if (remainingDamage <= 0) break;
          
          let damage = remainingDamage;
          
          // 🆕 属性有利チェック（最初の攻撃者の属性を使用）
          const isAdvantage = attackers.length > 0 && checkElementAdvantage(attackers[0].skill.color, targetBug.element);
          if (isAdvantage) {
            damage = Math.floor(damage * 2);
            const elementNames = {
              'red': '赤',
              'blue': '青',
              'green': '緑'
            };
            addLog(`🔥 属性有利！${elementNames[attackers[0].skill.color]} → ${elementNames[targetBug.element]} ダメージ2倍！`, 'attack');
          }
          
          addLog(`⚔️ ${targetBug.name}が合計${damage}ダメージを受けました！`, 'attack');
          
          const maxHealth = getEffectiveMaxHealth(targetBug);
          const currentHealth = targetBug.currentHealth !== undefined ? targetBug.currentHealth : maxHealth;
          const newHealth = Math.max(0, currentHealth - damage);
          
          if (newHealth <= 0) {
            addLog(`💀 ${targetBug.name}が撃破されました！`, 'attack');
            
            // 針金虫の道連れ効果チェック（最初の攻撃者に対して）
            const needlewormEffect = attackers.length > 0 ? checkNeedlewormRoadCompanionEffect(targetBug, attackers[0].bug) : null;
            
            updatedPlayer1 = {
              ...updatedPlayer1,
              field: updatedPlayer1.field.filter(bug => bug.id !== targetBug.id),
              graveyard: [...updatedPlayer1.graveyard, targetBug]
            };
            
            if (updatedPlayer1.territory.length > 0) {
              const drawnCard = updatedPlayer1.territory[updatedPlayer1.territory.length - 1];
              updatedPlayer1 = {
                ...updatedPlayer1,
                territory: updatedPlayer1.territory.slice(0, -1),
                hand: [...updatedPlayer1.hand, drawnCard]
              };
              addLog(`🏠 虫が撃破されたため、プレイヤー1のカードが縄張りから手札に移動しました`, 'info');
            }
            
            if (needlewormEffect?.shouldDestroy) {
              processNeedlewormRoadCompanionEffect(needlewormEffect, 2, 1);
            }
            
            remainingDamage = 0; // 虫が撃破されたら攻撃終了
          } else {
            updatedPlayer1 = {
              ...updatedPlayer1,
              field: updatedPlayer1.field.map(bug => 
                bug.id === targetBug.id ? {...bug, currentHealth: newHealth} : bug
              )
            };
            addLog(`${targetBug.name}は${damage}ダメージを受けました (${currentHealth} → ${newHealth})`, 'attack');
            remainingDamage = 0; // 一匹に全ダメージを集中
          }
          
          // 🆕 データベースに攻撃ログを記録（代表攻撃者として最初の虫を使用）
          if (attackers.length > 0) {
            logAttackToDatabase({
              attackerPlayer: 2,
              targetPlayer: 1,
              attackerCard: attackers[0].bug,
              targetType: 'insect',
              targetCard: targetBug,
              attackValue: totalAttackPower,
              attackType: 1,
              isAdvantage,
              damageDealt: damage
            });
          }
          
          break; // 一匹に集中攻撃
        }
      } else {
        // 🎯 直接攻撃（プレイヤーの場に攻撃可能な虫がいない）
        const allPlayerBugs = prev.player1.field.filter(bug => bug.type === 'insect');
        const flippedBugs = allPlayerBugs.filter(bug => bug.isFlipped);
        const mimicryBugs = allPlayerBugs.filter(bug => {
          const hasMimicry = manageMimicryEffects.isActive(bug.id, turnCount, gamePhase, currentPlayer);
          return hasMimicry;
        });
        
        let attackMessage = `🎯 敵の虫${attackers.length}匹が合計攻撃力${totalAttackPower}でプレイヤーを直接攻撃！`;
        // 🔧 修正: 擬態中の虫は縄張りを守れないことを明確に表現
        if (flippedBugs.length > 0 && mimicryBugs.length > 0) {
          attackMessage += `（裏向きの虫${flippedBugs.length}匹は守れず、擬態中の虫${mimicryBugs.length}匹は場にいないため縄張りを守れない）`;
        } else if (flippedBugs.length > 0) {
          attackMessage += `（裏向きの虫${flippedBugs.length}匹は守れない）`;
        } else if (mimicryBugs.length > 0) {
          attackMessage += `（擬態中の虫${mimicryBugs.length}匹は場にいないため縄張りを守れない）`;
        }
        
        addLog(attackMessage, 'attack');
        
        // 🆕 合計攻撃力分の縄張りカードを失う
        let remainingAttacks = Math.ceil(totalAttackPower / 100); // 100ダメージごとに1枚の縄張りを失う（調整可能）
        remainingAttacks = Math.min(remainingAttacks, updatedPlayer1.territory.length); // 縄張りの枚数を超えない
        
        for (let i = 0; i < remainingAttacks; i++) {
          if (updatedPlayer1.territory.length > 0) {
            const drawnCard = updatedPlayer1.territory[updatedPlayer1.territory.length - 1];
            updatedPlayer1 = {
              ...updatedPlayer1,
              territory: updatedPlayer1.territory.slice(0, -1),
              hand: [...updatedPlayer1.hand, drawnCard]
            };
            
            // 各攻撃者について縄張り攻撃履歴を記録
            attackers.forEach(attacker => {
              manageTerritoryAttackHistory.record(2, 1, turnCount, attacker.bug, attacker.power);
            });
          }
        }
        
        addLog(`🏠 合計攻撃により、プレイヤー1の縄張りから${remainingAttacks}枚のカードが手札に移動しました`, 'info');
        
        if (updatedPlayer1.territory.length === 0) {
          addLog('💀 プレイヤーの縄張りがすべて失われました。敗北です！', 'error');
          setTimeout(() => {
            setIsGameOver(true);
            setWinner(2);
          }, 1000);
        }
        
        // 🆕 データベースに縄張り攻撃ログを記録（代表攻撃者として最初の虫を使用）
        if (attackers.length > 0) {
          logAttackToDatabase({
            attackerPlayer: 2,
            targetPlayer: 1,
            attackerCard: attackers[0].bug,
            targetType: 'territory',
            targetCard: null,
            attackValue: totalAttackPower,
            attackType: 1,
            isAdvantage: false,
            damageDealt: totalAttackPower
          });
        }
      }
      
      // 🆝 全ての攻撃者を攻撃済み状態にする
      updatedPlayer2 = {
        ...updatedPlayer2,
        field: updatedPlayer2.field.map(bug => {
          const wasAttacker = attackers.some(attacker => attacker.bug.id === bug.id);
          return wasAttacker ? {...bug, hasAttackedThisTurn: true} : bug;
        })
      };
      
      console.log(`✅ 敵の複数攻撃処理完了 - 合計攻撃力: ${totalAttackPower}`);
      
      return {...prev, player1: updatedPlayer1, player2: updatedPlayer2};
    });
  }, [
    turnCount,
    addLog,
    checkElementAdvantage,
    logAttackToDatabase,
    manageEnemyAttackHistory,
    getEffectiveAttackPower,
    manageDebuffEffects,
    getEffectiveMaxHealth,
    manageLocustSpellEffects,
    checkNeedlewormRoadCompanionEffect,
    processNeedlewormRoadCompanionEffect,
    checkTauntEffect,
    manageMimicryEffects,
    getValidAttackTargets,
    gamePhase,
    currentPlayer,
    manageTerritoryAttackHistory
  ]);

  // 🎯 AI行動システム（続き）
  const executeAIActions = useCallback(async () => {
    if (currentPlayer !== 2 || isGameOver || isPhaseExecuted(currentPlayer, turnCount, gamePhase)) {
      return;
    }
    
    console.log(`🎯 AI Actions Starting - Player: ${currentPlayer}, Phase: ${gamePhase}, Turn: ${turnCount}`);
    
    try {
      if (gamePhase === 'set') {
        await new Promise(resolve => setTimeout(resolve, 800));
        
        setGameState(prev => {
          if (!prev) return prev;
          
          const computer = prev.player2;
          const startFeedCount = manageTurnStartFeedCount.get(currentPlayer, turnCount);
          
          if (computer.feedArea.length <= startFeedCount && computer.hand.length > 0) {
            const feedCard = computer.hand.find(card => card.cost >= 3) ||
                             computer.hand.find(card => card.type !== 'insect') ||
                             computer.hand.find(card => card.cost <= 2) ||
                             computer.hand[0];
            
            const newFeedArea = [...computer.feedArea, {...feedCard, hasPlayed: false}];
            manageCardTurnAdded.record(feedCard.id, currentPlayer, turnCount);
            
            addLog(`🤖 プレイヤー2が${feedCard.name}をエサにセットしました (利用可能コスト: ${newFeedArea.length})`, 'info');
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'set');
              await advancePhase();
            }, 1200);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== feedCard.id),
                feedArea: newFeedArea,
                maxCost: newFeedArea.length,
                hasSetFeed: true,
                currentCost: newFeedArea.length
              }
            };
          }
          
          setTimeout(async () => {
            markPhaseAsExecuted(currentPlayer, turnCount, 'set');
            await advancePhase();
          }, 800);
          
          return prev;
        });
      }
      
      if (gamePhase === 'main') {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setGameState(prev => {
          if (!prev) return prev;
          
          const computer = prev.player2;
          const enemyField = prev.player1.field.filter(bug => bug.type === 'insect' && !bug.isFlipped);
          
          // 優先度0: 虹の架け橋の使用（捨札に虫がいる場合）
          const rainbowBridgeSpells = computer.hand.filter(
            card => card.type === 'spell' && card.name && card.name.includes('虹の架け橋') && card.cost <= computer.currentCost
          );
          
          if (rainbowBridgeSpells.length > 0 && computer.graveyard.some(card => card.type === 'insect')) {
            const rainbowBridgeSpell = rainbowBridgeSpells[0];
            const graveyardInsects = computer.graveyard.filter(card => card.type === 'insect');
            
            const targetInsect = graveyardInsects.reduce((strongest, current) => {
              const currentAttack = current.attack1 || current.attack || 0;
              const strongestAttack = strongest.attack1 || strongest.attack || 0;
              return currentAttack > strongestAttack ? current : strongest;
            });
            
            applyRainbowBridgeEffect(currentPlayer, rainbowBridgeSpell, targetInsect);
            addLog(`🤖 プレイヤー2が${rainbowBridgeSpell.name}で${targetInsect.name}を蘇生しました (コスト: ${rainbowBridgeSpell.cost})`, 'success');
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 2000);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== rainbowBridgeSpell.id),
                graveyard: [...computer.graveyard, rainbowBridgeSpell],
                currentCost: computer.currentCost - rainbowBridgeSpell.cost
              }
            };
          }
          
          // 優先度1: 塵芥虫の爆熱弾の使用（敵に虫がいる場合）
          const explosiveSpells = computer.hand.filter(
            card => card.type === 'spell' && card.name && card.name.includes('塵芥虫の爆熱弾') && card.cost <= computer.currentCost
          );
          
          if (explosiveSpells.length > 0 && enemyField.length > 0) {
            const explosiveSpell = explosiveSpells[0];
            const targetInsect = enemyField.reduce((weakest, current) => {
              const currentHealth = current.currentHealth !== undefined ? current.currentHealth : current.health;
              const weakestHealth = weakest.currentHealth !== undefined ? weakest.currentHealth : weakest.health;
              return currentHealth < weakestHealth ? current : weakest;
            });
            
            applyExplosiveEffect(currentPlayer, explosiveSpell, targetInsect);
            addLog(`🤖 プレイヤー2が${explosiveSpell.name}を${targetInsect.name}に使用しました (コスト: ${explosiveSpell.cost})`, 'success');
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 2000);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== explosiveSpell.id),
                graveyard: [...computer.graveyard, explosiveSpell],
                currentCost: computer.currentCost - explosiveSpell.cost
              }
            };
          }
          
          // 優先度2: 蟲の息吹の使用
          const breathSpells = computer.hand.filter(
            card => card.type === 'spell' && card.name && card.name.includes('蟲の息吹') && card.cost <= computer.currentCost
          );
          
          if (breathSpells.length > 0) {
            const breathSpell = breathSpells[0];
            addLog(`🤖 プレイヤー2が${breathSpell.name}を使用しました (コスト: ${breathSpell.cost})`, 'success');
            applyBreathOfInsectsEffect(currentPlayer, breathSpell);
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 2000);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== breathSpell.id),
                graveyard: [...computer.graveyard, breathSpell],
                currentCost: computer.currentCost - breathSpell.cost
              }
            };
          }
          
          // 優先度3: 飛蝗の凶相の使用
          const locustSpells = computer.hand.filter(
            card => card.type === 'spell' && card.name && card.name.includes('飛蝗の凶相') && card.cost <= computer.currentCost
          );
          
          if (locustSpells.length > 0 && computer.field.length > 0) {
            const locustSpell = locustSpells[0];
            applyLocustSpellEffect(currentPlayer);
            addLog(`🤖 プレイヤー2が${locustSpell.name}を使用しました (コスト: ${locustSpell.cost})`, 'success');
            
            setTimeout(() => {
              executeEnemyTurnAttacks();
            }, 1500);
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 3000);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== locustSpell.id),
                graveyard: [...computer.graveyard, locustSpell],
                currentCost: computer.currentCost - locustSpell.cost
              }
            };
          }
          
          // 優先度4: 虫の召喚
          const playableInsects = computer.hand.filter(
            card => card.type === 'insect' && card.cost <= computer.currentCost && computer.field.length < 5
          );
          
          if (playableInsects.length > 0) {
            const selectedInsect = playableInsects.sort((a, b) => {
              const aAttack = (a.attack1 || a.attack || 0);
              const bAttack = (b.attack1 || b.attack || 0);
              return bAttack - aAttack;
            })[0];
            
            manageCardPlayedTurn.record(selectedInsect.id, currentPlayer, turnCount);
            
            let hasMimicryEffect = false;
            if (selectedInsect.passive_effect_text && selectedInsect.passive_effect_text.includes('擬態')) {
              hasMimicryEffect = true;
            }
            
            addLog(`🤖 プレイヤー2が${selectedInsect.name}(攻撃力:${selectedInsect.attack1 || selectedInsect.attack})を場に召喚！ (コスト: ${selectedInsect.cost})`, 'success');
            
            setTimeout(() => {
              executeEnemyTurnAttacks();
            }, 1500);
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 3000);
            
            const newInsect = {
              ...selectedInsect,
              currentHealth: selectedInsect.health,
              hasAttacked: false,
              hasPlayed: false,
              hasAttackedThisTurn: false,
              playedTurn: turnCount,
              isFlipped: false
            };
            
            if (hasMimicryEffect) {
              setTimeout(() => {
                applyMimicryEffect(newInsect, currentPlayer);
              }, 500);
            }
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== selectedInsect.id),
                field: [...computer.field, newInsect],
                currentCost: computer.currentCost - selectedInsect.cost
              }
            };
          }
          
          // 既に場に虫がいる場合は攻撃のみ実行
          if (computer.field.length > 0) {
            addLog(`🤖 プレイヤー2が場の虫で攻撃を開始！`, 'info');
            
            setTimeout(() => {
              executeEnemyTurnAttacks();
            }, 500);
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 2500);
            
            return prev;
          }
          
          // 優先度5: その他の術カードの使用
          const playableSpells = computer.hand.filter(
            card => card.type === 'spell' && card.cost <= computer.currentCost
          );
          
          if (playableSpells.length > 0) {
            const selectedSpell = playableSpells[0];
            addLog(`🤖 プレイヤー2が${selectedSpell.name}を使用しました (コスト: ${selectedSpell.cost})`, 'success');
            
            setTimeout(async () => {
              markPhaseAsExecuted(currentPlayer, turnCount, 'main');
              await advancePhase();
            }, 1500);
            
            return {
              ...prev,
              player2: {
                ...computer,
                hand: computer.hand.filter(c => c.id !== selectedSpell.id),
                graveyard: [...computer.graveyard, selectedSpell],
                currentCost: computer.currentCost - selectedSpell.cost
              }
            };
          }
          
          addLog(`🤖 プレイヤー2は行動可能なカードがないため、ターンを終了します`, 'info');
          
          setTimeout(async () => {
            markPhaseAsExecuted(currentPlayer, turnCount, 'main');
            await advancePhase();
          }, 1000);
          
          return prev;
        });
      }
    } catch (error) {
      console.error('AI action failed:', error);
      addLog('AIの行動中にエラーが発生しました', 'error');
      markPhaseAsExecuted(currentPlayer, turnCount, gamePhase);
      
      setTimeout(async () => {
        await advancePhase();
      }, 1000);
    }
  }, [
    currentPlayer,
    gamePhase,
    turnCount,
    isGameOver,
    addLog,
    advancePhase,
    isPhaseExecuted,
    markPhaseAsExecuted,
    manageTurnStartFeedCount,
    manageCardTurnAdded,
    manageCardPlayedTurn,
    manageEnemyAttackHistory,
    executeEnemyTurnAttacks,
    manageEnemyAttackCount,
    applyLocustSpellEffect,
    applyBreathOfInsectsEffect,
    applyExplosiveEffect,
    applyRainbowBridgeEffect,
    applyMimicryEffect
  ]);

  useEffect(() => {
    if (currentPlayer === 2 && (gamePhase === 'set' || gamePhase === 'main') && !isAIProcessing && !isTurnTransitioning && !isPhaseExecuted(currentPlayer, turnCount, gamePhase)) {
      console.log(`⏰ AI Timer set for Player ${currentPlayer} in ${gamePhase} phase`);
      const timer = setTimeout(executeAIActions, 800);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, gamePhase, isAIProcessing, isTurnTransitioning, executeAIActions, isPhaseExecuted, turnCount]);

  const drawCard = useCallback(() => {
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      
      if (player.deck.length === 0) {
        const opponent = prev[`player${currentPlayer === 1 ? 2 : 1}`];
        const winner = player.territory.length > opponent.territory.length ? currentPlayer :
                      player.territory.length < opponent.territory.length ? (currentPlayer === 1 ? 2 : 1) : 'draw';
        
        setWinner(winner);
        setIsGameOver(true);
        addLog(`プレイヤー${currentPlayer}の山札が空になりました`, 'error');
        return prev;
      }
      
      const newCard = player.deck[0];
      addLog(`プレイヤー${currentPlayer}が「${newCard.name}」を引きました`, 'info');
      
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          deck: player.deck.slice(1),
          hand: [...player.hand, newCard]
        }
      };
    });
  }, [currentPlayer, addLog]);

  const setFeed = useCallback((card) => {
    if (isPhaseExecuted(currentPlayer, turnCount, 'set')) {
      addLog('このターンは既にセットフェーズが完了しています', 'error');
      return;
    }
    
    let feedCountAfter = 0;
    
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      const startFeedCount = manageTurnStartFeedCount.get(currentPlayer, turnCount);
      
      if (player.feedArea.length > startFeedCount) {
        addLog('このターンは既にエサをセットしています', 'error');
        return prev;
      }
      
      const newFeedArea = [...player.feedArea, {...card, hasPlayed: false}];
      feedCountAfter = newFeedArea.length;
      manageCardTurnAdded.record(card.id, currentPlayer, turnCount);
      
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          hand: player.hand.filter(c => c.id !== card.id),
          feedArea: newFeedArea,
          maxCost: feedCountAfter,
          hasSetFeed: true,
          currentCost: feedCountAfter
        }
      };
    });
    
    addLog(`プレイヤー${currentPlayer}が${card.name}をエサにセットしました (利用可能コスト: ${feedCountAfter})`, 'success');
    
    if (manageTurnStartFeedCount.hasIncreasedByOne(currentPlayer, turnCount, feedCountAfter)) {
      setLastSetCard(card);
      setShowPhaseConfirmation(true);
    }
  }, [currentPlayer, addLog, isPhaseExecuted, turnCount, manageTurnStartFeedCount, manageCardTurnAdded]);

  const skipFeedPhase = useCallback(async () => {
    if (currentPlayer !== 1 || gamePhase !== 'set') {
      addLog('セットフェーズではないか、プレイヤー1のターンではありません', 'error');
      return;
    }
    
    if (isPhaseExecuted(currentPlayer, turnCount, 'set')) {
      addLog('このターンは既にセットフェーズが完了しています', 'error');
      return;
    }
    
    markPhaseAsExecuted(currentPlayer, turnCount, 'set');
    
    const currentState = gameState?.[`player${currentPlayer}`];
    const currentCost = currentState?.currentCost || currentState?.maxCost || currentState?.feedArea?.length || 0;
    
    addLog(`エサセットをスキップしてメインフェーズに移行しました (利用可能コスト: ${currentCost})`, 'info');
    
    setGameState(prev => {
      if (!prev) return prev;
      
      const player = prev[`player${currentPlayer}`];
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          currentCost: player.currentCost || player.maxCost || player.feedArea.length,
          hasSetFeed: true
        }
      };
    });
    
    await advancePhase();
  }, [currentPlayer, gamePhase, turnCount, isPhaseExecuted, markPhaseAsExecuted, addLog, advancePhase, gameState]);

  const handlePhaseConfirmation = useCallback(async (confirm) => {
    setShowPhaseConfirmation(false);
    
    if (confirm) {
      markPhaseAsExecuted(currentPlayer, turnCount, 'set');
      await advancePhase();
      addLog('セットフェーズを終了し、メインフェーズに移行しました', 'info');
    } else {
      if (lastSetCard) {
        setGameState(prev => {
          if (!prev) return prev;
          
          const player = prev[`player${currentPlayer}`];
          const newFeedArea = player.feedArea.filter(c => c.id !== lastSetCard.id);
          manageCardTurnAdded.remove(lastSetCard.id);
          
          return {
            ...prev,
            [`player${currentPlayer}`]: {
              ...player,
              hand: [...player.hand, lastSetCard],
              feedArea: newFeedArea,
              maxCost: newFeedArea.length,
              hasSetFeed: newFeedArea.length > manageTurnStartFeedCount.get(currentPlayer, turnCount),
              currentCost: newFeedArea.length
            }
          };
        });
        
        addLog(`${lastSetCard.name}を手札に戻しました。セットフェーズを継続します`, 'info');
      } else {
        addLog('セットフェーズを継続します', 'info');
      }
    }
    
    setLastSetCard(null);
  }, [
    advancePhase,
    addLog,
    currentPlayer,
    turnCount,
    markPhaseAsExecuted,
    lastSetCard,
    manageCardTurnAdded,
    manageTurnStartFeedCount
  ]);

  const playCard = useCallback((card) => {
    if (isPhaseExecuted(currentPlayer, turnCount, 'main')) {
      addLog('このターンは既にメインフェーズが完了しています', 'error');
      return;
    }
    
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      
      if (card.cost > player.currentCost) {
        addLog(`コストが足りません (必要: ${card.cost}, 現在: ${player.currentCost})`, 'error');
        return prev;
      }
      
      if (card.type === 'insect' && player.field.length >= 5) {
        addLog('場がいっぱいです (最大5体)', 'error');
        return prev;
      }
      
      if (card.type === 'spell' && card.name && card.name.includes('蟲の息吹')) {
        addLog(`プレイヤー${currentPlayer}が${card.name}を使用しました (コスト: ${card.cost})`, 'success');
        
        const newState = {
          ...prev,
          [`player${currentPlayer}`]: {
            ...player,
            hand: player.hand.filter(c => c.id !== card.id),
            graveyard: [...player.graveyard, card],
            currentCost: player.currentCost - card.cost
          }
        };
        
        setTimeout(() => {
          applyBreathOfInsectsEffect(currentPlayer, card);
        }, 100);
        
        return newState;
      }
      
      if (card.type === 'spell' && card.name && card.name.includes('飛蝗の凶相')) {
        applyLocustSpellEffect(currentPlayer);
      }
      
      if (card.type === 'insect') {
        manageCardPlayedTurn.record(card.id, currentPlayer, turnCount);
      }
      
      addLog(`プレイヤー${currentPlayer}が${card.name}を${card.type === 'insect' ? '場に召喚' : '使用'}しました (コスト: ${card.cost})`, 'success');
      
      const newInsect = card.type === 'insect' ? {
        ...card,
        currentHealth: card.health,
        hasAttacked: false,
        hasPlayed: false,
        hasAttackedThisTurn: false,
        playedTurn: turnCount,
        isFlipped: false
      } : null;
      
      if (newInsect && newInsect.passive_effect_text && newInsect.passive_effect_text.includes('擬態')) {
        setTimeout(() => {
          applyMimicryEffect(newInsect, currentPlayer);
        }, 100);
      }
      
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          hand: player.hand.filter(c => c.id !== card.id),
          field: card.type === 'insect' ? [...player.field, newInsect] : player.field,
          graveyard: card.type !== 'insect' ? [...player.graveyard, card] : player.graveyard,
          currentCost: player.currentCost - card.cost
        }
      };
    });
  }, [
    currentPlayer,
    addLog,
    isPhaseExecuted,
    turnCount,
    manageCardPlayedTurn,
    applyLocustSpellEffect,
    applyBreathOfInsectsEffect,
    applyMimicryEffect
  ]);

  const applyEnhancementToInsect = useCallback((enhancementCard, targetInsect) => {
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      
      if (enhancementCard.cost > player.currentCost) {
        addLog(`コストが足りません (必要: ${enhancementCard.cost}, 現在: ${player.currentCost})`, 'error');
        return prev;
      }
      
      const updatedField = player.field.map(insect => {
        if (insect.id === targetInsect.id) {
          const appliedEnhancements = insect.appliedEnhancements || [];
          const newEnhancements = [...appliedEnhancements, enhancementCard];
          
          const { healthBonus } = calculateEnhancementEffects({...insect, appliedEnhancements: newEnhancements});
          const newMaxHealth = insect.health + healthBonus;
          const currentHealth = insect.currentHealth || insect.health;
          
          if (enhancementCard.name && enhancementCard.name.includes('天牛の大顎')) {
            addLog(`⚡ ${enhancementCard.name}により${targetInsect.name}の攻撃力が300増加しました！`, 'success');
          }
          
          if (enhancementCard.name && enhancementCard.name.includes('蓑虫の隠れ蓑')) {
            addLog(`🛡️ ${enhancementCard.name}により${targetInsect.name}の体力が500増加しました！`, 'success');
          }
          
          if (enhancementCard.name && enhancementCard.name.includes('針金虫の道連れ')) {
            addLog(`💀🪱 ${enhancementCard.name}により${targetInsect.name}に道連れ効果が付与されました！`, 'success');
          }
          
          return {
            ...insect,
            appliedEnhancements: newEnhancements,
            currentHealth: healthBonus > 0 ? currentHealth + (newMaxHealth - (insect.health + (healthBonus - 500))) : currentHealth
          };
        }
        return insect;
      });
      
      addLog(`プレイヤー${currentPlayer}が${enhancementCard.name}を${targetInsect.name}に適用しました (コスト: ${enhancementCard.cost})`, 'success');
      
      return {
        ...prev,
        [`player${currentPlayer}`]: {
          ...player,
          hand: player.hand.filter(c => c.id !== enhancementCard.id),
          field: updatedField,
          currentCost: player.currentCost - enhancementCard.cost
        }
      };
    });
  }, [currentPlayer, addLog, calculateEnhancementEffects]);

  const returnCardToHand = useCallback((card, area, playerNumber) => {
    if (gamePhase === 'main' && area === 'feed') {
      addLog('メインフェーズではエサ場のカードを手札に戻すことができません', 'error');
      return;
    }
    
    if (area === 'field') {
      if (!manageCardPlayedTurn.canReturnFromField(card.id, playerNumber, turnCount)) {
        addLog('このカードは手札に戻すことができません（場に出されたターンではありません）', 'error');
        return;
      }
      
      // 🆕 カードが場を離れる時にセアカゴケグモの攻撃2使用履歴をリセット
      if (card.name && card.name.includes('セアカゴケグモ')) {
        manageSeakagokeGumoAttack2.resetUsage(card.id, playerNumber);
        addLog(`🕷️ ${card.name}が場を離れたため、攻撃2の使用履歴がリセットされました`, 'info');
      }
    }
    
    if (area === 'feed') {
      if (manageBreathOfInsectsCards.isBreathOfInsectsCard(card.id)) {
        addLog('蟲の息吹で追加されたカードは手札に戻すことができません', 'error');
        return;
      }
      
      if (!manageCardTurnAdded.canReturnToHand(card.id, area, playerNumber, turnCount)) {
        addLog('このカードは手札に戻すことができません（別のターンで追加されたカードです）', 'error');
        return;
      }
    }
    
    if (!card.hasPlayed) {
      setGameState(prev => {
        const player = prev[`player${playerNumber}`];
        
        let newCurrentCost = player.currentCost;
        let newMaxCost = player.maxCost;
        let newHasSetFeed = player.hasSetFeed;
        
        if (area === 'feed') {
          const newFeedArea = player.feedArea.filter(c => c.id !== card.id);
          const wasBreathCard = manageBreathOfInsectsCards.remove(card.id);
          newMaxCost = newFeedArea.length;
          
          if (!wasBreathCard) {
            newCurrentCost = newMaxCost;
          } else {
            console.log(`🌪️ 蟲の息吹カード${card.name}が削除されました（コスト変更なし）`);
          }
          
          const startFeedCount = manageTurnStartFeedCount.get(playerNumber, turnCount);
          if (newFeedArea.length <= startFeedCount) {
            newHasSetFeed = false;
          }
          
          if (!wasBreathCard) {
            manageCardTurnAdded.remove(card.id);
          }
        } else if (area === 'field') {
          newCurrentCost = Math.min(newCurrentCost + card.cost, newMaxCost);
          manageCardPlayedTurn.remove(card.id, playerNumber);
        }
        
        const areaKey = area === 'feed' ? 'feedArea' : 'field';
        
        return {
          ...prev,
          [`player${playerNumber}`]: {
            ...player,
            hand: [...player.hand, {...card, isFlipped: false}],
            [areaKey]: player[areaKey].filter(c => c.id !== card.id),
            currentCost: newCurrentCost,
            maxCost: area === 'feed' ? newMaxCost : player.maxCost,
            hasSetFeed: area === 'feed' ? newHasSetFeed : player.hasSetFeed
          }
        };
      });
      
      addLog(`プレイヤー${playerNumber}が${card.name}を手札に戻しました${area === 'feed' ? ' (利用可能コスト-1)' : ''}`, 'info');
    }
  }, [
    addLog,
    turnCount,
    manageCardTurnAdded,
    manageTurnStartFeedCount,
    gamePhase,
    manageCardPlayedTurn,
    manageBreathOfInsectsCards,
    manageSeakagokeGumoAttack2
  ]);

  const attackWithInsect = useCallback((attackingInsect, attackType = 1, targetInsect = null) => {
    const opponentPlayer = currentPlayer === 1 ? 2 : 1;
    
    // 🆕 セアカゴケグモの攻撃2使用制限チェック
    if (attackType === 2 && attackingInsect.name && attackingInsect.name.includes('セアカゴケグモ')) {
      const attack2Status = getSeakagokeGumoAttack2Status(attackingInsect.id, currentPlayer, attackingInsect.name);
      
      if (!attack2Status.canUseAttack2) {
        addLog(`🕷️ ${attackingInsect.name}の攻撃2は既に使用済みです！攻撃2は1度しか使用できません。`, 'error');
        return;
      }
      
      // 攻撃2使用をマーク
      manageSeakagokeGumoAttack2.markUsed(attackingInsect.id, currentPlayer, turnCount);
      addLog(`🕷️ ${attackingInsect.name}が攻撃2を使用しました。この攻撃2はもう使用できません。`, 'info');
    }
    
    let attackValue = getEffectiveAttackPower(attackingInsect, attackType, currentPlayer);
    const effectText = attackType === 2 ? attackingInsect.effect2_text : attackingInsect.effect1_text;
    let isAdvantage = false;
    
    if (targetInsect) {
      isAdvantage = checkElementAdvantage(attackingInsect.element, targetInsect.element);
      if (isAdvantage) {
        attackValue = Math.floor(attackValue * 2);
      }
    }
    
    setGameState(prev => {
      const player = prev[`player${currentPlayer}`];
      const opponent = prev[`player${opponentPlayer}`];
      
      const markAttackerAsUsed = (playerField, attackerId) => {
        return playerField.map(insect => 
          insect.id === attackerId ? {...insect, hasAttacked: true} : insect
        );
      };
      
      if (targetInsect) {
        let attackMessage = `プレイヤー${currentPlayer}の${attackingInsect.name}が攻撃${attackType}(${attackValue})でプレイヤー${opponentPlayer}の${targetInsect.isFlipped ? "裏返った虫" : targetInsect.name}を攻撃！`;
        if (isAdvantage) {
          const elementNames = {
            'red': '赤',
            'blue': '青',
            'green': '緑'
          };
          attackMessage += ` 【属性有利: ${elementNames[attackingInsect.element]} → ${elementNames[targetInsect.element]} ×2ダメージ！】`;
        }
        
        // 🆕 セアカゴケグモの攻撃2使用時の特別メッセージ
        if (attackType === 2 && attackingInsect.name && attackingInsect.name.includes('セアカゴケグモ')) {
          attackMessage += ` 【🕷️ セアカゴケグモの攻撃2 - この攻撃はもう使用できません】`;
        }
        
        const { totalDebuff } = manageDebuffEffects.getActiveDebuffs(attackingInsect.id, turnCount);
        const locustBonus = manageLocustSpellEffects.getActiveBonus(currentPlayer, turnCount);
        
        if (totalDebuff > 0) {
          addLog(`🦋 ${attackingInsect.name}は弱体化効果により攻撃力が${totalDebuff}低下中！`, 'info');
        }
        
        if (locustBonus > 0) {
          addLog(`🦗 ${attackingInsect.name}は飛蝗の凶相効果により攻撃力が${locustBonus}増加中！`, 'info');
        }
        
        addLog(attackMessage, 'attack');
        
        if (effectText) {
          addLog(`${attackingInsect.name}の効果${attackType}が発動: ${effectText}`, 'success');
        }
        
        if (attackingInsect.name && attackingInsect.name.includes('カブト') && attackType === 2) {
          addLog(`🔄 ${attackingInsect.name}の攻撃2により、${targetInsect.isFlipped ? "裏返った虫" : targetInsect.name}が裏返されました！`, 'attack');
        }
        
        if (attackingInsect.name && attackingInsect.name.includes('ナミアゲハ') && attackType === 2) {
          applyDebuffEffect(attackingInsect, targetInsect);
        }
        
        logAttackToDatabase({
          attackerPlayer: currentPlayer,
          targetPlayer: opponentPlayer,
          attackerCard: attackingInsect,
          targetType: 'insect',
          targetCard: targetInsect,
          attackValue,
          attackType,
          isAdvantage,
          damageDealt: attackValue
        });
        
        let newOpponentField = [...opponent.field];
        let newOpponentGraveyard = [...opponent.graveyard];
        let newPlayerField = [...player.field];
        let newOpponentHand = [...opponent.hand];
        let newOpponentTerritory = [...opponent.territory];
        
        const targetMaxHealth = getEffectiveMaxHealth(targetInsect);
        const targetCurrentHealth = targetInsect.currentHealth !== undefined ? targetInsect.currentHealth : targetMaxHealth;
        const newTargetHealth = Math.max(0, targetCurrentHealth - attackValue);
        
        addLog(`${targetInsect.isFlipped ? "裏返った虫" : targetInsect.name}は${attackValue}ダメージを受けました (${targetCurrentHealth} → ${newTargetHealth})`, 'attack');
        
        if (newTargetHealth <= 0) {
          const needlewormEffect = checkNeedlewormRoadCompanionEffect(targetInsect, attackingInsect);
          newOpponentField = opponent.field.filter(insect => insect.id !== targetInsect.id);
          newOpponentGraveyard = [...opponent.graveyard, {...targetInsect, isFlipped: false}];
          
          addLog(`${targetInsect.isFlipped ? "裏返った虫" : targetInsect.name}は撃破され、プレイヤー${opponentPlayer}の捨札に送られました！`, 'attack');
          
          if (newOpponentTerritory.length > 0) {
            const drawnCard = newOpponentTerritory[newOpponentTerritory.length - 1];
            newOpponentTerritory = newOpponentTerritory.slice(0, -1);
            newOpponentHand = [...newOpponentHand, drawnCard];
            // 🔧 修正: プレイヤー番号を明記
            addLog(`🏠 虫が撃破されたため、プレイヤー${opponentPlayer}のカードが縄張りから手札に移動しました`, 'info');
          }
          
          if (needlewormEffect?.shouldDestroy) {
            newPlayerField = player.field.filter(insect => insect.id !== attackingInsect.id);
            const newPlayerGraveyard = [...player.graveyard, {...attackingInsect, isFlipped: false}];
            
            addLog(`💀🪱 針金虫の道連れの効果発動！${targetInsect.name}を破壊した${attackingInsect.name}も道連れで破壊されます！`, 'attack');
            
            let newPlayerHand = [...player.hand];
            let newPlayerTerritory = [...player.territory];
            
            if (newPlayerTerritory.length > 0) {
              const drawnCard = newPlayerTerritory[newPlayerTerritory.length - 1];
              newPlayerTerritory = newPlayerTerritory.slice(0, -1);
              newPlayerHand = [...newPlayerHand, drawnCard];
              // 🔧 修正: プレイヤー番号を明記
              addLog(`🏠 針金虫の道連れで虫が撃破されたため、プレイヤー${currentPlayer}のカードが縄張りから手札に移動しました`, 'info');
            }
            
            // 🆕 針金虫の道連れで撃破された場合もセアカゴケグモの使用履歴をリセット
            if (attackingInsect.name && attackingInsect.name.includes('セアカゴケグモ')) {
              manageSeakagokeGumoAttack2.resetUsage(attackingInsect.id, currentPlayer);
            }
            
            return {
              ...prev,
              [`player${opponentPlayer}`]: {
                ...opponent,
                field: newOpponentField,
                graveyard: newOpponentGraveyard,
                hand: newOpponentHand,
                territory: newOpponentTerritory
              },
              [`player${currentPlayer}`]: {
                ...player,
                field: newPlayerField,
                graveyard: newPlayerGraveyard,
                hand: newPlayerHand,
                territory: newPlayerTerritory
              }
            };
          }
        } else {
          const shouldFlip = attackingInsect.name && attackingInsect.name.includes('カブト') && attackType === 2;
          newOpponentField = opponent.field.map(insect => 
            insect.id === targetInsect.id ? {
              ...insect,
              currentHealth: newTargetHealth,
              isFlipped: shouldFlip ? true : insect.isFlipped
            } : insect
          );
        }
        
        newPlayerField = markAttackerAsUsed(newPlayerField, attackingInsect.id);
        
        return {
          ...prev,
          [`player${opponentPlayer}`]: {
            ...opponent,
            field: newOpponentField,
            graveyard: newOpponentGraveyard,
            hand: newOpponentHand,
            territory: newOpponentTerritory
          },
          [`player${currentPlayer}`]: {
            ...player,
            field: newPlayerField
          }
        };
      }
      
      // プレイヤーの縄張り直接攻撃
      const validTargets = getValidAttackTargets(opponent.field, turnCount, gamePhase, currentPlayer);
      const tauntStatus = checkTauntEffect(validTargets);
      const defendingBugs = tauntStatus.validTargets;
      
      if (defendingBugs.length === 0) {
        if (opponent.territory.length === 0) {
          setWinner(currentPlayer);
          setIsGameOver(true);
          addLog(`プレイヤー${currentPlayer}の勝利！`, 'success');
          
          const newPlayerField = markAttackerAsUsed(player.field, attackingInsect.id);
          return {
            ...prev,
            [`player${currentPlayer}`]: {
              ...player,
              field: newPlayerField
            }
          };
        } else {
          const territoryCard = opponent.territory[opponent.territory.length - 1];
          
          if (tauntStatus.hasTaunt) {
            addLog(`🦋 ナミアゲハの挑発効果により、プレイヤー${currentPlayer}の${attackingInsect.name}はナミアゲハしか攻撃できません！`, 'error');
            return prev;
          }
          
          const flippedBugs = opponent.field.filter(bug => bug.type === 'insect' && bug.isFlipped);
          const mimicryBugs = opponent.field.filter(bug => {
            const hasMimicry = manageMimicryEffects.isActive(bug.id, turnCount, gamePhase, currentPlayer);
            return hasMimicry && bug.type === 'insect';
          });
          
          let attackMessage = `プレイヤー${currentPlayer}の${attackingInsect.name}が攻撃${attackType}(${attackValue})でプレイヤー${opponentPlayer}を直接攻撃！`;
          // 🔧 修正: 擬態中の虫は縄張りを守れないことを明確に表現
          if (flippedBugs.length > 0 && mimicryBugs.length > 0) {
            attackMessage += `（裏向きの虫${flippedBugs.length}匹は守れず、擬態中の虫${mimicryBugs.length}匹は場にいないため縄張りを守れない）`;
          } else if (flippedBugs.length > 0) {
            attackMessage += `（裏向きの虫${flippedBugs.length}匹は守れない）`;
          } else if (mimicryBugs.length > 0) {
            attackMessage += `（擬態中の虫${mimicryBugs.length}匹は場にいないため縄張りを守れない）`;
          }
          
          // 🆕 セアカゴケグモの攻撃2使用時の特別メッセージ
          if (attackType === 2 && attackingInsect.name && attackingInsect.name.includes('セアカゴケグモ')) {
            attackMessage += ` 【🕷️ セアカゴケグモの攻撃2 - この攻撃はもう使用できません】`;
          }
          
          addLog(attackMessage, 'attack');
          
          if (effectText) {
            addLog(`${attackingInsect.name}の効果${attackType}が発動: ${effectText}`, 'success');
          }
          
          // 🔧 修正: プレイヤー番号を明記
          addLog(`🏠 プレイヤー${opponentPlayer}のカードが縄張りから手札に移動しました`, 'info');
          
          manageTerritoryAttackHistory.record(
            currentPlayer,
            opponentPlayer,
            turnCount,
            attackingInsect,
            attackValue
          );
          
          logAttackToDatabase({
            attackerPlayer: currentPlayer,
            targetPlayer: opponentPlayer,
            attackerCard: attackingInsect,
            targetType: 'territory',
            targetCard: territoryCard,
            attackValue,
            attackType,
            isAdvantage: false,
            damageDealt: attackValue
          });
          
          const newPlayerField = markAttackerAsUsed(player.field, attackingInsect.id);
          
          return {
            ...prev,
            [`player${opponentPlayer}`]: {
              ...opponent,
              territory: opponent.territory.slice(0, -1),
              hand: [...opponent.hand, territoryCard]
            },
            [`player${currentPlayer}`]: {
              ...player,
              field: newPlayerField
            }
          };
        }
      }
      
      return prev;
    });
  }, [
    currentPlayer,
    addLog,
    checkElementAdvantage,
    manageTerritoryAttackHistory,
    logAttackToDatabase,
    getEffectiveAttackPower,
    manageDebuffEffects,
    turnCount,
    applyDebuffEffect,
    getEffectiveMaxHealth,
    manageLocustSpellEffects,
    checkNeedlewormRoadCompanionEffect,
    checkTauntEffect,
    manageMimicryEffects,
    getValidAttackTargets,
    gamePhase,
    manageSeakagokeGumoAttack2,
    getSeakagokeGumoAttack2Status
  ]);

  const endTurn = useCallback(async () => {
    if (isAIProcessing || isTurnTransitioning) {
      addLog('ターン処理中のため、操作できません', 'error');
      return;
    }
    
    if (currentPlayer !== 1) {
      addLog('プレイヤー1のターンではありません', 'error');
      return;
    }
    
    if (gamePhase === 'set' && showPhaseConfirmation) {
      addLog('エサセットの確認が必要です。「はい」または「いいえ」を選択してください', 'error');
      return;
    }
    
    if (gamePhase === 'set') {
      const currentState = gameState?.[`player${currentPlayer}`];
      if (!currentState?.hasSetFeed) {
        addLog('エサをセットしていませんが、スキップボタンを使用してメインフェーズに移行してください', 'error');
        return;
      }
    }
    
    markPhaseAsExecuted(currentPlayer, turnCount, gamePhase);
    addLog('プレイヤー1のターンが終了しました', 'info');
    
    const success = await endPlayerTurn();
    if (success) {
      const nextTurn = currentPlayer === 1 ? turnCount : turnCount + 1;
      addLog(`プレイヤー2のターン${nextTurn}開始 - ドローフェーズ`, 'success');
    } else {
      addLog('ターン移行に失敗しました', 'error');
    }
  }, [
    currentPlayer,
    isAIProcessing,
    isTurnTransitioning,
    endPlayerTurn,
    addLog,
    turnCount,
    gamePhase,
    markPhaseAsExecuted,
    gameState,
    showPhaseConfirmation
  ]);

  const getTerritoryAttackStatus = useCallback(() => {
    return {
      hasPlayer1BeenAttacked: manageTerritoryAttackHistory.hasTerritoryBeenAttacked(1, turnCount),
      hasPlayer2BeenAttacked: manageTerritoryAttackHistory.hasTerritoryBeenAttacked(2, turnCount),
      player1Attacks: manageTerritoryAttackHistory.getTerritoryAttacks(2, 1, turnCount),
      player2Attacks: manageTerritoryAttackHistory.getTerritoryAttacks(1, 2, turnCount),
      enemyAttackCount: manageEnemyAttackCount.getCount(2, turnCount),
      canEnemyAttack: manageEnemyAttackCount.canAttack(2, turnCount)
    };
  }, [manageTerritoryAttackHistory, turnCount, manageEnemyAttackCount]);

  const getDebuffStatus = useCallback((cardId) => {
    return manageDebuffEffects.getActiveDebuffs(cardId, turnCount);
  }, [manageDebuffEffects, turnCount]);

  const getLocustSpellStatus = useCallback((playerNumber) => {
    return manageLocustSpellEffects.getActiveBonus(playerNumber, turnCount);
  }, [manageLocustSpellEffects, turnCount]);

  const getTauntStatus = useCallback((targetPlayerField) => {
    return checkTauntEffect(targetPlayerField);
  }, [checkTauntEffect]);

  // 🔧 修正: 擬態効果の状態を取得する関数 - 場にいないもの扱い
  const getMimicryStatus = useCallback((cardId) => {
    const isActive = manageMimicryEffects.isActive(cardId, turnCount, gamePhase, currentPlayer);
    const effectDetails = manageMimicryEffects.getEffect(cardId);
    return { isActive, effectDetails };
  }, [manageMimicryEffects, turnCount, gamePhase, currentPlayer]);

  return {
    gameState,
    currentPlayer,
    gamePhase,
    turnCount,
    gameLog,
    isGameOver,
    winner,
    isAIProcessing,
    isTurnTransitioning,
    gameSessionId,
    showPhaseConfirmation,
    lastSetCard,
    initializeGame,
    initializeGameWithDecks,
    endTurn,
    playCard,
    attackWithInsect,
    setFeed,
    drawCard,
    returnCardToHand,
    handlePhaseConfirmation,
    getTurnHistory,
    skipFeedPhase,
    applyEnhancementToInsect,
    getTerritoryAttackStatus,
    getDebuffStatus,
    getEffectiveAttackPower,
    getEffectiveMaxHealth,
    getLocustSpellStatus,
    applyExplosiveEffect,
    applyRainbowBridgeEffect,
    applyColorChangeEnhancement,
    getTauntStatus,
    getMimicryStatus,
    mimicryRefresh,
    // 🆕 セアカゴケグモの攻撃2使用状況を取得する関数を公開
    getSeakagokeGumoAttack2Status
  };
};