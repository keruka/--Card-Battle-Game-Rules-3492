export const calculateDamage = (attacker, defender) => {
  let damage = attacker.attack;
  
  // Element advantage: red > green > blue > red
  if (
    (attacker.element === 'red' && defender.element === 'green') ||
    (attacker.element === 'green' && defender.element === 'blue') ||
    (attacker.element === 'blue' && defender.element === 'red')
  ) {
    damage *= 2;
  }
  
  return damage;
};

export const checkWinCondition = (gameState) => {
  const { player1, player2 } = gameState;
  
  // Win by territory destruction
  if (player1.territory.length === 0) {
    return { winner: 2, reason: 'territory' };
  }
  if (player2.territory.length === 0) {
    return { winner: 1, reason: 'territory' };
  }
  
  // Win by deck exhaustion
  if (player1.deck.length === 0 && player2.deck.length === 0) {
    if (player1.territory.length > player2.territory.length) {
      return { winner: 1, reason: 'territory_count' };
    } else if (player2.territory.length > player1.territory.length) {
      return { winner: 2, reason: 'territory_count' };
    } else {
      return { winner: 'draw', reason: 'territory_tie' };
    }
  }
  
  return null;
};

export const isValidPlay = (card, player, gamePhase) => {
  if (gamePhase === 'set') {
    return true; // Any card can be used as feed
  }
  
  if (gamePhase === 'main') {
    if (card.cost > player.currentCost) {
      return false;
    }
    
    if (card.type === 'insect' && player.field.length >= 5) {
      return false;
    }
    
    return true;
  }
  
  return false;
};