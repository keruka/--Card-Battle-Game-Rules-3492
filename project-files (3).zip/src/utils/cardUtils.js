import { v4 as uuidv4 } from 'uuid';

// Enhanced error handling for card creation
const createCardWithFallback = (baseCard) => ({
  id: uuidv4(),
  name: baseCard.name || 'Unknown Card',
  type: baseCard.type || 'insect',
  cost: typeof baseCard.cost === 'number' ? baseCard.cost : 1,
  attack: baseCard.attack1 || baseCard.attack || 100,
  attack1: baseCard.attack1 || baseCard.attack || 100,
  // 🔧 修正: attack2の処理 - NULLと0を明確に区別
  attack2: baseCard.attack2 !== null && baseCard.attack2 !== undefined ? baseCard.attack2 : null,
  health: typeof baseCard.health === 'number' ? baseCard.health : 100,
  element: baseCard.element || 'green',
  rarity: baseCard.rarity || 'N',
  effect: baseCard.effect_text || '',
  effect1_text: baseCard.effect1_text || baseCard.effect_text || '',
  effect2_text: baseCard.effect2_text || '',
  passive_effect_text: baseCard.passive_effect_text || '',
  image_url: baseCard.image_url || ''
});

// Lazy load Supabase to prevent blocking
let supabaseInstance = null;
const getSupabase = async () => {
  if (!supabaseInstance) {
    try {
      const { default: supabase } = await import('../lib/supabase');
      supabaseInstance = supabase;
    } catch (error) {
      console.warn('Supabase not available:', error);
      return null;
    }
  }
  return supabaseInstance;
};

export const createInitialDeck = async () => {
  try {
    // Try to load cards from database with timeout
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Database timeout')), 3000)
    );

    const supabase = await getSupabase();
    if (!supabase) {
      throw new Error('Supabase not available');
    }

    const dbPromise = supabase
      .from('cards_mushi_a7x9k2')
      .select('*')
      .not('image_url', 'is', null)
      .neq('image_url', '')
      .limit(50);

    const { data: dbCards, error } = await Promise.race([dbPromise, timeoutPromise]);

    if (!error && dbCards && dbCards.length > 0) {
      console.log(`✅ Loaded ${dbCards.length} cards from database`);
      
      // Convert database cards to game format with error handling
      const gameCards = dbCards.map(card => {
        try {
          return createCardWithFallback(card);
        } catch (err) {
          console.warn('⚠️ Error processing card:', card.name, err);
          return null;
        }
      }).filter(Boolean);

      if (gameCards.length >= 10) {
        // Create balanced deck
        const deck = [];
        const cardsByType = {
          insect: gameCards.filter(c => c.type === 'insect'),
          spell: gameCards.filter(c => c.type === 'spell'),
          enhancement: gameCards.filter(c => c.type === 'enhancement')
        };

        // Add insects (priority)
        const insectCount = Math.min(16, cardsByType.insect.length);
        for (let i = 0; i < insectCount; i++) {
          const randomCard = cardsByType.insect[Math.floor(Math.random() * cardsByType.insect.length)];
          deck.push({ ...randomCard, id: uuidv4() });
        }

        // Fill remaining slots
        const remainingSlots = 20 - deck.length;
        const otherCards = [...cardsByType.spell, ...cardsByType.enhancement];
        for (let i = 0; i < remainingSlots && otherCards.length > 0; i++) {
          const randomCard = otherCards[Math.floor(Math.random() * otherCards.length)];
          deck.push({ ...randomCard, id: uuidv4() });
        }

        // Fill any remaining slots with random cards
        while (deck.length < 20 && gameCards.length > 0) {
          const randomCard = gameCards[Math.floor(Math.random() * gameCards.length)];
          deck.push({ ...randomCard, id: uuidv4() });
        }

        if (deck.length >= 20) {
          return deck.slice(0, 20);
        }
      }
    }
  } catch (error) {
    console.warn('⚠️ Database unavailable, using fallback cards:', error.message);
  }

  // Enhanced fallback cards with better variety
  const fallbackCards = [
    {
      name: '基本甲虫',
      type: 'insect',
      cost: 1,
      attack1: 100,
      attack2: 150,
      health: 100,
      element: 'green',
      rarity: 'N',
      effect1_text: '軽い攻撃',
      effect2_text: '少し強い攻撃'
    },
    {
      name: '赤トンボ',
      type: 'insect',
      cost: 1,
      attack1: 120,
      attack2: 180,
      health: 80,
      element: 'red',
      rarity: 'N',
      effect1_text: '素早い攻撃',
      effect2_text: '急降下攻撃'
    },
    {
      name: '青い蝶',
      type: 'insect',
      cost: 1,
      attack1: 90,
      attack2: 140,
      health: 120,
      element: 'blue',
      rarity: 'N',
      effect1_text: '粉攻撃',
      effect2_text: '魅惑の舞'
    },
    {
      name: 'クワガタ',
      type: 'insect',
      cost: 2,
      attack1: 200,
      attack2: 300,
      health: 200,
      element: 'green',
      rarity: 'N',
      effect1_text: '挟み攻撃',
      effect2_text: '強力挟み'
    },
    {
      name: 'スズメバチ',
      type: 'insect',
      cost: 2,
      attack1: 150,
      attack2: 250,
      health: 180,
      element: 'red',
      rarity: 'N',
      effect1_text: '毒針攻撃',
      effect2_text: '炎の針'
    },
    {
      name: 'カマキリ',
      type: 'insect',
      cost: 2,
      attack1: 180,
      attack2: 280,
      health: 160,
      element: 'blue',
      rarity: 'N',
      effect1_text: '鎌攻撃',
      effect2_text: '氷の鎌'
    },
    {
      name: 'レアカブト',
      type: 'insect',
      cost: 3,
      attack1: 300,
      attack2: 450,
      health: 350,
      element: 'green',
      rarity: 'R',
      effect1_text: '角攻撃',
      effect2_text: '必殺角突き',
      passive_effect_text: '威風堂々: 場の他の虫の攻撃力+50'
    },
    {
      name: '雷ムカデ',
      type: 'insect',
      cost: 3,
      attack1: 350,
      attack2: 500,
      health: 250,
      element: 'red',
      rarity: 'R',
      effect1_text: '電撃攻撃',
      effect2_text: '雷撃',
      passive_effect_text: '感電: 敵の虫を麻痺させる'
    },
    {
      name: 'カブトムシ（幼虫）',
      type: 'insect',
      cost: 1,
      attack1: 50,
      attack2: 0,
      health: 200,
      element: 'green',
      rarity: 'N',
      effect1_text: '弱い攻撃',
      effect2_text: '体当たり（無力）'
    },
    {
      name: 'ナミアゲハ（幼虫）',
      type: 'insect',
      cost: 1,
      attack1: 30,
      attack2: 0,
      health: 150,
      element: 'green',
      rarity: 'N',
      effect1_text: '葉っぱかじり',
      effect2_text: '無力な体当たり'
    },
    // 🆕 擬態能力を持つナナフシモドキ
    {
      name: 'ナナフシモドキ',
      type: 'insect',
      cost: 1,
      attack1: 80,
      attack2: null,
      health: 60,
      element: 'green',
      rarity: 'N',
      effect1_text: '細い体での攻撃',
      passive_effect_text: '擬態: 場に出たとき、敵の攻撃を1回無効化する'
    },
    {
      name: '普通のアリ',
      type: 'insect',
      cost: 1,
      attack1: 80,
      attack2: null,
      health: 60,
      element: 'green',
      rarity: 'N',
      effect1_text: '噛みつき'
    },
    {
      name: 'ハエ',
      type: 'insect',
      cost: 1,
      attack1: 40,
      attack2: null,
      health: 40,
      element: 'red',
      rarity: 'N',
      effect1_text: 'ブンブン飛ぶ'
    },
    {
      name: '強化の術',
      type: 'spell',
      cost: 1,
      effect1_text: 'ムシの攻撃力+100',
      rarity: 'N',
      element: 'neutral'
    },
    {
      name: '回復の術',
      type: 'spell',
      cost: 1,
      effect1_text: 'ムシの体力を全回復',
      rarity: 'N',
      element: 'neutral'
    },
    {
      name: '飛蝗の凶相',
      type: 'spell',
      cost: 2,
      effect1_text: 'ターン終了時まで、自分のすべての虫の攻撃力+200',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '蟲の息吹',
      type: 'spell',
      cost: 1,
      effect1_text: 'このカードをコストなしでエサ場に置く',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '塵芥虫の爆熱弾',
      type: 'spell',
      cost: 3,
      effect1_text: '選択した敵の虫に600の固定ダメージ。撃破された虫は捨札に送られる',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '虹の架け橋',
      type: 'spell',
      cost: 2,
      effect1_text: '自分の捨札の虫を1体選び、手札に戻す',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '天牛の大顎',
      type: 'enhancement',
      cost: 2,
      effect1_text: '装備した虫の攻撃力+300',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '蓑虫の隠れ蓑',
      type: 'enhancement',
      cost: 2,
      effect1_text: '装備した虫の体力+500',
      rarity: 'R',
      element: 'neutral'
    },
    {
      name: '針金虫の道連れ',
      type: 'enhancement',
      cost: 3,
      effect1_text: '装備している虫が虫の攻撃によって破壊されたとき、これを破壊した虫を破壊する',
      rarity: 'SR',
      element: 'neutral'
    },
    {
      name: '玉虫色の羽化',
      type: 'enhancement',
      cost: 2,
      effect1_text: '装備した虫の属性を選択した色に変更する',
      rarity: 'R',
      element: 'neutral'
    }
  ];

  // Create a 20-card deck with enhanced variety
  const deck = [];
  const cardsPerType = Math.floor(20 / fallbackCards.length);

  fallbackCards.forEach(card => {
    for (let i = 0; i < cardsPerType; i++) {
      if (deck.length < 20) {
        deck.push(createCardWithFallback(card));
      }
    }
  });

  // Fill remaining slots
  while (deck.length < 20) {
    const randomCard = fallbackCards[Math.floor(Math.random() * fallbackCards.length)];
    deck.push(createCardWithFallback(randomCard));
  }

  console.log(`✅ Created fallback deck with ${deck.length} cards`);
  return deck.slice(0, 20);
};

export const shuffleDeck = (deck) => {
  if (!Array.isArray(deck) || deck.length === 0) {
    console.warn('⚠️ Invalid deck for shuffling, creating fallback');
    return [];
  }

  const shuffled = [...deck];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

// Safe game session functions with error handling
export const saveGameSession = async (gameState) => {
  try {
    const supabase = await getSupabase();
    if (!supabase) return null;

    const { data, error } = await supabase
      .from('game_sessions_a7x9k2')
      .insert([{
        player1_deck: gameState.player1,
        player2_deck: gameState.player2,
        current_state: gameState,
        current_player: gameState.currentPlayer || 1,
        game_phase: gameState.gamePhase || 'setup'
      }])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error saving game session:', error);
    return null;
  }
};

export const loadGameSession = async (sessionId) => {
  try {
    const supabase = await getSupabase();
    if (!supabase) return null;

    const { data, error } = await supabase
      .from('game_sessions_a7x9k2')
      .select('*')
      .eq('id', sessionId)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error loading game session:', error);
    return null;
  }
};