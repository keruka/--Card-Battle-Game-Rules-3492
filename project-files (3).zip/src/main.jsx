import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// Enhanced error boundary component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('Application Error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
          <div className="bg-red-900/20 border border-red-600 rounded-lg p-6 max-w-lg w-full">
            <h2 className="text-red-400 text-lg font-bold mb-2">アプリケーションエラー</h2>
            <p className="text-gray-300 text-sm mb-4">
              アプリケーションの読み込み中にエラーが発生しました。
            </p>
            <details className="mb-4">
              <summary className="text-red-300 cursor-pointer text-sm">詳細を表示</summary>
              <pre className="text-xs text-gray-400 mt-2 overflow-auto max-h-32">
                {this.state.error && this.state.error.toString()}
                {this.state.errorInfo && this.state.errorInfo.componentStack}
              </pre>
            </details>
            <div className="flex gap-2">
              <button
                onClick={() => window.location.reload()}
                className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded transition-colors"
              >
                リロード
              </button>
              <button
                onClick={() => window.location.href = '/'}
                className="bg-gray-600 hover:bg-gray-500 text-white px-4 py-2 rounded transition-colors"
              >
                ホームに戻る
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Safe root creation with error handling
try {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    throw new Error('Root element not found');
  }

  const root = ReactDOM.createRoot(rootElement);

  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
} catch (error) {
  console.error('Failed to initialize React app:', error);
  document.body.innerHTML = `
    <div style="
      min-height: 100vh; 
      background: #1f2937; 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      color: white; 
      font-family: Arial, sans-serif;
      padding: 20px;
    ">
      <div style="
        background: rgba(239, 68, 68, 0.1); 
        border: 2px solid #dc2626; 
        border-radius: 8px; 
        padding: 20px; 
        max-width: 500px; 
        text-align: center;
      ">
        <h2 style="color: #fca5a5; margin: 0 0 10px 0;">初期化エラー</h2>
        <p style="color: #d1d5db; margin: 0 0 20px 0; font-size: 14px;">
          アプリケーションの初期化に失敗しました。ページを再読み込みしてください。
        </p>
        <button 
          onclick="window.location.reload()" 
          style="
            background: #dc2626; 
            color: white; 
            border: none; 
            padding: 10px 20px; 
            border-radius: 4px; 
            cursor: pointer;
          "
        >
          再読み込み
        </button>
      </div>
    </div>
  `;
}